@media screen {a.interwiki { background: transparent url(/wiki/pm/lib/images/interwiki.png) 0px 1px no-repeat; padding: 1px 0px 1px 16px;}a.iw_wp {  background-image: url(/wiki/pm/lib/images/interwiki/wp.gif)}a.iw_wpfr {  background-image: url(/wiki/pm/lib/images/interwiki/wpfr.gif)}a.iw_wpde {  background-image: url(/wiki/pm/lib/images/interwiki/wpde.gif)}a.iw_wpes {  background-image: url(/wiki/pm/lib/images/interwiki/wpes.gif)}a.iw_wppl {  background-image: url(/wiki/pm/lib/images/interwiki/wppl.gif)}a.iw_wpjp {  background-image: url(/wiki/pm/lib/images/interwiki/wpjp.gif)}a.iw_wpmeta {  background-image: url(/wiki/pm/lib/images/interwiki/wpmeta.gif)}a.iw_doku {  background-image: url(/wiki/pm/lib/images/interwiki/doku.gif)}a.iw_dokubug {  background-image: url(/wiki/pm/lib/images/interwiki/dokubug.gif)}a.iw_amazon {  background-image: url(/wiki/pm/lib/images/interwiki/amazon.gif)}a.iw_amazon_de {  background-image: url(/wiki/pm/lib/images/interwiki/amazon.de.gif)}a.iw_amazon_uk {  background-image: url(/wiki/pm/lib/images/interwiki/amazon.uk.gif)}a.iw_paypal {  background-image: url(/wiki/pm/lib/images/interwiki/paypal.gif)}a.iw_phpfn {  background-image: url(/wiki/pm/lib/images/interwiki/phpfn.gif)}a.iw_coral {  background-image: url(/wiki/pm/lib/images/interwiki/coral.gif)}a.iw_sb {  background-image: url(/wiki/pm/lib/images/interwiki/sb.gif)}a.iw_skype {  background-image: url(/wiki/pm/lib/images/interwiki/skype.png)}a.iw_callto {  background-image: url(/wiki/pm/lib/images/interwiki/callto.gif)}a.iw_google {  background-image: url(/wiki/pm/lib/images/interwiki/google.gif)}a.iw_meatball {  background-image: url(/wiki/pm/lib/images/interwiki/meatball.gif)}a.iw_wiki {  background-image: url(/wiki/pm/lib/images/interwiki/wiki.gif)}.mediafile { background: transparent url(/wiki/pm/lib/images/fileicons/file.png) 0px 1px no-repeat; padding-left: 18px; padding-bottom: 1px;}.mf_sxi {  background-image: url(/wiki/pm/lib/images/fileicons/sxi.png)}.mf_gz {  background-image: url(/wiki/pm/lib/images/fileicons/gz.png)}.mf_xls {  background-image: url(/wiki/pm/lib/images/fileicons/xls.png)}.mf_mp3 {  background-image: url(/wiki/pm/lib/images/fileicons/mp3.png)}.mf_audio {  background-image: url(/wiki/pm/lib/images/fileicons/audio.png)}.mf_css {  background-image: url(/wiki/pm/lib/images/fileicons/css.png)}.mf_php {  background-image: url(/wiki/pm/lib/images/fileicons/php.png)}.mf_txt {  background-image: url(/wiki/pm/lib/images/fileicons/txt.png)}.mf_tgz {  background-image: url(/wiki/pm/lib/images/fileicons/tgz.png)}.mf_odp {  background-image: url(/wiki/pm/lib/images/fileicons/odp.png)}.mf_odi {  background-image: url(/wiki/pm/lib/images/fileicons/odi.png)}.mf_cpp {  background-image: url(/wiki/pm/lib/images/fileicons/cpp.png)}.mf_bz2 {  background-image: url(/wiki/pm/lib/images/fileicons/bz2.png)}.mf_gif {  background-image: url(/wiki/pm/lib/images/fileicons/gif.png)}.mf_rpm {  background-image: url(/wiki/pm/lib/images/fileicons/rpm.png)}.mf_c {  background-image: url(/wiki/pm/lib/images/fileicons/c.png)}.mf_rb {  background-image: url(/wiki/pm/lib/images/fileicons/rb.png)}.mf_ico {  background-image: url(/wiki/pm/lib/images/fileicons/ico.png)}.mf_sxc {  background-image: url(/wiki/pm/lib/images/fileicons/sxc.png)}.mf_xlsx {  background-image: url(/wiki/pm/lib/images/fileicons/xlsx.png)}.mf_odc {  background-image: url(/wiki/pm/lib/images/fileicons/odc.png)}.mf_ppt {  background-image: url(/wiki/pm/lib/images/fileicons/ppt.png)}.mf_pptx {  background-image: url(/wiki/pm/lib/images/fileicons/pptx.png)}.mf_ods {  background-image: url(/wiki/pm/lib/images/fileicons/ods.png)}.mf_7z {  background-image: url(/wiki/pm/lib/images/fileicons/7z.png)}.mf_pdf {  background-image: url(/wiki/pm/lib/images/fileicons/pdf.png)}.mf_swf {  background-image: url(/wiki/pm/lib/images/fileicons/swf.png)}.mf_pl {  background-image: url(/wiki/pm/lib/images/fileicons/pl.png)}.mf_odg {  background-image: url(/wiki/pm/lib/images/fileicons/odg.png)}.mf_rar {  background-image: url(/wiki/pm/lib/images/fileicons/rar.png)}.mf_docx {  background-image: url(/wiki/pm/lib/images/fileicons/docx.png)}.mf_xml {  background-image: url(/wiki/pm/lib/images/fileicons/xml.png)}.mf_wav {  background-image: url(/wiki/pm/lib/images/fileicons/wav.png)}.mf_csv {  background-image: url(/wiki/pm/lib/images/fileicons/csv.png)}.mf_conf {  background-image: url(/wiki/pm/lib/images/fileicons/conf.png)}.mf_png {  background-image: url(/wiki/pm/lib/images/fileicons/png.png)}.mf_jpeg {  background-image: url(/wiki/pm/lib/images/fileicons/jpeg.png)}.mf_htm {  background-image: url(/wiki/pm/lib/images/fileicons/htm.png)}.mf_sql {  background-image: url(/wiki/pm/lib/images/fileicons/sql.png)}.mf_ogg {  background-image: url(/wiki/pm/lib/images/fileicons/ogg.png)}.mf_zip {  background-image: url(/wiki/pm/lib/images/fileicons/zip.png)}.mf_jpg {  background-image: url(/wiki/pm/lib/images/fileicons/jpg.png)}.mf_sxd {  background-image: url(/wiki/pm/lib/images/fileicons/sxd.png)}.mf_doc {  background-image: url(/wiki/pm/lib/images/fileicons/doc.png)}.mf_tar {  background-image: url(/wiki/pm/lib/images/fileicons/tar.png)}.mf_html {  background-image: url(/wiki/pm/lib/images/fileicons/html.png)}.mf_odf {  background-image: url(/wiki/pm/lib/images/fileicons/odf.png)}.mf_java {  background-image: url(/wiki/pm/lib/images/fileicons/java.png)}.mf_rtf {  background-image: url(/wiki/pm/lib/images/fileicons/rtf.png)}.mf_sxw {  background-image: url(/wiki/pm/lib/images/fileicons/sxw.png)}.mf_cs {  background-image: url(/wiki/pm/lib/images/fileicons/cs.png)}.mf_py {  background-image: url(/wiki/pm/lib/images/fileicons/py.png)}.mf_js {  background-image: url(/wiki/pm/lib/images/fileicons/js.png)}.mf_odt {  background-image: url(/wiki/pm/lib/images/fileicons/odt.png)}.mf_ps {  background-image: url(/wiki/pm/lib/images/fileicons/ps.png)}.mf_lua {  background-image: url(/wiki/pm/lib/images/fileicons/lua.png)}.mf_deb {  background-image: url(/wiki/pm/lib/images/fileicons/deb.png)}}
@media screen { /* START screen styles */
/**
 * Basic screen styles. These styles are needed for basic DokuWiki functions
 * regardless of the used template. Templates can override them of course
 */

/* messages with msg() */
div.error,
div.info,
div.success,
div.notify {
    color: #000;
    background-repeat: no-repeat;
    background-position: 8px 50%;
    border: 1px solid;
    font-size: 90%;
    margin: 0 0 0.5em;
    padding: 0.4em;
    padding-left: 32px;
    overflow: hidden;
    border-radius: 5px;
}

div.error {
    background-color: #fcc;
    background-image: url(/wiki/pm/lib/styles/../images/error.png);
    border-color: #ebb;
}

div.info {
    background-color: #ccf;
    background-image: url(/wiki/pm/lib/styles/../images/info.png);
    border-color: #bbe;
}

div.success {
    background-color: #cfc;
    background-image: url(/wiki/pm/lib/styles/../images/success.png);
    border-color: #beb;
}

div.notify {
    background-color: #ffc;
    background-image: url(/wiki/pm/lib/styles/../images/notify.png);
    border-color: #eeb;
}

/* modal windows */
.JSpopup,
#link__wiz {
    position: absolute;
    background-color: #fff;
    color: #000;
    z-index: 20;
    overflow: hidden;
}

#link__wiz .ui-dialog-content {
    padding-left: 0;
    padding-right: 0;
}

/* media manager popup toggle buttons */

#media__popup_content button.button {
    border: 1px outset;
}

#media__popup_content button.selected {
    border-style: inset;
}

/* hide something accessibly
   (e.g. for screen readers or to keep access keys working) */
.a11y {
    position: absolute !important;
    left: -99999em !important;
    top: auto !important;
    width: 1px !important;
    height: 1px !important;
    overflow: hidden !important;
}
[dir=rtl] .a11y {
    left: auto !important;
    right: -99999em !important;
}

/* syntax highlighting code */
.code .br0  { color: #66cc66; }
.code .co0  { color: #808080; font-style: italic; }
.code .co1  { color: #808080; font-style: italic; }
.code .co2  { color: #808080; font-style: italic; }
.code .co3  { color: #808080; }
.code .coMULTI  { color: #808080; font-style: italic; }
.code .es0  { color: #000099; font-weight: bold; }
.code .kw1  { color: #b1b100; }
.code .kw2  { color: #000000; font-weight: bold; }
.code .kw3  { color: #000066; }
.code .kw4  { color: #993333; }
.code .kw5  { color: #0000ff; }
.code .me1  { color: #006600; }
.code .me2  { color: #006600; }
.code .nu0  { color: #cc66cc; }
.code .re0  { color: #0000ff; }
.code .re1  { color: #0000ff; }
.code .re2  { color: #0000ff; }
.code .re3  { color: #ff3333; font-weight:bold; }
.code .re4  { color: #009999; }
.code .st0  { color: #ff0000; }
.code .sy0  { color: #66cc66; }
/*
 * jQuery UI CSS Framework 1.8.16
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Theming/API
 */

/* Layout helpers
----------------------------------*/
.ui-helper-hidden { display: none; }
.ui-helper-hidden-accessible { position: absolute !important; clip: rect(1px 1px 1px 1px); clip: rect(1px,1px,1px,1px); }
.ui-helper-reset { margin: 0; padding: 0; border: 0; outline: 0; line-height: 1.3; text-decoration: none; font-size: 100%; list-style: none; }
.ui-helper-clearfix:after { content: "."; display: block; height: 0; clear: both; visibility: hidden; }
.ui-helper-clearfix { display: inline-block; }
/* required comment for clearfix to work in Opera \*/
* html .ui-helper-clearfix { height:1%; }
.ui-helper-clearfix { display:block; }
/* end clearfix */
.ui-helper-zfix { width: 100%; height: 100%; top: 0; left: 0; position: absolute; opacity: 0; filter:Alpha(Opacity=0); }


/* Interaction Cues
----------------------------------*/
.ui-state-disabled { cursor: default !important; }


/* Icons
----------------------------------*/

/* states and images */
.ui-icon { display: block; text-indent: -99999px; overflow: hidden; background-repeat: no-repeat; }


/* Misc visuals
----------------------------------*/

/* Overlays */
.ui-widget-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }


/*
 * jQuery UI CSS Framework 1.8.16
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Theming/API
 *
 * To view and modify this theme, visit http://jqueryui.com/themeroller/?ffDefault=Verdana,Arial,sans-serif&fwDefault=normal&fsDefault=1.1em&cornerRadius=4px&bgColorHeader=cccccc&bgTextureHeader=03_highlight_soft.png&bgImgOpacityHeader=75&borderColorHeader=aaaaaa&fcHeader=222222&iconColorHeader=222222&bgColorContent=ffffff&bgTextureContent=01_flat.png&bgImgOpacityContent=75&borderColorContent=aaaaaa&fcContent=222222&iconColorContent=222222&bgColorDefault=e6e6e6&bgTextureDefault=02_glass.png&bgImgOpacityDefault=75&borderColorDefault=d3d3d3&fcDefault=555555&iconColorDefault=888888&bgColorHover=dadada&bgTextureHover=02_glass.png&bgImgOpacityHover=75&borderColorHover=999999&fcHover=212121&iconColorHover=454545&bgColorActive=ffffff&bgTextureActive=02_glass.png&bgImgOpacityActive=65&borderColorActive=aaaaaa&fcActive=212121&iconColorActive=454545&bgColorHighlight=fbf9ee&bgTextureHighlight=02_glass.png&bgImgOpacityHighlight=55&borderColorHighlight=fcefa1&fcHighlight=363636&iconColorHighlight=2e83ff&bgColorError=fef1ec&bgTextureError=02_glass.png&bgImgOpacityError=95&borderColorError=cd0a0a&fcError=cd0a0a&iconColorError=cd0a0a&bgColorOverlay=aaaaaa&bgTextureOverlay=01_flat.png&bgImgOpacityOverlay=0&opacityOverlay=30&bgColorShadow=aaaaaa&bgTextureShadow=01_flat.png&bgImgOpacityShadow=0&opacityShadow=30&thicknessShadow=8px&offsetTopShadow=-8px&offsetLeftShadow=-8px&cornerRadiusShadow=8px
 */


/* Component containers
----------------------------------*/
.ui-widget { font-size: 1.1em; }
.ui-widget .ui-widget { font-size: 1em; }
.ui-widget input, .ui-widget select, .ui-widget textarea, .ui-widget button { font-size: 1em; }
.ui-widget-content { border: 1px solid #aaaaaa; background: #ffffff url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-bg_flat_75_ffffff_40x100.png) 50% 50% repeat-x; color: #222222; }
.ui-widget-content a { color: #222222; }
.ui-widget-header { border: 1px solid #aaaaaa; background: #cccccc url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-bg_highlight-soft_75_cccccc_1x100.png) 50% 50% repeat-x; color: #222222; font-weight: bold; }
.ui-widget-header a { color: #222222; }

/* Interaction states
----------------------------------*/
.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default { border: 1px solid #d3d3d3; background: #e6e6e6 url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-bg_glass_75_e6e6e6_1x400.png) 50% 50% repeat-x; font-weight: normal; color: #555555; }
.ui-state-default a, .ui-state-default a:link, .ui-state-default a:visited { color: #555555; text-decoration: none; }
.ui-state-hover, .ui-widget-content .ui-state-hover, .ui-widget-header .ui-state-hover, .ui-state-focus, .ui-widget-content .ui-state-focus, .ui-widget-header .ui-state-focus { border: 1px solid #999999; background: #dadada url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-bg_glass_75_dadada_1x400.png) 50% 50% repeat-x; font-weight: normal; color: #212121; }
.ui-state-hover a, .ui-state-hover a:hover { color: #212121; text-decoration: none; }
.ui-state-active, .ui-widget-content .ui-state-active, .ui-widget-header .ui-state-active { border: 1px solid #aaaaaa; background: #ffffff url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-bg_glass_65_ffffff_1x400.png) 50% 50% repeat-x; font-weight: normal; color: #212121; }
.ui-state-active a, .ui-state-active a:link, .ui-state-active a:visited { color: #212121; text-decoration: none; }
.ui-widget :active { outline: none; }

/* Interaction Cues
----------------------------------*/
.ui-state-highlight, .ui-widget-content .ui-state-highlight, .ui-widget-header .ui-state-highlight  {border: 1px solid #fcefa1; background: #fbf9ee url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-bg_glass_55_fbf9ee_1x400.png) 50% 50% repeat-x; color: #363636; }
.ui-state-highlight a, .ui-widget-content .ui-state-highlight a,.ui-widget-header .ui-state-highlight a { color: #363636; }
.ui-state-error, .ui-widget-content .ui-state-error, .ui-widget-header .ui-state-error {border: 1px solid #cd0a0a; background: #fef1ec url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-bg_glass_95_fef1ec_1x400.png) 50% 50% repeat-x; color: #cd0a0a; }
.ui-state-error a, .ui-widget-content .ui-state-error a, .ui-widget-header .ui-state-error a { color: #cd0a0a; }
.ui-state-error-text, .ui-widget-content .ui-state-error-text, .ui-widget-header .ui-state-error-text { color: #cd0a0a; }
.ui-priority-primary, .ui-widget-content .ui-priority-primary, .ui-widget-header .ui-priority-primary { font-weight: bold; }
.ui-priority-secondary, .ui-widget-content .ui-priority-secondary,  .ui-widget-header .ui-priority-secondary { opacity: .7; filter:Alpha(Opacity=70); font-weight: normal; }
.ui-state-disabled, .ui-widget-content .ui-state-disabled, .ui-widget-header .ui-state-disabled { opacity: .35; filter:Alpha(Opacity=35); background-image: none; }

/* Icons
----------------------------------*/

/* states and images */
.ui-icon { width: 16px; height: 16px; background-image: url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-icons_222222_256x240.png); }
.ui-widget-content .ui-icon {background-image: url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-icons_222222_256x240.png); }
.ui-widget-header .ui-icon {background-image: url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-icons_222222_256x240.png); }
.ui-state-default .ui-icon { background-image: url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-icons_888888_256x240.png); }
.ui-state-hover .ui-icon, .ui-state-focus .ui-icon {background-image: url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-icons_454545_256x240.png); }
.ui-state-active .ui-icon {background-image: url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-icons_454545_256x240.png); }
.ui-state-highlight .ui-icon {background-image: url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-icons_2e83ff_256x240.png); }
.ui-state-error .ui-icon, .ui-state-error-text .ui-icon {background-image: url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-icons_cd0a0a_256x240.png); }

/* positioning */
.ui-icon-carat-1-n { background-position: 0 0; }
.ui-icon-carat-1-ne { background-position: -16px 0; }
.ui-icon-carat-1-e { background-position: -32px 0; }
.ui-icon-carat-1-se { background-position: -48px 0; }
.ui-icon-carat-1-s { background-position: -64px 0; }
.ui-icon-carat-1-sw { background-position: -80px 0; }
.ui-icon-carat-1-w { background-position: -96px 0; }
.ui-icon-carat-1-nw { background-position: -112px 0; }
.ui-icon-carat-2-n-s { background-position: -128px 0; }
.ui-icon-carat-2-e-w { background-position: -144px 0; }
.ui-icon-triangle-1-n { background-position: 0 -16px; }
.ui-icon-triangle-1-ne { background-position: -16px -16px; }
.ui-icon-triangle-1-e { background-position: -32px -16px; }
.ui-icon-triangle-1-se { background-position: -48px -16px; }
.ui-icon-triangle-1-s { background-position: -64px -16px; }
.ui-icon-triangle-1-sw { background-position: -80px -16px; }
.ui-icon-triangle-1-w { background-position: -96px -16px; }
.ui-icon-triangle-1-nw { background-position: -112px -16px; }
.ui-icon-triangle-2-n-s { background-position: -128px -16px; }
.ui-icon-triangle-2-e-w { background-position: -144px -16px; }
.ui-icon-arrow-1-n { background-position: 0 -32px; }
.ui-icon-arrow-1-ne { background-position: -16px -32px; }
.ui-icon-arrow-1-e { background-position: -32px -32px; }
.ui-icon-arrow-1-se { background-position: -48px -32px; }
.ui-icon-arrow-1-s { background-position: -64px -32px; }
.ui-icon-arrow-1-sw { background-position: -80px -32px; }
.ui-icon-arrow-1-w { background-position: -96px -32px; }
.ui-icon-arrow-1-nw { background-position: -112px -32px; }
.ui-icon-arrow-2-n-s { background-position: -128px -32px; }
.ui-icon-arrow-2-ne-sw { background-position: -144px -32px; }
.ui-icon-arrow-2-e-w { background-position: -160px -32px; }
.ui-icon-arrow-2-se-nw { background-position: -176px -32px; }
.ui-icon-arrowstop-1-n { background-position: -192px -32px; }
.ui-icon-arrowstop-1-e { background-position: -208px -32px; }
.ui-icon-arrowstop-1-s { background-position: -224px -32px; }
.ui-icon-arrowstop-1-w { background-position: -240px -32px; }
.ui-icon-arrowthick-1-n { background-position: 0 -48px; }
.ui-icon-arrowthick-1-ne { background-position: -16px -48px; }
.ui-icon-arrowthick-1-e { background-position: -32px -48px; }
.ui-icon-arrowthick-1-se { background-position: -48px -48px; }
.ui-icon-arrowthick-1-s { background-position: -64px -48px; }
.ui-icon-arrowthick-1-sw { background-position: -80px -48px; }
.ui-icon-arrowthick-1-w { background-position: -96px -48px; }
.ui-icon-arrowthick-1-nw { background-position: -112px -48px; }
.ui-icon-arrowthick-2-n-s { background-position: -128px -48px; }
.ui-icon-arrowthick-2-ne-sw { background-position: -144px -48px; }
.ui-icon-arrowthick-2-e-w { background-position: -160px -48px; }
.ui-icon-arrowthick-2-se-nw { background-position: -176px -48px; }
.ui-icon-arrowthickstop-1-n { background-position: -192px -48px; }
.ui-icon-arrowthickstop-1-e { background-position: -208px -48px; }
.ui-icon-arrowthickstop-1-s { background-position: -224px -48px; }
.ui-icon-arrowthickstop-1-w { background-position: -240px -48px; }
.ui-icon-arrowreturnthick-1-w { background-position: 0 -64px; }
.ui-icon-arrowreturnthick-1-n { background-position: -16px -64px; }
.ui-icon-arrowreturnthick-1-e { background-position: -32px -64px; }
.ui-icon-arrowreturnthick-1-s { background-position: -48px -64px; }
.ui-icon-arrowreturn-1-w { background-position: -64px -64px; }
.ui-icon-arrowreturn-1-n { background-position: -80px -64px; }
.ui-icon-arrowreturn-1-e { background-position: -96px -64px; }
.ui-icon-arrowreturn-1-s { background-position: -112px -64px; }
.ui-icon-arrowrefresh-1-w { background-position: -128px -64px; }
.ui-icon-arrowrefresh-1-n { background-position: -144px -64px; }
.ui-icon-arrowrefresh-1-e { background-position: -160px -64px; }
.ui-icon-arrowrefresh-1-s { background-position: -176px -64px; }
.ui-icon-arrow-4 { background-position: 0 -80px; }
.ui-icon-arrow-4-diag { background-position: -16px -80px; }
.ui-icon-extlink { background-position: -32px -80px; }
.ui-icon-newwin { background-position: -48px -80px; }
.ui-icon-refresh { background-position: -64px -80px; }
.ui-icon-shuffle { background-position: -80px -80px; }
.ui-icon-transfer-e-w { background-position: -96px -80px; }
.ui-icon-transferthick-e-w { background-position: -112px -80px; }
.ui-icon-folder-collapsed { background-position: 0 -96px; }
.ui-icon-folder-open { background-position: -16px -96px; }
.ui-icon-document { background-position: -32px -96px; }
.ui-icon-document-b { background-position: -48px -96px; }
.ui-icon-note { background-position: -64px -96px; }
.ui-icon-mail-closed { background-position: -80px -96px; }
.ui-icon-mail-open { background-position: -96px -96px; }
.ui-icon-suitcase { background-position: -112px -96px; }
.ui-icon-comment { background-position: -128px -96px; }
.ui-icon-person { background-position: -144px -96px; }
.ui-icon-print { background-position: -160px -96px; }
.ui-icon-trash { background-position: -176px -96px; }
.ui-icon-locked { background-position: -192px -96px; }
.ui-icon-unlocked { background-position: -208px -96px; }
.ui-icon-bookmark { background-position: -224px -96px; }
.ui-icon-tag { background-position: -240px -96px; }
.ui-icon-home { background-position: 0 -112px; }
.ui-icon-flag { background-position: -16px -112px; }
.ui-icon-calendar { background-position: -32px -112px; }
.ui-icon-cart { background-position: -48px -112px; }
.ui-icon-pencil { background-position: -64px -112px; }
.ui-icon-clock { background-position: -80px -112px; }
.ui-icon-disk { background-position: -96px -112px; }
.ui-icon-calculator { background-position: -112px -112px; }
.ui-icon-zoomin { background-position: -128px -112px; }
.ui-icon-zoomout { background-position: -144px -112px; }
.ui-icon-search { background-position: -160px -112px; }
.ui-icon-wrench { background-position: -176px -112px; }
.ui-icon-gear { background-position: -192px -112px; }
.ui-icon-heart { background-position: -208px -112px; }
.ui-icon-star { background-position: -224px -112px; }
.ui-icon-link { background-position: -240px -112px; }
.ui-icon-cancel { background-position: 0 -128px; }
.ui-icon-plus { background-position: -16px -128px; }
.ui-icon-plusthick { background-position: -32px -128px; }
.ui-icon-minus { background-position: -48px -128px; }
.ui-icon-minusthick { background-position: -64px -128px; }
.ui-icon-close { background-position: -80px -128px; }
.ui-icon-closethick { background-position: -96px -128px; }
.ui-icon-key { background-position: -112px -128px; }
.ui-icon-lightbulb { background-position: -128px -128px; }
.ui-icon-scissors { background-position: -144px -128px; }
.ui-icon-clipboard { background-position: -160px -128px; }
.ui-icon-copy { background-position: -176px -128px; }
.ui-icon-contact { background-position: -192px -128px; }
.ui-icon-image { background-position: -208px -128px; }
.ui-icon-video { background-position: -224px -128px; }
.ui-icon-script { background-position: -240px -128px; }
.ui-icon-alert { background-position: 0 -144px; }
.ui-icon-info { background-position: -16px -144px; }
.ui-icon-notice { background-position: -32px -144px; }
.ui-icon-help { background-position: -48px -144px; }
.ui-icon-check { background-position: -64px -144px; }
.ui-icon-bullet { background-position: -80px -144px; }
.ui-icon-radio-off { background-position: -96px -144px; }
.ui-icon-radio-on { background-position: -112px -144px; }
.ui-icon-pin-w { background-position: -128px -144px; }
.ui-icon-pin-s { background-position: -144px -144px; }
.ui-icon-play { background-position: 0 -160px; }
.ui-icon-pause { background-position: -16px -160px; }
.ui-icon-seek-next { background-position: -32px -160px; }
.ui-icon-seek-prev { background-position: -48px -160px; }
.ui-icon-seek-end { background-position: -64px -160px; }
.ui-icon-seek-start { background-position: -80px -160px; }
/* ui-icon-seek-first is deprecated, use ui-icon-seek-start instead */
.ui-icon-seek-first { background-position: -80px -160px; }
.ui-icon-stop { background-position: -96px -160px; }
.ui-icon-eject { background-position: -112px -160px; }
.ui-icon-volume-off { background-position: -128px -160px; }
.ui-icon-volume-on { background-position: -144px -160px; }
.ui-icon-power { background-position: 0 -176px; }
.ui-icon-signal-diag { background-position: -16px -176px; }
.ui-icon-signal { background-position: -32px -176px; }
.ui-icon-battery-0 { background-position: -48px -176px; }
.ui-icon-battery-1 { background-position: -64px -176px; }
.ui-icon-battery-2 { background-position: -80px -176px; }
.ui-icon-battery-3 { background-position: -96px -176px; }
.ui-icon-circle-plus { background-position: 0 -192px; }
.ui-icon-circle-minus { background-position: -16px -192px; }
.ui-icon-circle-close { background-position: -32px -192px; }
.ui-icon-circle-triangle-e { background-position: -48px -192px; }
.ui-icon-circle-triangle-s { background-position: -64px -192px; }
.ui-icon-circle-triangle-w { background-position: -80px -192px; }
.ui-icon-circle-triangle-n { background-position: -96px -192px; }
.ui-icon-circle-arrow-e { background-position: -112px -192px; }
.ui-icon-circle-arrow-s { background-position: -128px -192px; }
.ui-icon-circle-arrow-w { background-position: -144px -192px; }
.ui-icon-circle-arrow-n { background-position: -160px -192px; }
.ui-icon-circle-zoomin { background-position: -176px -192px; }
.ui-icon-circle-zoomout { background-position: -192px -192px; }
.ui-icon-circle-check { background-position: -208px -192px; }
.ui-icon-circlesmall-plus { background-position: 0 -208px; }
.ui-icon-circlesmall-minus { background-position: -16px -208px; }
.ui-icon-circlesmall-close { background-position: -32px -208px; }
.ui-icon-squaresmall-plus { background-position: -48px -208px; }
.ui-icon-squaresmall-minus { background-position: -64px -208px; }
.ui-icon-squaresmall-close { background-position: -80px -208px; }
.ui-icon-grip-dotted-vertical { background-position: 0 -224px; }
.ui-icon-grip-dotted-horizontal { background-position: -16px -224px; }
.ui-icon-grip-solid-vertical { background-position: -32px -224px; }
.ui-icon-grip-solid-horizontal { background-position: -48px -224px; }
.ui-icon-gripsmall-diagonal-se { background-position: -64px -224px; }
.ui-icon-grip-diagonal-se { background-position: -80px -224px; }


/* Misc visuals
----------------------------------*/

/* Corner radius */
.ui-corner-all, .ui-corner-top, .ui-corner-left, .ui-corner-tl { -moz-border-radius-topleft: 4px; -webkit-border-top-left-radius: 4px; -khtml-border-top-left-radius: 4px; border-top-left-radius: 4px; }
.ui-corner-all, .ui-corner-top, .ui-corner-right, .ui-corner-tr { -moz-border-radius-topright: 4px; -webkit-border-top-right-radius: 4px; -khtml-border-top-right-radius: 4px; border-top-right-radius: 4px; }
.ui-corner-all, .ui-corner-bottom, .ui-corner-left, .ui-corner-bl { -moz-border-radius-bottomleft: 4px; -webkit-border-bottom-left-radius: 4px; -khtml-border-bottom-left-radius: 4px; border-bottom-left-radius: 4px; }
.ui-corner-all, .ui-corner-bottom, .ui-corner-right, .ui-corner-br { -moz-border-radius-bottomright: 4px; -webkit-border-bottom-right-radius: 4px; -khtml-border-bottom-right-radius: 4px; border-bottom-right-radius: 4px; }

/* Overlays */
.ui-widget-overlay { background: #aaaaaa url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-bg_flat_0_aaaaaa_40x100.png) 50% 50% repeat-x; opacity: .30;filter:Alpha(Opacity=30); }
.ui-widget-shadow { margin: -8px 0 0 -8px; padding: 8px; background: #aaaaaa url(/wiki/pm/lib/scripts/jquery/jquery-ui-theme/images/ui-bg_flat_0_aaaaaa_40x100.png) 50% 50% repeat-x; opacity: .30;filter:Alpha(Opacity=30); -moz-border-radius: 8px; -khtml-border-radius: 8px; -webkit-border-radius: 8px; border-radius: 8px; }/*
 * jQuery UI Resizable 1.8.16
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Resizable#theming
 */
.ui-resizable { position: relative;}
.ui-resizable-handle { position: absolute;font-size: 0.1px;z-index: 99999; display: block; }
.ui-resizable-disabled .ui-resizable-handle, .ui-resizable-autohide .ui-resizable-handle { display: none; }
.ui-resizable-n { cursor: n-resize; height: 7px; width: 100%; top: -5px; left: 0; }
.ui-resizable-s { cursor: s-resize; height: 7px; width: 100%; bottom: -5px; left: 0; }
.ui-resizable-e { cursor: e-resize; width: 7px; right: -5px; top: 0; height: 100%; }
.ui-resizable-w { cursor: w-resize; width: 7px; left: -5px; top: 0; height: 100%; }
.ui-resizable-se { cursor: se-resize; width: 12px; height: 12px; right: 1px; bottom: 1px; }
.ui-resizable-sw { cursor: sw-resize; width: 9px; height: 9px; left: -5px; bottom: -5px; }
.ui-resizable-nw { cursor: nw-resize; width: 9px; height: 9px; left: -5px; top: -5px; }
.ui-resizable-ne { cursor: ne-resize; width: 9px; height: 9px; right: -5px; top: -5px;}/*
 * jQuery UI Selectable 1.8.16
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Selectable#theming
 */
.ui-selectable-helper { position: absolute; z-index: 100; border:1px dotted black; }
/*
 * jQuery UI Accordion 1.8.16
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Accordion#theming
 */
/* IE/Win - Fix animation bug - #4615 */
.ui-accordion { width: 100%; }
.ui-accordion .ui-accordion-header { cursor: pointer; position: relative; margin-top: 1px; zoom: 1; }
.ui-accordion .ui-accordion-li-fix { display: inline; }
.ui-accordion .ui-accordion-header-active { border-bottom: 0 !important; }
.ui-accordion .ui-accordion-header a { display: block; font-size: 1em; padding: .5em .5em .5em .7em; }
.ui-accordion-icons .ui-accordion-header a { padding-left: 2.2em; }
.ui-accordion .ui-accordion-header .ui-icon { position: absolute; left: .5em; top: 50%; margin-top: -8px; }
.ui-accordion .ui-accordion-content { padding: 1em 2.2em; border-top: 0; margin-top: -2px; position: relative; top: 1px; margin-bottom: 2px; overflow: auto; display: none; zoom: 1; }
.ui-accordion .ui-accordion-content-active { display: block; }
/*
 * jQuery UI Autocomplete 1.8.16
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Autocomplete#theming
 */
.ui-autocomplete { position: absolute; cursor: default; }	

/* workarounds */
* html .ui-autocomplete { width:1px; } /* without this, the menu expands to 100% in IE6 */

/*
 * jQuery UI Menu 1.8.16
 *
 * Copyright 2010, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Menu#theming
 */
.ui-menu {
	list-style:none;
	padding: 2px;
	margin: 0;
	display:block;
	float: left;
}
.ui-menu .ui-menu {
	margin-top: -3px;
}
.ui-menu .ui-menu-item {
	margin:0;
	padding: 0;
	zoom: 1;
	float: left;
	clear: left;
	width: 100%;
}
.ui-menu .ui-menu-item a {
	text-decoration:none;
	display:block;
	padding:.2em .4em;
	line-height:1.5;
	zoom:1;
}
.ui-menu .ui-menu-item a.ui-state-hover,
.ui-menu .ui-menu-item a.ui-state-active {
	font-weight: normal;
	margin: -1px;
}
/*
 * jQuery UI Button 1.8.16
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Button#theming
 */
.ui-button { display: inline-block; position: relative; padding: 0; margin-right: .1em; text-decoration: none !important; cursor: pointer; text-align: center; zoom: 1; overflow: visible; } /* the overflow property removes extra width in IE */
.ui-button-icon-only { width: 2.2em; } /* to make room for the icon, a width needs to be set here */
button.ui-button-icon-only { width: 2.4em; } /* button elements seem to need a little more width */
.ui-button-icons-only { width: 3.4em; } 
button.ui-button-icons-only { width: 3.7em; } 

/*button text element */
.ui-button .ui-button-text { display: block; line-height: 1.4;  }
.ui-button-text-only .ui-button-text { padding: .4em 1em; }
.ui-button-icon-only .ui-button-text, .ui-button-icons-only .ui-button-text { padding: .4em; text-indent: -9999999px; }
.ui-button-text-icon-primary .ui-button-text, .ui-button-text-icons .ui-button-text { padding: .4em 1em .4em 2.1em; }
.ui-button-text-icon-secondary .ui-button-text, .ui-button-text-icons .ui-button-text { padding: .4em 2.1em .4em 1em; }
.ui-button-text-icons .ui-button-text { padding-left: 2.1em; padding-right: 2.1em; }
/* no icon support for input elements, provide padding by default */
input.ui-button { padding: .4em 1em; }

/*button icon element(s) */
.ui-button-icon-only .ui-icon, .ui-button-text-icon-primary .ui-icon, .ui-button-text-icon-secondary .ui-icon, .ui-button-text-icons .ui-icon, .ui-button-icons-only .ui-icon { position: absolute; top: 50%; margin-top: -8px; }
.ui-button-icon-only .ui-icon { left: 50%; margin-left: -8px; }
.ui-button-text-icon-primary .ui-button-icon-primary, .ui-button-text-icons .ui-button-icon-primary, .ui-button-icons-only .ui-button-icon-primary { left: .5em; }
.ui-button-text-icon-secondary .ui-button-icon-secondary, .ui-button-text-icons .ui-button-icon-secondary, .ui-button-icons-only .ui-button-icon-secondary { right: .5em; }
.ui-button-text-icons .ui-button-icon-secondary, .ui-button-icons-only .ui-button-icon-secondary { right: .5em; }

/*button sets*/
.ui-buttonset { margin-right: 7px; }
.ui-buttonset .ui-button { margin-left: 0; margin-right: -.3em; }

/* workarounds */
button.ui-button::-moz-focus-inner { border: 0; padding: 0; } /* reset extra padding in Firefox */
/*
 * jQuery UI Dialog 1.8.16
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Dialog#theming
 */
.ui-dialog { position: absolute; padding: .2em; width: 300px; overflow: hidden; }
.ui-dialog .ui-dialog-titlebar { padding: .4em 1em; position: relative;  }
.ui-dialog .ui-dialog-title { float: left; margin: .1em 16px .1em 0; } 
.ui-dialog .ui-dialog-titlebar-close { position: absolute; right: .3em; top: 50%; width: 19px; margin: -10px 0 0 0; padding: 1px; height: 18px; }
.ui-dialog .ui-dialog-titlebar-close span { display: block; margin: 1px; }
.ui-dialog .ui-dialog-titlebar-close:hover, .ui-dialog .ui-dialog-titlebar-close:focus { padding: 0; }
.ui-dialog .ui-dialog-content { position: relative; border: 0; padding: .5em 1em; background: none; overflow: auto; zoom: 1; }
.ui-dialog .ui-dialog-buttonpane { text-align: left; border-width: 1px 0 0 0; background-image: none; margin: .5em 0 0 0; padding: .3em 1em .5em .4em; }
.ui-dialog .ui-dialog-buttonpane .ui-dialog-buttonset { float: right; }
.ui-dialog .ui-dialog-buttonpane button { margin: .5em .4em .5em 0; cursor: pointer; }
.ui-dialog .ui-resizable-se { width: 14px; height: 14px; right: 3px; bottom: 3px; }
.ui-draggable .ui-dialog-titlebar { cursor: move; }
/*
 * jQuery UI Slider 1.8.16
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Slider#theming
 */
.ui-slider { position: relative; text-align: left; }
.ui-slider .ui-slider-handle { position: absolute; z-index: 2; width: 1.2em; height: 1.2em; cursor: default; }
.ui-slider .ui-slider-range { position: absolute; z-index: 1; font-size: .7em; display: block; border: 0; background-position: 0 0; }

.ui-slider-horizontal { height: .8em; }
.ui-slider-horizontal .ui-slider-handle { top: -.3em; margin-left: -.6em; }
.ui-slider-horizontal .ui-slider-range { top: 0; height: 100%; }
.ui-slider-horizontal .ui-slider-range-min { left: 0; }
.ui-slider-horizontal .ui-slider-range-max { right: 0; }

.ui-slider-vertical { width: .8em; height: 100px; }
.ui-slider-vertical .ui-slider-handle { left: -.3em; margin-left: 0; margin-bottom: -.6em; }
.ui-slider-vertical .ui-slider-range { left: 0; width: 100%; }
.ui-slider-vertical .ui-slider-range-min { bottom: 0; }
.ui-slider-vertical .ui-slider-range-max { top: 0; }/*
 * jQuery UI Tabs 1.8.16
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Tabs#theming
 */
.ui-tabs { position: relative; padding: .2em; zoom: 1; } /* position: relative prevents IE scroll bug (element with position: relative inside container with overflow: auto appear as "fixed") */
.ui-tabs .ui-tabs-nav { margin: 0; padding: .2em .2em 0; }
.ui-tabs .ui-tabs-nav li { list-style: none; float: left; position: relative; top: 1px; margin: 0 .2em 1px 0; border-bottom: 0 !important; padding: 0; white-space: nowrap; }
.ui-tabs .ui-tabs-nav li a { float: left; padding: .5em 1em; text-decoration: none; }
.ui-tabs .ui-tabs-nav li.ui-tabs-selected { margin-bottom: 0; padding-bottom: 1px; }
.ui-tabs .ui-tabs-nav li.ui-tabs-selected a, .ui-tabs .ui-tabs-nav li.ui-state-disabled a, .ui-tabs .ui-tabs-nav li.ui-state-processing a { cursor: text; }
.ui-tabs .ui-tabs-nav li a, .ui-tabs.ui-tabs-collapsible .ui-tabs-nav li.ui-tabs-selected a { cursor: pointer; } /* first selector in group seems obsolete, but required to overcome bug in Opera applying cursor: text overall if defined elsewhere... */
.ui-tabs .ui-tabs-panel { display: block; border-width: 0; padding: 1em 1.4em; background: none; }
.ui-tabs .ui-tabs-hide { display: none !important; }
/*
 * jQuery UI Datepicker 1.8.16
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Datepicker#theming
 */
.ui-datepicker { width: 17em; padding: .2em .2em 0; display: none; }
.ui-datepicker .ui-datepicker-header { position:relative; padding:.2em 0; }
.ui-datepicker .ui-datepicker-prev, .ui-datepicker .ui-datepicker-next { position:absolute; top: 2px; width: 1.8em; height: 1.8em; }
.ui-datepicker .ui-datepicker-prev-hover, .ui-datepicker .ui-datepicker-next-hover { top: 1px; }
.ui-datepicker .ui-datepicker-prev { left:2px; }
.ui-datepicker .ui-datepicker-next { right:2px; }
.ui-datepicker .ui-datepicker-prev-hover { left:1px; }
.ui-datepicker .ui-datepicker-next-hover { right:1px; }
.ui-datepicker .ui-datepicker-prev span, .ui-datepicker .ui-datepicker-next span { display: block; position: absolute; left: 50%; margin-left: -8px; top: 50%; margin-top: -8px;  }
.ui-datepicker .ui-datepicker-title { margin: 0 2.3em; line-height: 1.8em; text-align: center; }
.ui-datepicker .ui-datepicker-title select { font-size:1em; margin:1px 0; }
.ui-datepicker select.ui-datepicker-month-year {width: 100%;}
.ui-datepicker select.ui-datepicker-month, 
.ui-datepicker select.ui-datepicker-year { width: 49%;}
.ui-datepicker table {width: 100%; font-size: .9em; border-collapse: collapse; margin:0 0 .4em; }
.ui-datepicker th { padding: .7em .3em; text-align: center; font-weight: bold; border: 0;  }
.ui-datepicker td { border: 0; padding: 1px; }
.ui-datepicker td span, .ui-datepicker td a { display: block; padding: .2em; text-align: right; text-decoration: none; }
.ui-datepicker .ui-datepicker-buttonpane { background-image: none; margin: .7em 0 0 0; padding:0 .2em; border-left: 0; border-right: 0; border-bottom: 0; }
.ui-datepicker .ui-datepicker-buttonpane button { float: right; margin: .5em .2em .4em; cursor: pointer; padding: .2em .6em .3em .6em; width:auto; overflow:visible; }
.ui-datepicker .ui-datepicker-buttonpane button.ui-datepicker-current { float:left; }

/* with multiple calendars */
.ui-datepicker.ui-datepicker-multi { width:auto; }
.ui-datepicker-multi .ui-datepicker-group { float:left; }
.ui-datepicker-multi .ui-datepicker-group table { width:95%; margin:0 auto .4em; }
.ui-datepicker-multi-2 .ui-datepicker-group { width:50%; }
.ui-datepicker-multi-3 .ui-datepicker-group { width:33.3%; }
.ui-datepicker-multi-4 .ui-datepicker-group { width:25%; }
.ui-datepicker-multi .ui-datepicker-group-last .ui-datepicker-header { border-left-width:0; }
.ui-datepicker-multi .ui-datepicker-group-middle .ui-datepicker-header { border-left-width:0; }
.ui-datepicker-multi .ui-datepicker-buttonpane { clear:left; }
.ui-datepicker-row-break { clear:both; width:100%; font-size:0em; }

/* RTL support */
.ui-datepicker-rtl { direction: rtl; }
.ui-datepicker-rtl .ui-datepicker-prev { right: 2px; left: auto; }
.ui-datepicker-rtl .ui-datepicker-next { left: 2px; right: auto; }
.ui-datepicker-rtl .ui-datepicker-prev:hover { right: 1px; left: auto; }
.ui-datepicker-rtl .ui-datepicker-next:hover { left: 1px; right: auto; }
.ui-datepicker-rtl .ui-datepicker-buttonpane { clear:right; }
.ui-datepicker-rtl .ui-datepicker-buttonpane button { float: left; }
.ui-datepicker-rtl .ui-datepicker-buttonpane button.ui-datepicker-current { float:right; }
.ui-datepicker-rtl .ui-datepicker-group { float:right; }
.ui-datepicker-rtl .ui-datepicker-group-last .ui-datepicker-header { border-right-width:0; border-left-width:1px; }
.ui-datepicker-rtl .ui-datepicker-group-middle .ui-datepicker-header { border-right-width:0; border-left-width:1px; }

/* IE6 IFRAME FIX (taken from datepicker 1.5.3 */
.ui-datepicker-cover {
    display: none; /*sorry for IE5*/
    display/**/: block; /*sorry for IE5*/
    position: absolute; /*must have*/
    z-index: -1; /*must have*/
    filter: mask(); /*must have*/
    top: -4px; /*must have*/
    left: -4px; /*must have*/
    width: 200px; /*must have*/
    height: 200px; /*must have*/
}/*
 * jQuery UI Progressbar 1.8.16
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Progressbar#theming
 */
.ui-progressbar { height:2em; text-align: left; }
.ui-progressbar .ui-progressbar-value {margin: -1px; height:100%; }.scheisse {}
/* this is some strange thing. If there is nothing on top of the 
   div.imgcaption, the centered images will not have a colored bounding box 
   and the image is left aligned.
   might be a bug of an older dokuwiki version.
 */


span.imgcaption {
    border: 1px solid #ccc;
    padding: 3px !important;
    background-color: #f9f9f9;  
    font-size: 94%;
    text-align: center;
    width: auto;
    overflow: hidden;
    margin: 1px auto;
    float: none;
    display: inline-block;
}

span.imgcaption.left {
    margin: 1px;
    float: left;
}
span.imgcaption.right {
    margin: 1px;
    float: right;
}
span.imgcaption_centerwrapper {
    display: block;
    text-align: center;
}

span.imgcaption a img {
    border: 1px solid #ccc;
    background-color:#FFFFFF;
}

div.dokuwiki .undercaption {
	 font-size: 95%;
     display: block;
}

div.dokuwiki .undercaption a:hover {
    text-decoration:none;
}

div.dokuwiki .undercaption span {
    background: url(/wiki/pm/lib/plugins/imagereference/./magnify-clip.png) no-repeat;
  
    margin:2px;
    padding-left:15px; 
    display:none;
}

div.dokuwiki span.imgcaption img.mediaright {
  float: none;
  margin: 0 0 0.5em 0;
}

div.dokuwiki span.imgcaption img.medialeft {
  float: none;
  margin: 0 0 0.5em 0;
}
/*
 * admin plugin extension - style additions
 *
 * @author  Christopher Smith  chris@jalakai.co.uk
 * @link    http://wiki.jalakai.co.uk/dokuwiki/doku.php/tutorials/adminplugin
 */

#plugin__manager h2 {
    margin-left: 0;
}

#plugin__manager form {
    display: block;
    margin: 0;
    padding: 0;
}

#plugin__manager legend {
    display: none;
}

#plugin__manager fieldset {
    width: auto;
}

#plugin__manager .button {
    margin: 0;
}

#plugin__manager p,
#plugin__manager label {
    text-align: left;
}

#plugin__manager .hidden {
    display: none;
}

#plugin__manager .new {
    background: #dee7ec;
}

/* IE won't understand but doesn't require it */
#plugin__manager input[disabled] {
    color: #ccc;
    border-color: #ccc;
}

#plugin__manager .pm_menu,
#plugin__manager .pm_info {
    margin-left: 0;
    text-align: left;
}

[dir=rtl] #plugin__manager .pm_menu,
[dir=rtl] #plugin__manager .pm_info,
[dir=rtl] #plugin__manager p,
[dir=rtl] #plugin__manager label {
    text-align: right;
}

#plugin__manager .pm_menu {
    float: left;
    width: 48%;
}
[dir=rtl] #plugin__manager .pm_menu {
    float: right;
}

#plugin__manager .pm_info {
    float: right;
    width: 50%;
}
[dir=rtl] #plugin__manager .pm_info {
    float: left;
}

#plugin__manager .common fieldset {
    margin: 0;
    padding: 0 0 1.0em 0;
    text-align: left;
    border: none;
}
[dir=rtl] #plugin__manager .common fieldset {
    text-align: right;
}

#plugin__manager .common label {
    padding: 0 0 0.5em 0;
}

#plugin__manager .common input.edit {
    width: 24em;
    margin: 0.5em;
}

#plugin__manager .plugins fieldset {
    color: #000;
    background: #fff;
    text-align: right;
    border-top: none;
    border-right: none;
    border-left: none;
}

#plugin__manager .plugins fieldset.protected {
    background: #fdd;
    color: #000;
}

#plugin__manager .plugins fieldset.disabled {
    background: #e0e0e0;
    color: #a8a8a8;
}

#plugin__manager .plugins .legend {
    color: #000;
    background: inherit;
    display: block;
    margin: 0;
    padding: 0;
    font-size: 1em;
    line-height: 1.4em;
    font-weight: normal;
    text-align: left;
    float: left;
    padding: 0;
    clear: none;
}
[dir=rtl] #plugin__manager .plugins .legend {
    text-align: right;
    float: right;
}

#plugin__manager .plugins .button {
    font-size: 95%;
}

#plugin__manager .plugins fieldset.buttons {
    border: none;
}

#plugin__manager .plugins fieldset.buttons .button {
    float: left;
}
[dir=rtl] #plugin__manager .plugins .button {
    float: left;
    margin-right: 0.5em;
}
[dir=rtl] #plugin__manager .plugins fieldset.buttons .button {
    float: right;
}

#plugin__manager .pm_info h3 {
    margin-left: 0;
}

#plugin__manager .pm_info dl {
    margin: 1em 0;
    padding: 0;
}

#plugin__manager .pm_info dt {
    width: 6em;
    float: left;
    clear: left;
    margin: 0;
    padding: 0;
}
[dir=rtl] #plugin__manager .pm_info dt {
    float: right;
    clear: right;
}

#plugin__manager .pm_info dd {
    margin: 0 0 0 7em;
    padding: 0;
    background: none;
}
[dir=rtl] #plugin__manager .pm_info dd {
    margin: 0 7em 0 0;
}

#plugin__manager .plugins .enable {
    float: left;
    width: auto;
    margin-right: 0.5em;
}
[dir=rtl] #plugin__manager .plugins .enable {
    float: right;
    margin-right: 0;
    margin-left: 0.5em;
}

/* end admin plugin styles */
/*--------------------------------------------------|
| dTree 2.05 | www.destroydrop.com/javascript/tree/ |
|---------------------------------------------------|
| Copyright (c) 2002-2003 Geir Landro               |
|--------------------------------------------------*/
/*
 a.nodeFdUrl	        Namespace with url link (headpage)	        js
 a.node 	        Namespace without url link        	        js
 a.nodeUrl	        Page	                                        js
 a.nodeSel 	        Last visited page            	                js
 a.navSel 	        Current page            	                js
 a.indexmenu_idx_head	link style of a namespace with url (headpage)	nojs
 a.indexmenu_idx	link style of a namespace without url	        nojs
 */ 

/* dtree properties. No need to change*/

.dtree {
  font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
  font-size: 11px;
  color: #333;
  white-space: nowrap;
  line-height: normal;
}

.dtree img {
  border: 0px;
  vertical-align: top;
}

/*Properties that can be edit*/

/*Link properties*/
.dtree a {
  color: #080;
  text-decoration: none;
}

/*Link properties*/
.dtree a.node, .dtree a.nodeSel a.navSel {
  white-space: nowrap;
  padding: 1px 2px 1px 2px;
}
/* Last visited page highlighting*/
.dtree a.nodeSel {
  background-color:  #eee;
}
/* Current page highlighting*/
.dtree a.navSel {
  background-color: #ff9;
}

/*
.dtree .clip {
}
*/

/*nojs tree div*/
.indexmenu_nojs {
  display: block;
}

/*Namespace without page link in nojs mode. !important has to be used*/
div.li a.indexmenu_idx {
  color: #d30 !important;
  text-decoration: none !important;
  font-weight: bold;
}

/*Namespace with page link (headpage) in nojs mode. !important has to be used*/

div.li a.indexmenu_idx_head {
  font-weight: bold;
}


/*Style for admin panel interface*/
div.dokuwiki div.indexmenu_list_themes { 
  clear: both;
  border-top: 2px solid #ccc;
  padding-left: 1em;
}

/*Mouseover property*/
.dtree a.nodeFdUrl:hover, .dtree a.nodeSel:hover, a.navSel:hover, .dtree a.nodeUrl:hover {
  color: #080;
  text-decoration: underline;
  background-color:  #eee;
}
/*Mouseover property*/
.dtree a.node:hover {
  text-decoration: none;
}

/*tocbullet property*/
.dtree .indexmenu_tocbullet {
  position:absolute;
  background: transparent url(/wiki/pm/lib/plugins/indexmenu/images/toc_bullet.gif) no-repeat scroll;
  vertical-align: middle;
  width: 11px;
  height: 11px;
}

/*scrolling arrow property*/
.dtree .indexmenu_larrow {
  position:absolute;
  filter:alpha(opacity=60);-moz-opacity:.60;opacity:.60;
  background:transparent url(/wiki/pm/lib/plugins/indexmenu/images/larrow.gif) repeat-y scroll;
  padding-left:22px;
  z-index:100;
}

/*toc property*/
.indexmenu_toc {
  font-size: 80%;
  line-height: 1.2em;
  white-space: normal;
  overflow: hidden;
  width: 200px !important;
  z-index:100 !important;
  word-wrap: break-word;
}

.indexmenu_toc .indexmenu_toc_inside {
  border: 1px solid #ccc;
  background-color: #fff;
  text-align: left;
  padding: 0.5em 0 0.7em 0;
  max-height: 300px;
  height: expression( this.scrollHeight > 300 ? "300px" : "auto" );
  overflow: auto;
}

.dtree .indexmenu_rarrow {
  position:absolute;
  background:white url(/wiki/pm/lib/plugins/indexmenu/images/rarrow.gif) no-repeat scroll;
  width:11px;
  height:15px;
}

.indexmenu_rmenu {
  position: absolute;
  z-index: 100;
  background-color: #fff;
  border: 1px solid black;
  font-size: 80%;
  line-height: 100%;
  padding-bottom: 5px;
}

.indexmenu_rmenuhead {
  background-color: #CCFFCC;
  border-bottom: 1px solid #333;
  color: #333;
  font-size: 90%;
  margin: 0pt;
  text-align: center;
  padding: 1px 5px;
  vertical-align: middle;                       
  overflow: hidden;
  width: 80px;
}

.indexmenu_rmenu ul,.indexmenu_rmenu li {
  list-style-type: none !important;
  list-style-image: none !important;
  color: #000 !important;
  margin: 2px !important;
  text-align: center;
}

.indexmenu_rmenu a:hover {
  background-color: #000 !important;
  color: #fff !important;
}

.indexmenu_opts {
  font-size: 80%;
}

.dtree .emptynode {
  background: transparent url(/wiki/pm/lib/plugins/indexmenu/images/empty.gif) no-repeat scroll;
  display: inline;
  padding: 1px 8px;
  width: 16px;
  height: 16px;
  vertical-align: top;
  /* needed by ie7 */
  zoom: 1;
}
/**
 * style.css for Plugin hidden
 * 
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Guillaume Turri <guillaume.turri@gmail.com>
 *
 */

.hiddenHead{
  background-color:#eee;
}

.hiddenBody{
  border-top:1px solid #ccc;
  padding:1px;
}

.hiddenGlobal{
  border:1px solid #ccc;
}

.hiddenActive{
  cursor:pointer;
}

.hiddenOnHidden{
  display:none;
}

.hiddenOnVisible{
  display:none;
}

.hiddenElements{
  display:none;
}

div.hiddenGlobal div.hiddenHead p{
  margin:0;
}

table.info_hof {
	width:80%;
}

.hof_evenrow {
	background-color:__background_other__;
}
.hof_oddrow {
	background-color:#fff;
}
.hof_caption {
	font-weight:bold;
	font-size:120%;
	padding-bottom:4px;
}
.hof_row_pos {
	text-align:center;
	width:10%;
}
.hof_row_name {
	text-align:left;
}
.hof_row_num {
	text-align:right;
	width:15%;
}
p.contact_error, p.contact_success {
	display:block;
	padding:10px 10px 10px 10px;
	font-size: 13px;
	text-shadow: white 1px 1px;
}
p.contact_success {
	border: 1px solid #9bac55;
	background-color: #E5F993;
	color: #688006;
}
p.contact_error {
	border: 1px solid #e18484;
	background-color: #F6B9B9;
	color: #c32727;
}
input.error_field, textarea.error_field {
	border: 1px solid #e18484;
}
div.statdisplay-progress {
    width: 150px;
    height: 15px;
    background-color: #eee;
    border: 1px solid #999;
}

div.statdisplay-progress span {
    display: block;
    height: 100%;
    background-color: #999;
}/* plugin:dokutexitmanager */
#dokutexit__manager {margin: 1em;}
#dokutexit__manager div.success,
#dokutexit__manager div.error,
#dokutexit__manager div.info {
  background-position: 0.5em;
  padding: 0.5em;
  text-align:center
}

#dokutexit__manager form { }
#dokutexit__manager table {margin: 1em 0;}
#dokutexit__manager td input.edit {width: 30em;}
#dokutexit__manager td select.edit { }
#dokutexit__manager td textarea.edit {width: 27.5em; height: 4em;}

#dokutexit__manager tr.default .input,
#dokutexit__manager tr.default input,
#dokutexit__manager tr.default textarea,
#dokutexit__manager tr.default select {
  background-color: #ccddff;
}

#dokutexit__manager tr.protected .input,
#dokutexit__manager tr.protected input,
#dokutexit__manager tr.default textarea,
#dokutexit__manager tr.protected select {
  background-color: #ffcccc;
}

#dokutexit__manager td.error  {background-color: red;}

/* end plugin:dokutexitmanager */
/* User Manager specific styles */
#user__manager tr.disabled {
  color: #6f6f6f;
  background: #e4e4e4;
}
#user__manager tr.user_info {
  vertical-align: top;
}
#user__manager div.edit_user {
  width: 46%;
  float: left;
}
#user__manager table {
  margin-bottom: 1em;
}
#user__manager input.button[disabled] {
  color: #ccc!important;
  border-color: #ccc!important;
}
/* IE won't understand but doesn't require it */
div.quickstats {
color: black;
}
 
 /* This can be used to control the dimensions and overflow of the query output display */
#quickstats_admin_disp {
  /* width: 1024px;    */ 
   overflow:scroll; 
} 

/* This controls the overflow of the query form */
#qs_admin_form_div { overflow:scroll !important; }

div.quickstats.basics span.title, div.quickstats.ip span.title, div.quickstats.ua span.title {
color: black;
font-weight:bold;
font-size: 125%;
}

div.quickstats.ip {
    padding:2px;  
    clear:left;
    padding: 8px;  
    margin-left: 60px;  /* aligns with basics left alignment */
}
div.quickstats span.total {
       font-size:115%;       	   
       color:blue; 
}   
th.quickstats_sort {  
    pointer: hand;
    text-align:center;
    background-color: #eeeeee;
    }
 a.quickstats_sort_title  { /*color: blue !important; */}   /* this will change the color etc of the column titles */
 
div.quickstats.basics { padding:2px; }

/* partial settings for basic layout */
div.browsers_basics {width: 150px;}
div.pages_basics { width: 310px;  }

div.pages_basics { margin-left: 245px;  margin-top: 14px;}
div.countries_basics { 
  padding-right: 80px; 
  margin-top: 14px;
 width: 280px;  
 }

/* placeholders for individual css formatting */
div.quickstats.misc span.title, div.quickstats.page span.title, div.quickstats.countries span.title, div.quickstats.ua span.title {}
div.quickstats.misc { }
div.quickstats.pages {}
div.quickstats.countries { }
div.quickstats.ua {}

td.padded,th.padded { padding-left: 10px; padding-right: 10px; }
div.quick__stats td.divider { border-left: 1px solid black; }
div.quick__stats td.padded input { background-color: #ffffaa; }
div.quick__stats th.padded input { background-color: #ffffaa; }
div.quick__stats td.place_holder { }
div.quick__stats th.thead {
  border-bottom: 1px solid black; 
  padding-bottom: 4px;  padding-top: 4px;  
  text-align:center;
 }
caption.qs_cap { font-size: 125%;  font-weight: bold; color:white; background-color: gray;}
caption.qs_bold_left { text-align: left;  font-weight: bold; }

#qs_cache_panel,#quick__stats { display: none; }
#qs_query_intro { border: 1px blue solid;  padding:10px; margin-top: 10px; display: none;}
div.qs_brief table.qs_brief_table td { border-bottom: 1px solid black;  }

/*#extended_data { } */.noteclassic, .noteimportant, .notewarning, .notetip {
  margin: 2em;
  margin-left: auto;
  margin-right: auto;
  width: 70% !important;
  min-height: 40px;
  clear: both;
  text-align: justify;
  vertical-align: middle;
  border-collapse: collapse;
  padding: 15px 20px 15px 80px;
  background-position: 20px 50%;
  background-repeat: no-repeat;
  -moz-border-radius: 20px;
  -khtml-border-radius: 20px;
  border-radius: 20px;
}
 
.noteclassic {
  /*border: 1px solid #99D;*/
  background-color: #eef;
  background-image: url(/wiki/pm/lib/plugins/note/images/note.png);
}
 
.noteimportant {
  /*border: 1px solid #ff0;*/
  background-color: #ffc;
  background-image: url(/wiki/pm/lib/plugins/note/images/important.png);
}
 
.notewarning {
  /*border: 1px solid #d99;*/
  background-color: #fdd;
  background-image: url(/wiki/pm/lib/plugins/note/images/warning.png);
}
 
.notetip {
  /*border: 1px solid #9d9;*/
  background-color: #dfd;
  background-image: url(/wiki/pm/lib/plugins/note/images/tip.png);
}
/********************************************************************
Screen Styles for the Wrap Plugin (additional to all.css)
********************************************************************/

/* box
********************************************************************/

.dokuwiki .wrap_box {
    background: #eee;
    color: #333;
}
.dokuwiki div.wrap_box,
.dokuwiki div.wrap_danger, .dokuwiki div.wrap_warning, .dokuwiki div.wrap_caution, .dokuwiki div.wrap_notice, .dokuwiki div.wrap_safety {
    padding: 1em 1em .5em;
    margin-bottom: 1.5em;
    overflow: hidden;
}
.dokuwiki span.wrap_box,
.dokuwiki span.wrap_danger, .dokuwiki span.wrap_warning, .dokuwiki span.wrap_caution, .dokuwiki span.wrap_notice, .dokuwiki span.wrap_safety {
    padding: 0 .3em;
}

/*____________ notes with icons ____________*/

/* general styles for all note divs */
.dokuwiki div.wrap_info, .dokuwiki div.wrap_important, .dokuwiki div.wrap_alert, .dokuwiki div.wrap_tip, .dokuwiki div.wrap_help, .dokuwiki div.wrap_todo, .dokuwiki div.wrap_download {
    padding: 1em 1em .5em 70px;
    margin-bottom: 1.5em;
    min-height: 68px;
    background-position: 10px 50%;
    background-repeat: no-repeat;
    color: #000;
    overflow: hidden;
}
/* special treatment for IE6 */
* html .dokuwiki div.wrap_info, * html .dokuwiki div.wrap_important, * html .dokuwiki div.wrap_alert, * html .dokuwiki div.wrap_tip, * html .dokuwiki div.wrap_help, * html .dokuwiki div.wrap_todo, * html .dokuwiki div.wrap_download {
    height: 68px;
    overflow: visible;
}
/* general styles for all note spans */
.dokuwiki span.wrap_info, .dokuwiki span.wrap_important, .dokuwiki span.wrap_alert, .dokuwiki span.wrap_tip, .dokuwiki span.wrap_help, .dokuwiki span.wrap_todo, .dokuwiki span.wrap_download {
    padding: 0 2px 0 20px;
    min-height: 20px;
    background-position: 2px 50%;
    background-repeat: no-repeat;
    color: #000;
}
/* special treatment for IE6 */
* html .dokuwiki span.wrap_info, * html .dokuwiki span.wrap_important, * html .dokuwiki span.wrap_alert, * html .dokuwiki span.wrap_tip, * html .dokuwiki span.wrap_help, * html .dokuwiki span.wrap_todo, * html .dokuwiki span.wrap_download {
    height: 20px;
}

/*____________ info ____________*/
.dokuwiki .wrap_info { background-color: #d1d7df; }
.dokuwiki div.wrap_info { background-image: url(/wiki/pm/lib/plugins/wrap/images/note/48/info.png); }
.dokuwiki span.wrap_info { background-image: url(/wiki/pm/lib/plugins/wrap/images/note/16/info.png); }

/*____________ important ____________*/
.dokuwiki .wrap_important { background-color: #ffd39f; }
.dokuwiki div.wrap_important { background-image: url(/wiki/pm/lib/plugins/wrap/images/note/48/important.png); }
.dokuwiki span.wrap_important { background-image: url(/wiki/pm/lib/plugins/wrap/images/note/16/important.png); }

/*____________ alert ____________*/
.dokuwiki .wrap_alert { background-color: #ffbcaf; }
.dokuwiki div.wrap_alert { background-image: url(/wiki/pm/lib/plugins/wrap/images/note/48/alert.png); }
.dokuwiki span.wrap_alert { background-image: url(/wiki/pm/lib/plugins/wrap/images/note/16/alert.png); }

/*____________ tip ____________*/
.dokuwiki .wrap_tip { background-color: #fff79f; }
.dokuwiki div.wrap_tip { background-image: url(/wiki/pm/lib/plugins/wrap/images/note/48/tip.png); }
.dokuwiki span.wrap_tip { background-image: url(/wiki/pm/lib/plugins/wrap/images/note/16/tip.png); }

/*____________ help ____________*/
.dokuwiki .wrap_help { background-color: #dcc2ef; }
.dokuwiki div.wrap_help { background-image: url(/wiki/pm/lib/plugins/wrap/images/note/48/help.png); }
.dokuwiki span.wrap_help { background-image: url(/wiki/pm/lib/plugins/wrap/images/note/16/help.png); }

/*____________ todo ____________*/
.dokuwiki .wrap_todo { background-color: #c2efdd; }
.dokuwiki div.wrap_todo { background-image: url(/wiki/pm/lib/plugins/wrap/images/note/48/todo.png); }
.dokuwiki span.wrap_todo { background-image: url(/wiki/pm/lib/plugins/wrap/images/note/16/todo.png); }

/*____________ download ____________*/
.dokuwiki .wrap_download { background-color: #d6efc2; }
.dokuwiki div.wrap_download { background-image: url(/wiki/pm/lib/plugins/wrap/images/note/48/download.png); }
.dokuwiki span.wrap_download { background-image: url(/wiki/pm/lib/plugins/wrap/images/note/16/download.png); }


/*____________ safety notes ____________*/

.dokuwiki .wrap_danger {
    background-color: #c00;
    color: #fff;
}
.dokuwiki .wrap_warning {
    background-color: #f60;
    color: #000;
}
.dokuwiki .wrap_caution {
    background-color: #ff0;
    color: #000;
}
.dokuwiki .wrap_notice {
    background-color: #06f;
    color: #fff;
}
.dokuwiki .wrap_safety {
    background-color: #090;
    color: #fff;
}


/* mark
********************************************************************/

div.dokuwiki .wrap_hi {
    background-color: #ff9;
    overflow: hidden;
}

/* typography
********************************************************************

div.dokuwiki .wrap_fgwhite {
    color: #fff;
}

div.dokuwiki div.wrap_bgred, div.dokuwiki div.wrap_bggreen, div.dokuwiki div.wrap_bgblue, div.dokuwiki div.wrap_bgcyan, div.dokuwiki div.wrap_bgviolet, div.dokuwiki div.wrap_bgyellow, div.dokuwiki div.wrap_bggrey, div.dokuwiki div.wrap_bgwhite, div.dokuwiki div.wrap_bgblack {
    overflow: hidden;
}

div.dokuwiki .wrap_bgred {
    background-color: #fcc;
}
div.dokuwiki .wrap_bggreen {
    background-color: #cfc;
}
div.dokuwiki .wrap_bgblue {
    background-color: #ccf;
}
div.dokuwiki .wrap_bgcyan {
    background-color: #9ff;
}
div.dokuwiki .wrap_bgviolet {
    background-color: #f9f;
}
div.dokuwiki .wrap_bgyellow {
    background-color: #ff9;
}
div.dokuwiki .wrap_bggrey {
    background-color: #ccc;
}
div.dokuwiki .wrap_bgwhite {
    background-color: #fff;
}
div.dokuwiki .wrap_bgblack {
    background-color: #000;
}
*/

/* miscellaneous
********************************************************************/

/*____________ spoiler ____________*/

div.dokuwiki .wrap_spoiler {
    background-color: #fff !important;
    color: #fff !important;
    border: 1px dotted red;
}

/*____________ only print ____________*/

div.dokuwiki .wrap_onlyprint {
    display: none;
}
/**
 * @file       hide/style.css
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Luis Machuca B. <luis.machuca [at] gulix.cl>
 * @brief      CSS styles for the "hide" plugin
 * @version    1.0
 *
 */

/**
 * the following rules hide/show the text
 */
span.selectview {
  color: #fff !important;
  outline: 1px dotted gray !important;
  }
span.selectview::selection {
  }



/**
 * This rule will try to hide the effects of nested syntax modes
 * that assign color, such as BBCode.
 * It requires CSS3 selector compatibility, so no IE
 * (as if I'd care...).
 */

span.selectview span[style*="color"] {
  color: #fff !important;
  }


/**
 * These rules hide links as well 
 */

/* hide all-purpose links (including their icon) */
span.selectview a {
  color: #fff !important;
  background-image: none !important;
    }

/* hide the "existing" links */
div.dokuwiki span.selectview a.wikilink1 {
  color: #fff !important;
  }

/* hide the "missing" links */
div.dokuwiki span.selectview a.wikilink2 {
  color: #fff !important;
  }

/**
 * This rule will also try to hide table headers.
 * It is not guaranteed to work because it depends on
 * the background color as defined by the
 * current template's style.ini.
 */
div.dokuwiki table tr th span.selectview {
  color: #ddd !important;
  outline: 1px dotted gray !important;
  }
/* plugin:configmanager */
#config__manager div.success,
#config__manager div.error,
#config__manager div.info {
  background-position: 0.5em;
  padding: 0.5em;
  text-align: center;
}

#config__manager fieldset {
  margin: 1em;
  width: auto;
  margin-bottom: 2em;
  background-color: #eee;
  color: #333;
  padding: 0 1em;
}
[dir=rtl] #config__manager fieldset {
    clear: both;
}
#config__manager legend {
    font-size: 1.25em;
}

#config__manager form { }
#config__manager table {
    margin: 1em 0;
    width: 100%;
}

#config__manager fieldset td {
    text-align: left;
}
[dir=rtl] #config__manager fieldset td {
    text-align: right;
}
#config__manager fieldset td.value {
    /* fixed data column width */
    width: 31em;
}

[dir=rtl] #config__manager label {
    text-align: right;
}
[dir=rtl] #config__manager td.value input.checkbox {
    float: right;
    padding-left: 0;
    padding-right: 0.7em;
}
[dir=rtl] #config__manager td.value label {
    float: left;
}

#config__manager td.label {
    padding: 0.8em 0 0.6em 1em;
    vertical-align: top;
}
[dir=rtl] #config__manager td.label {
    padding: 0.8em 1em 0.6em 0;
}

#config__manager td.label label {
    clear: left;
    display: block;
}
[dir=rtl] #config__manager td.label label {
    clear: right;
}
#config__manager td.label img {
    padding: 0 10px;
    vertical-align: middle;
    float: right;
}
[dir=rtl] #config__manager td.label img {
    float: left;
}

#config__manager td.label span.outkey {
    font-size: 70%;
    margin-top: -1.7em;
    margin-left: -1em;
    display: block;
    background-color: #fff;
    color: #666;
    float: left;
    padding: 0 0.1em;
    position: relative;
    z-index: 1;
}
[dir=rtl] #config__manager td.label span.outkey {
    float: right;
    margin-right: 1em;
}

#config__manager td input.edit {
    width: 30em;
}
#config__manager td .input {
    width: 30.8em;
}
#config__manager td select.edit { }
#config__manager td textarea.edit {
    width: 27.5em;
    height: 4em;
}

#config__manager tr .input,
#config__manager tr input,
#config__manager tr textarea,
#config__manager tr select {
  background-color: #fff;
  color: #000;
}

#config__manager tr.default .input,
#config__manager tr.default input,
#config__manager tr.default textarea,
#config__manager tr.default select,
#config__manager .selectiondefault {
  background-color: #ccddff;
  color: #000;
}

#config__manager tr.protected .input,
#config__manager tr.protected input,
#config__manager tr.protected textarea,
#config__manager tr.protected select,
#config__manager tr.protected .selection {
  background-color: #ffcccc!important;
  color: #000 !important;
}

#config__manager td.error  { background-color: red; color: #000; }

#config__manager .selection {
  width: 14.8em;
  float: left;
  margin: 0 0.3em 2px 0;
}
[dir=rtl] #config__manager .selection {
  width: 14.8em;
  float: right;
  margin: 0 0 2px 0.3em;
}

#config__manager .selection label {
  float: right;
  width: 14em;
  font-size: 90%;
}


/* IE6 correction */
* html #config__manager .selection label {
  padding-top: 2px;
}

#config__manager .selection input.checkbox {
  padding-left: 0.7em;
}

#config__manager .other {
  clear: both;
  padding-top: 0.5em;
}

#config__manager .other label {
  padding-left: 2px;
  font-size: 90%;
}

/* end plugin:configmanager */
div.dokuwiki div.comment_wrapper {
  background-color: #eee;
  margin: 1em; 
  padding: 0.5em 1em 1.5em 0;
  clear: both;
}

div.dokuwiki div.comment_text {
  padding-top: 0.5em
}

div.dokuwiki div#discussion__comment_preview {
  padding: 1em;
  margin-top: 1em;
  visibility: hidden;
}

div.dokuwiki div.comment_preview {
  padding: 1em;
  border: 1px dashed #ccc;
}

div.dokuwiki div.comment_form {
  margin-top: 2em;
  margin-right: 1em;
  clear: both;
}

div.dokuwiki div.comment_form .error {
  background: #fcc;
}

div.dokuwiki #discussion__comment_form label input.edit {
  width: 75%;
}

div.dokuwiki .comment_head {
  font-size: 80%;
  color: #666;
  padding-top: 0.5em;
  margin-top: 1em;
  clear: both;
}

div.dokuwiki .comment_head abbr {
  border-bottom: 0;
}

div.dokuwiki .comment_head span.author {
  background: transparent url(/wiki/pm/lib/plugins/discussion/images/user.gif) 0px 1px no-repeat;
  padding: 1px 0px 1px 16px;
}

div.dokuwiki .comment_head abbr.published {
  background: transparent url(/wiki/pm/lib/plugins/discussion/images/date.gif) 0px 1px no-repeat;
  padding: 1px 0px 1px 16px;
}

div.dokuwiki .comment_body {
  padding-top: 0.5em;
  padding-bottom: 0.5em;
  border-bottom: 1px dotted #ccc;
}

div.dokuwiki div.comment_replies {
}

div.dokuwiki div.comment_subscribe {
  float: left;
  display: inline;
  padding: 0.6em;
}

div.dokuwiki div.comment_subscribe input {
  float: left;
  display: inline;
}

div.dokuwiki div.comment_subscribe label {
  float: left;
  padding-left: 0.8em;
}

div.dokuwiki input.comment_submit {
  float: left;
  display: inline;
}

div.dokuwiki div.comment_hidden {
  opacity: 0.5;
}

div.dokuwiki div.comment_buttons {
  float: right;
  font-size: 10px;
  cursor: pointer;
  margin-top: -21px;
  padding-bottom: 1em;
}

div.dokuwiki div.comment_buttons input.button {
  border: 1px solid #ccc;
  color: #333;
  background-color: #fff;
  vertical-align: middle;
  text-decoration: none;
  padding: 0;
  margin: 0 0 0 0.5em;
}

div.dokuwiki div.newthread_form {
  clear: both;
  text-align: center;
  margin-bottom: 1em;
}

div.dokuwiki #discussion__newthread_form input.edit {
  width: 95%;
}

div.dokuwiki ul.admin_discussion li.hidden {
  display: list-item;
  opacity: 0.5;
}

div.dokuwiki ul.admin_discussion span.abstract {
  color: #666;
}

div.dokuwiki table.pagelist tr.discussion_status2 a {
  color: #666 !important;
}

div#acl_manager div#acl__tree {
    font-size: 90%;
    width: 25%;
    height: 300px;
    float: left;
    overflow: auto;
    border: 1px solid #ccc;
    text-align: left;
}
[dir=rtl] div#acl_manager div#acl__tree {
    float: right;
    text-align: right;
}

div#acl_manager div#acl__tree a.cur {
    background-color: #ff9;
    font-weight: bold;
}

div#acl_manager div#acl__tree ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
}

div#acl_manager div#acl__tree li {
    padding-left: 1em;
    list-style-image: none;
}
[dir=rtl] div#acl_manager div#acl__tree li {
    padding-left: 0em;
    padding-right: 1em;
}

div#acl_manager div#acl__tree ul img {
    margin-right: 0.25em;
    cursor: pointer;
}
[dir=rtl] div#acl_manager div#acl__tree ul img {
    margin-left: 0.25em;
    margin-right: 0em;
}

div#acl_manager div#acl__detail {
    width: 73%;
    height: 300px;
    float: right;
    overflow: auto;
}
[dir=rtl] div#acl_manager div#acl__detail {
    float: left;
}

div#acl_manager div#acl__detail fieldset {
    width: 90%;
}

div#acl_manager div#acl__detail div#acl__user {
    border: 1px solid #ccc;
    padding: 0.5em;
    margin-bottom: 0.6em;
}

div#acl_manager table.inline {
    width: 100%;
    margin: 0;
}

#acl_manager table .check {
    text-align: center;
}

#acl_manager table .action {
    text-align: right;
}

div#acl_manager .aclgroup {
    background: transparent url(/wiki/pm/lib/plugins/acl/pix/group.png) 0px 1px no-repeat;
    padding: 1px 0px 1px 18px;
}
[dir=rtl] div#acl_manager .aclgroup {
    background: transparent url(/wiki/pm/lib/plugins/acl/pix/group.png) right 1px no-repeat;
    padding: 1px 18px 1px 0px;
    display: inline-block; /* needed for IE7 */
}

div#acl_manager .acluser {
    background: transparent url(/wiki/pm/lib/plugins/acl/pix/user.png) 0px 1px no-repeat;
    padding: 1px 0px 1px 18px;
}
[dir=rtl] div#acl_manager .acluser {
    background: transparent url(/wiki/pm/lib/plugins/acl/pix/user.png) right 1px no-repeat;
    padding: 1px 18px 1px 0px;
    display: inline-block; /* needed for IE7 */
}

div#acl_manager .aclpage {
    background: transparent url(/wiki/pm/lib/plugins/acl/pix/page.png) 0px 1px no-repeat;
    padding: 1px 0px 1px 18px;
}
[dir=rtl] div#acl_manager .aclpage {
    background: transparent url(/wiki/pm/lib/plugins/acl/pix/page.png) right 1px no-repeat;
    padding: 1px 18px 1px 0px;
    display: inline-block; /* needed for IE7 */
}

div#acl_manager .aclns {
    background: transparent url(/wiki/pm/lib/plugins/acl/pix/ns.png) 0px 1px no-repeat;
    padding: 1px 0px 1px 18px;
}
[dir=rtl] div#acl_manager .aclns {
    background: transparent url(/wiki/pm/lib/plugins/acl/pix/ns.png) right 1px no-repeat;
    padding: 1px 18px 1px 0px;
    display: inline-block; /* needed for IE7 */
}

div#acl_manager label.disabled {
  color: #666!important;
}

#acl_manager label {
  text-align: left;
  font-weight: normal;
  display: inline;
}

#acl_manager table {
  margin-left: 10%;
  width: 80%;
}

#acl_manager table tr {
    background-color: inherit;
}

#acl_manager table tr:hover {
    background-color: #eee;
}

div.dokuwiki div.gallery table {
    border: none;
}
div.dokuwiki div.gallery table td {
    padding: 1em;
    text-align: center;
    vertical-align: middle;
    border: none;
}

div.dokuwiki div.gallery table img.tn {
    padding: 0.4em;
    border: 1px solid #ccc;
    max-width: none;
}

div.dokuwiki div.gallery {
    clear: left;
    margin-bottom: 1em;
}

/*div.dokuwiki div.gallery div {
 *   float: left;
 *   }*/

div.dokuwiki div.gallery img.tn {
    margin: 9px;
    vertical-align: middle;
    padding: 0.4em;
    border: 1px solid #000;
}

div.dokuwiki div.gallery_left {
    float: left;
}

div.dokuwiki div.gallery div {
    float: left;
}

div.dokuwiki div.gallery_right {
    float: right;
}

div.dokuwiki div.gallery_center {
    margin-left: auto;
    margin-right: auto;
}

div.dokuwiki div.gallery_center {
    width: 80%;
    text-align: center;
}

/* for pagination */
div.dokuwiki div.gallery div.gallery_pages {
    float: none;
    text-align: left;
}

/* ------------------------------------------------------------------------
    This you can edit.
------------------------------------------------------------------------- */

    /* ----------------------------------
        Default Theme
    ----------------------------------- */

    div.pp_default .pp_top,
    div.pp_default .pp_top .pp_middle,
    div.pp_default .pp_top .pp_left,
    div.pp_default .pp_top .pp_right,
    div.pp_default .pp_bottom,
    div.pp_default .pp_bottom .pp_left,
    div.pp_default .pp_bottom .pp_middle,
    div.pp_default .pp_bottom .pp_right { height: 13px; }

    div.pp_default .pp_top .pp_left { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite.png) -78px -93px no-repeat; } /* Top left corner */
    div.pp_default .pp_top .pp_middle { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite_x.png) top left repeat-x; } /* Top pattern/color */
    div.pp_default .pp_top .pp_right { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite.png) -112px -93px no-repeat; } /* Top right corner */

    div.pp_default .pp_content .ppt { color: #f8f8f8; }
    div.pp_default .pp_content_container .pp_left { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite_y.png) -7px 0 repeat-y; padding-left: 13px; }
    div.pp_default .pp_content_container .pp_right { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite_y.png) top right repeat-y; padding-right: 13px; }
    div.pp_default .pp_content { background-color: #fff; } /* Content background */
    div.pp_default .pp_next:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite_next.png) center right  no-repeat; cursor: pointer; } /* Next button */
    div.pp_default .pp_previous:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite_prev.png) center left no-repeat; cursor: pointer; } /* Previous button */
    div.pp_default .pp_expand { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite.png) 0 -29px no-repeat; cursor: pointer; width: 28px; height: 28px; } /* Expand button */
    div.pp_default .pp_expand:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite.png) 0 -56px no-repeat; cursor: pointer; } /* Expand button hover */
    div.pp_default .pp_contract { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite.png) 0 -84px no-repeat; cursor: pointer; width: 28px; height: 28px; } /* Contract button */
    div.pp_default .pp_contract:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite.png) 0 -113px no-repeat; cursor: pointer; } /* Contract button hover */
    div.pp_default .pp_close { width: 30px; height: 30px; background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite.png) 2px 1px no-repeat; cursor: pointer; } /* Close button */
    div.pp_default #pp_full_res .pp_inline { color: #000; }
    div.pp_default .pp_gallery ul li a { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/default_thumb.png) center center #f8f8f8; border:1px solid #aaa; }
    div.pp_default .pp_gallery ul li a:hover,
    div.pp_default .pp_gallery ul li.selected a { border-color: #fff; }
    div.pp_default .pp_social { margin-top: 7px; }

    div.pp_default .pp_gallery a.pp_arrow_previous,
    div.pp_default .pp_gallery a.pp_arrow_next { position: static; left: auto; }
    div.pp_default .pp_nav .pp_play,
    div.pp_default .pp_nav .pp_pause { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite.png) -51px 1px no-repeat; height:30px; width:30px; }
    div.pp_default .pp_nav .pp_pause { background-position: -51px -29px; }
    div.pp_default .pp_details { position: relative; }
    div.pp_default a.pp_arrow_previous,
    div.pp_default a.pp_arrow_next { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite.png) -31px -3px no-repeat; height: 20px; margin: 4px 0 0 0; width: 20px; }
    div.pp_default a.pp_arrow_next { left: 52px; background-position: -82px -3px; } /* The next arrow in the bottom nav */
    div.pp_default .pp_content_container .pp_details { margin-top: 5px; }
    div.pp_default .pp_nav { clear: none; height: 30px; width: 110px; position: relative; }
    div.pp_default .pp_nav .currentTextHolder{ font-family: Georgia; font-style: italic; color:#999; font-size: 11px; left: 75px; line-height: 25px; margin: 0; padding: 0 0 0 10px; position: absolute; top: 2px; }

    div.pp_default .pp_close:hover, div.pp_default .pp_nav .pp_play:hover, div.pp_default .pp_nav .pp_pause:hover, div.pp_default .pp_arrow_next:hover, div.pp_default .pp_arrow_previous:hover { opacity:0.7; }

    div.pp_default .pp_description{ font-size: 11px; font-weight: bold; line-height: 14px; margin: 5px 50px 5px 0; }

    div.pp_default .pp_bottom .pp_left { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite.png) -78px -127px no-repeat; } /* Bottom left corner */
    div.pp_default .pp_bottom .pp_middle { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite_x.png) bottom left repeat-x; } /* Bottom pattern/color */
    div.pp_default .pp_bottom .pp_right { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/sprite.png) -112px -127px no-repeat; } /* Bottom right corner */

    div.pp_default .pp_loaderIcon { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/default/loader.gif) center center no-repeat; } /* Loader icon */


    /* ----------------------------------
        Light Rounded Theme
    ----------------------------------- */


    div.light_rounded .pp_top .pp_left { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/sprite.png) -88px -53px no-repeat; } /* Top left corner */
    div.light_rounded .pp_top .pp_middle { background: #fff; } /* Top pattern/color */
    div.light_rounded .pp_top .pp_right { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/sprite.png) -110px -53px no-repeat; } /* Top right corner */

    div.light_rounded .pp_content .ppt { color: #000; }
    div.light_rounded .pp_content_container .pp_left,
    div.light_rounded .pp_content_container .pp_right { background: #fff; }
    div.light_rounded .pp_content { background-color: #fff; } /* Content background */
    div.light_rounded .pp_next:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/btnNext.png) center right  no-repeat; cursor: pointer; } /* Next button */
    div.light_rounded .pp_previous:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/btnPrevious.png) center left no-repeat; cursor: pointer; } /* Previous button */
    div.light_rounded .pp_expand { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/sprite.png) -31px -26px no-repeat; cursor: pointer; } /* Expand button */
    div.light_rounded .pp_expand:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/sprite.png) -31px -47px no-repeat; cursor: pointer; } /* Expand button hover */
    div.light_rounded .pp_contract { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/sprite.png) 0 -26px no-repeat; cursor: pointer; } /* Contract button */
    div.light_rounded .pp_contract:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/sprite.png) 0 -47px no-repeat; cursor: pointer; } /* Contract button hover */
    div.light_rounded .pp_close { width: 75px; height: 22px; background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/sprite.png) -1px -1px no-repeat; cursor: pointer; } /* Close button */
    div.light_rounded .pp_details { position: relative; }
    div.light_rounded .pp_description { margin-right: 85px; }
    div.light_rounded #pp_full_res .pp_inline { color: #000; }
    div.light_rounded .pp_gallery a.pp_arrow_previous,
    div.light_rounded .pp_gallery a.pp_arrow_next { margin-top: 12px !important; }
    div.light_rounded .pp_nav .pp_play { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/sprite.png) -1px -100px no-repeat; height: 15px; width: 14px; }
    div.light_rounded .pp_nav .pp_pause { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/sprite.png) -24px -100px no-repeat; height: 15px; width: 14px; }

    div.light_rounded .pp_arrow_previous { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/sprite.png) 0 -71px no-repeat; } /* The previous arrow in the bottom nav */
        div.light_rounded .pp_arrow_previous.disabled { background-position: 0 -87px; cursor: default; }
    div.light_rounded .pp_arrow_next { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/sprite.png) -22px -71px no-repeat; } /* The next arrow in the bottom nav */
        div.light_rounded .pp_arrow_next.disabled { background-position: -22px -87px; cursor: default; }

    div.light_rounded .pp_bottom .pp_left { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/sprite.png) -88px -80px no-repeat; } /* Bottom left corner */
    div.light_rounded .pp_bottom .pp_middle { background: #fff; } /* Bottom pattern/color */
    div.light_rounded .pp_bottom .pp_right { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/sprite.png) -110px -80px no-repeat; } /* Bottom right corner */

    div.light_rounded .pp_loaderIcon { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/loader.gif) center center no-repeat; } /* Loader icon */

    /* ----------------------------------
        Dark Rounded Theme
    ----------------------------------- */

    div.dark_rounded .pp_top .pp_left { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/sprite.png) -88px -53px no-repeat; } /* Top left corner */
    div.dark_rounded .pp_top .pp_middle { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/contentPattern.png) top left repeat; } /* Top pattern/color */
    div.dark_rounded .pp_top .pp_right { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/sprite.png) -110px -53px no-repeat; } /* Top right corner */

    div.dark_rounded .pp_content_container .pp_left { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/contentPattern.png) top left repeat-y; } /* Left Content background */
    div.dark_rounded .pp_content_container .pp_right { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/contentPattern.png) top right repeat-y; } /* Right Content background */
    div.dark_rounded .pp_content { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/contentPattern.png) top left repeat; } /* Content background */
    div.dark_rounded .pp_next:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/btnNext.png) center right  no-repeat; cursor: pointer; } /* Next button */
    div.dark_rounded .pp_previous:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/btnPrevious.png) center left no-repeat; cursor: pointer; } /* Previous button */
    div.dark_rounded .pp_expand { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/sprite.png) -31px -26px no-repeat; cursor: pointer; } /* Expand button */
    div.dark_rounded .pp_expand:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/sprite.png) -31px -47px no-repeat; cursor: pointer; } /* Expand button hover */
    div.dark_rounded .pp_contract { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/sprite.png) 0 -26px no-repeat; cursor: pointer; } /* Contract button */
    div.dark_rounded .pp_contract:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/sprite.png) 0 -47px no-repeat; cursor: pointer; } /* Contract button hover */
    div.dark_rounded .pp_close { width: 75px; height: 22px; background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/sprite.png) -1px -1px no-repeat; cursor: pointer; } /* Close button */
    div.dark_rounded .pp_details { position: relative; }
    div.dark_rounded .pp_description { margin-right: 85px; }
    div.dark_rounded .currentTextHolder { color: #c4c4c4; }
    div.dark_rounded .pp_description { color: #fff; }
    div.dark_rounded #pp_full_res .pp_inline { color: #fff; }
    div.dark_rounded .pp_gallery a.pp_arrow_previous,
    div.dark_rounded .pp_gallery a.pp_arrow_next { margin-top: 12px !important; }
    div.dark_rounded .pp_nav .pp_play { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/sprite.png) -1px -100px no-repeat; height: 15px; width: 14px; }
    div.dark_rounded .pp_nav .pp_pause { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/sprite.png) -24px -100px no-repeat; height: 15px; width: 14px; }

    div.dark_rounded .pp_arrow_previous { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/sprite.png) 0 -71px no-repeat; } /* The previous arrow in the bottom nav */
        div.dark_rounded .pp_arrow_previous.disabled { background-position: 0 -87px; cursor: default; }
    div.dark_rounded .pp_arrow_next { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/sprite.png) -22px -71px no-repeat; } /* The next arrow in the bottom nav */
        div.dark_rounded .pp_arrow_next.disabled { background-position: -22px -87px; cursor: default; }

    div.dark_rounded .pp_bottom .pp_left { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/sprite.png) -88px -80px no-repeat; } /* Bottom left corner */
    div.dark_rounded .pp_bottom .pp_middle { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/contentPattern.png) top left repeat; } /* Bottom pattern/color */
    div.dark_rounded .pp_bottom .pp_right { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/sprite.png) -110px -80px no-repeat; } /* Bottom right corner */

    div.dark_rounded .pp_loaderIcon { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_rounded/loader.gif) center center no-repeat; } /* Loader icon */


    /* ----------------------------------
        Dark Square Theme
    ----------------------------------- */

    div.dark_square .pp_left ,
    div.dark_square .pp_middle,
    div.dark_square .pp_right,
    div.dark_square .pp_content { background: #000; }

    div.dark_square .currentTextHolder { color: #c4c4c4; }
    div.dark_square .pp_description { color: #fff; }
    div.dark_square .pp_loaderIcon { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_square/loader.gif) center center no-repeat; } /* Loader icon */

    div.dark_square .pp_expand { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_square/sprite.png) -31px -26px no-repeat; cursor: pointer; } /* Expand button */
    div.dark_square .pp_expand:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_square/sprite.png) -31px -47px no-repeat; cursor: pointer; } /* Expand button hover */
    div.dark_square .pp_contract { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_square/sprite.png) 0 -26px no-repeat; cursor: pointer; } /* Contract button */
    div.dark_square .pp_contract:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_square/sprite.png) 0 -47px no-repeat; cursor: pointer; } /* Contract button hover */
    div.dark_square .pp_close { width: 75px; height: 22px; background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_square/sprite.png) -1px -1px no-repeat; cursor: pointer; } /* Close button */
    div.dark_square .pp_details { position: relative; }
    div.dark_square .pp_description { margin: 0 85px 0 0; }
    div.dark_square #pp_full_res .pp_inline { color: #fff; }
    div.dark_square .pp_gallery a.pp_arrow_previous,
    div.dark_square .pp_gallery a.pp_arrow_next { margin-top: 12px !important; }
    div.dark_square .pp_nav { clear: none; }
    div.dark_square .pp_nav .pp_play { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_square/sprite.png) -1px -100px no-repeat; height: 15px; width: 14px; }
    div.dark_square .pp_nav .pp_pause { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_square/sprite.png) -24px -100px no-repeat; height: 15px; width: 14px; }

    div.dark_square .pp_arrow_previous { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_square/sprite.png) 0 -71px no-repeat; } /* The previous arrow in the bottom nav */
        div.dark_square .pp_arrow_previous.disabled { background-position: 0 -87px; cursor: default; }
    div.dark_square .pp_arrow_next { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_square/sprite.png) -22px -71px no-repeat; } /* The next arrow in the bottom nav */
        div.dark_square .pp_arrow_next.disabled { background-position: -22px -87px; cursor: default; }

    div.dark_square .pp_next:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_square/btnNext.png) center right  no-repeat; cursor: pointer; } /* Next button */
    div.dark_square .pp_previous:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/dark_square/btnPrevious.png) center left no-repeat; cursor: pointer; } /* Previous button */


    /* ----------------------------------
        Light Square Theme
    ----------------------------------- */

    div.light_square .pp_left ,
    div.light_square .pp_middle,
    div.light_square .pp_right,
    div.light_square .pp_content { background: #fff; }

    div.light_square .pp_content .ppt { color: #000; }
    div.light_square .pp_expand { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_square/sprite.png) -31px -26px no-repeat; cursor: pointer; } /* Expand button */
    div.light_square .pp_expand:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_square/sprite.png) -31px -47px no-repeat; cursor: pointer; } /* Expand button hover */
    div.light_square .pp_contract { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_square/sprite.png) 0 -26px no-repeat; cursor: pointer; } /* Contract button */
    div.light_square .pp_contract:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_square/sprite.png) 0 -47px no-repeat; cursor: pointer; } /* Contract button hover */
    div.light_square .pp_close { width: 75px; height: 22px; background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_square/sprite.png) -1px -1px no-repeat; cursor: pointer; } /* Close button */
    div.light_square .pp_details { position: relative; }
    div.light_square .pp_description { margin-right: 85px; }
    div.light_square #pp_full_res .pp_inline { color: #000; }
    div.light_square .pp_gallery a.pp_arrow_previous,
    div.light_square .pp_gallery a.pp_arrow_next { margin-top: 12px !important; }
    div.light_square .pp_nav .pp_play { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_square/sprite.png) -1px -100px no-repeat; height: 15px; width: 14px; }
    div.light_square .pp_nav .pp_pause { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_square/sprite.png) -24px -100px no-repeat; height: 15px; width: 14px; }

    div.light_square .pp_arrow_previous { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_square/sprite.png) 0 -71px no-repeat; } /* The previous arrow in the bottom nav */
        div.light_square .pp_arrow_previous.disabled { background-position: 0 -87px; cursor: default; }
    div.light_square .pp_arrow_next { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_square/sprite.png) -22px -71px no-repeat; } /* The next arrow in the bottom nav */
        div.light_square .pp_arrow_next.disabled { background-position: -22px -87px; cursor: default; }

    div.light_square .pp_next:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_square/btnNext.png) center right  no-repeat; cursor: pointer; } /* Next button */
    div.light_square .pp_previous:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_square/btnPrevious.png) center left no-repeat; cursor: pointer; } /* Previous button */

    div.light_square .pp_loaderIcon { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/loader.gif) center center no-repeat; } /* Loader icon */


    /* ----------------------------------
        Facebook style Theme
    ----------------------------------- */

    div.facebook .pp_top .pp_left { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/sprite.png) -88px -53px no-repeat; } /* Top left corner */
    div.facebook .pp_top .pp_middle { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/contentPatternTop.png) top left repeat-x; } /* Top pattern/color */
    div.facebook .pp_top .pp_right { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/sprite.png) -110px -53px no-repeat; } /* Top right corner */

    div.facebook .pp_content .ppt { color: #000; }
    div.facebook .pp_content_container .pp_left { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/contentPatternLeft.png) top left repeat-y; } /* Content background */
    div.facebook .pp_content_container .pp_right { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/contentPatternRight.png) top right repeat-y; } /* Content background */
    div.facebook .pp_content { background: #fff; } /* Content background */
    div.facebook .pp_expand { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/sprite.png) -31px -26px no-repeat; cursor: pointer; } /* Expand button */
    div.facebook .pp_expand:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/sprite.png) -31px -47px no-repeat; cursor: pointer; } /* Expand button hover */
    div.facebook .pp_contract { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/sprite.png) 0 -26px no-repeat; cursor: pointer; } /* Contract button */
    div.facebook .pp_contract:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/sprite.png) 0 -47px no-repeat; cursor: pointer; } /* Contract button hover */
    div.facebook .pp_close { width: 22px; height: 22px; background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/sprite.png) -1px -1px no-repeat; cursor: pointer; } /* Close button */
    div.facebook .pp_details { position: relative; }
    div.facebook .pp_description { margin: 0 37px 0 0; }
    div.facebook #pp_full_res .pp_inline { color: #000; }
    div.facebook .pp_loaderIcon { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/loader.gif) center center no-repeat; } /* Loader icon */

    div.facebook .pp_arrow_previous { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/sprite.png) 0 -71px no-repeat; height: 22px; margin-top: 0; width: 22px; } /* The previous arrow in the bottom nav */
        div.facebook .pp_arrow_previous.disabled { background-position: 0 -96px; cursor: default; }
    div.facebook .pp_arrow_next { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/sprite.png) -32px -71px no-repeat; height: 22px; margin-top: 0; width: 22px; } /* The next arrow in the bottom nav */
        div.facebook .pp_arrow_next.disabled { background-position: -32px -96px; cursor: default; }
    div.facebook .pp_nav { margin-top: 0; }
    div.facebook .pp_nav p { font-size: 15px; padding: 0 3px 0 4px; }
    div.facebook .pp_nav .pp_play { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/sprite.png) -1px -123px no-repeat; height: 22px; width: 22px; }
    div.facebook .pp_nav .pp_pause { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/sprite.png) -32px -123px no-repeat; height: 22px; width: 22px; }

    div.facebook .pp_next:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/btnNext.png) center right no-repeat; cursor: pointer; } /* Next button */
    div.facebook .pp_previous:hover { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/btnPrevious.png) center left no-repeat; cursor: pointer; } /* Previous button */

    div.facebook .pp_bottom .pp_left { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/sprite.png) -88px -80px no-repeat; } /* Bottom left corner */
    div.facebook .pp_bottom .pp_middle { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/contentPatternBottom.png) top left repeat-x; } /* Bottom pattern/color */
    div.facebook .pp_bottom .pp_right { background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/sprite.png) -110px -80px no-repeat; } /* Bottom right corner */


/* ------------------------------------------------------------------------
    DO NOT CHANGE
------------------------------------------------------------------------- */

    div.pp_pic_holder a:focus { outline:none; }

    div.pp_overlay {
        background: #000;
        display: none;
        left: 0;
        position: absolute;
        top: 0;
        width: 100%;
        z-index: 9500;
    }

    div.pp_pic_holder {
        display: none;
        position: absolute;
        width: 100px;
        z-index: 10000;
    }


        .pp_top {
            height: 20px;
            position: relative;
        }
            * html .pp_top { padding: 0 20px; }

            .pp_top .pp_left {
                height: 20px;
                left: 0;
                position: absolute;
                width: 20px;
            }
            .pp_top .pp_middle {
                height: 20px;
                left: 20px;
                position: absolute;
                right: 20px;
            }
                * html .pp_top .pp_middle {
                    left: 0;
                    position: static;
                }

            .pp_top .pp_right {
                height: 20px;
                left: auto;
                position: absolute;
                right: 0;
                top: 0;
                width: 20px;
            }

        .pp_content { height: 40px; min-width: 40px; }
        * html .pp_content { width: 40px; }

        .pp_fade { display: none; }

        .pp_content_container {
            position: relative;
            text-align: left;
            width: 100%;
        }

            .pp_content_container .pp_left { padding-left: 20px; }
            .pp_content_container .pp_right { padding-right: 20px; }

            .pp_content_container .pp_details {
                float: left;
                margin: 10px 0 2px 0;
            }
                .pp_description {
                    display: none;
                    margin: 0;
                }

                .pp_social { float: left; margin: 0; }
                .pp_social .facebook { float: left; margin-left: 5px; width: 55px; overflow: hidden; }
                .pp_social .twitter { float: left; }

                .pp_nav {
                    clear: right;
                    float: left;
                    margin: 3px 10px 0 0;
                }

                    .pp_nav p {
                        float: left;
                        margin: 2px 4px;
                        white-space: nowrap;
                    }

                    .pp_nav .pp_play,
                    .pp_nav .pp_pause {
                        float: left;
                        margin-right: 4px;
                        text-indent: -10000px;
                    }

                    a.pp_arrow_previous,
                    a.pp_arrow_next {
                        display: block;
                        float: left;
                        height: 15px;
                        margin-top: 3px;
                        overflow: hidden;
                        text-indent: -10000px;
                        width: 14px;
                    }

        .pp_hoverContainer {
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 2000;
        }

        .pp_gallery {
            display: none;
            left: 50%;
            margin-top: -50px;
            position: absolute;
            z-index: 10000;
        }

            .pp_gallery div {
                float: left;
                overflow: hidden;
                position: relative;
            }

            .pp_gallery ul {
                float: left;
                height: 35px;
                margin: 0 0 0 5px;
                padding: 0;
                position: relative;
                white-space: nowrap;
            }

            .pp_gallery ul a {
                border: 1px #000 solid;
                border: 1px rgba(0,0,0,0.5) solid;
                display: block;
                float: left;
                height: 33px;
                overflow: hidden;
            }

            .pp_gallery ul a:hover,
            .pp_gallery li.selected a { border-color: #fff; }

            .pp_gallery ul a img { border: 0; }

            .pp_gallery li {
                display: block;
                float: left;
                margin: 0 5px 0 0;
                padding: 0;
            }

            .pp_gallery li.default a {
                background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/facebook/default_thumbnail.gif) 0 0 no-repeat;
                display: block;
                height: 33px;
                width: 50px;
            }

            .pp_gallery li.default a img { display: none; }

            .pp_gallery .pp_arrow_previous,
            .pp_gallery .pp_arrow_next {
                margin-top: 7px !important;
            }

        a.pp_next {
            background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/btnNext.png) 10000px 10000px no-repeat;
            display: block;
            float: right;
            height: 100%;
            text-indent: -10000px;
            width: 49%;
        }

        a.pp_previous {
            background: url(/wiki/pm/lib/plugins/gallery/prettyPhoto/light_rounded/btnNext.png) 10000px 10000px no-repeat;
            display: block;
            float: left;
            height: 100%;
            text-indent: -10000px;
            width: 49%;
        }

        a.pp_expand,
        a.pp_contract {
            cursor: pointer;
            display: none;
            height: 20px;
            position: absolute;
            right: 30px;
            text-indent: -10000px;
            top: 10px;
            width: 20px;
            z-index: 20000;
        }

        a.pp_close {
            position: absolute; right: 0; top: 0;
            display: block;
            line-height:22px;
            text-indent: -10000px;
        }

        .pp_bottom {
            height: 20px;
            position: relative;
        }
            * html .pp_bottom { padding: 0 20px; }

            .pp_bottom .pp_left {
                height: 20px;
                left: 0;
                position: absolute;
                width: 20px;
            }
            .pp_bottom .pp_middle {
                height: 20px;
                left: 20px;
                position: absolute;
                right: 20px;
            }
                * html .pp_bottom .pp_middle {
                    left: 0;
                    position: static;
                }

            .pp_bottom .pp_right {
                height: 20px;
                left: auto;
                position: absolute;
                right: 0;
                top: 0;
                width: 20px;
            }

        .pp_loaderIcon {
            display: block;
            height: 24px;
            left: 50%;
            margin: -12px 0 0 -12px;
            position: absolute;
            top: 50%;
            width: 24px;
        }

        #pp_full_res {
            line-height: 1 !important;
        }

            #pp_full_res .pp_inline {
                text-align: left;
            }

                #pp_full_res .pp_inline p { margin: 0 0 15px 0; }

        div.ppt {
            color: #fff;
            display: none;
            font-size: 17px;
            margin: 0 0 5px 15px;
            z-index: 9999;
        }
div.save_as {
 color:black;
 background-color:yellow;
 width: 300px;
 height: 80px;
 text-align: center;
 border: solid 1px red;
 padding: 10px;
 margin: auto;
}
div.panoview_plugin {
    position: relative;
    top: 0;
    left: 0;
    border: solid 1px #ccc;
    background-color: #000;
}
div.panoview_plugin .well, div.panoview_plugin .surface {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0px;
    left: 0px;
    /* FIXME: let's apply this in GSV.js */
    /*cursor: grab;*/
    cursor: -moz-grab;
        _cursor: url(/wiki/pm/lib/plugins/panoview/gfx/grab.cur);
}
div.panoview_plugin .surface {
    z-index: 20;
    /*background: url(/wiki/pm/lib/plugins/panoview/../gfx/center.gif) no-repeat center center;*/
        _background: url(/wiki/pm/lib/plugins/panoview/gfx/blank.gif) no-repeat center center; /* NOTE: required for IE to"see" the surface */
}
div.panoview_plugin .well {
    overflow: hidden;
    z-index: 10;
}
div.panoview_plugin .well .tile
{
    border: 0;
    margin: 0;
    padding: 0;
    position: absolute;
    top: 0px;
    left: 0px;
    display: block;
    /*-moz-outline: 1px dashed #FF0000;*/
}
div.panoview_plugin .controls
{
    background-color: #FFFFFF;
    position: absolute;
    /* NOTE: the right and bottom can be adjusted when initialized */
    right: 1px;
    bottom: 1px;
    width: 44px;
    height: 20px;
    margin: 0;
    padding: 0 0 0 4px;
    font-size: 12px;
    line-height: 20px;
    vertical-align: middle;
    font-weight: bold;
    border: 1px solid #ccc;
    z-index: 30;
    opacity: 0.8;
}
div.panoview_plugin .controls a, div.panoview_plugin .controls span
{
    color: #000000;
    text-decoration: none;
    -moz-outline: none;
    cursor: pointer;
}
div.panoview_plugin .controls a img, div.panoview_plugin .controls span img {
    border: 0;
    vertical-align: middle;
}
div.panoview_plugin .controls a:active, div.panoview_plugin .controls span:active {
    color: #FF0000;
}
.dwmenu{width:80%;}
.dwmenu.center{margin:0 auto;}
.dwmenu.left{float:left}
.dwmenu.right{float:right}
.dwmenu_caption{font-size: medium !important;font-weight: bold;}
.dwmenu_item{display:inline-block;padding: 5px 2px;}
.dwmenu_item img{float:left;padding-right: 5px;width: 48px;}
.dwmenu_item.column1{width:100%}
.dwmenu_item.column2{width:49%}
.dwmenu_item.column3{width:33%}
.dwmenu_item.column4{width:25%}
.dwmenu_item.column5{width:20%}
.dwmenu_item.column6{width:16%}
.dwmenu_item.column7{width:14%}
.dwmenu_item.column8{width:12.5%}
.dwmenu_item.column9{width:11%}
.dwmenu_item.column10{width:10%}
.dwmenu_itemhead{font-weight: bold;margin-left: 53px;}
.dwmenu_itemdesc{margin-left: 53px;font-size: 87.5%;font-style: italic;}
.dwmenu_itemlink{margin-left: 53px;}/**
 * This file provides the most basic styles.
 *
 * If you integrate DokuWiki into another project, you might either
 * want to integrate this file into the other project as well, or use
 * the other project's basic CSS for DokuWiki instead of this one.
 *
 * @author Anika Henke <anika@selfthinker.org>
 */

html {
    overflow-x: auto;
    overflow-y: scroll;
}
html,
body {
    color: #333;
    background: #fbfaf9 url(/wiki/pm/lib/tpl/dokuwiki_modif/images/page-gradient.png) top left repeat-x;
    margin: 0;
    padding: 0;
}
body {
    font: normal 87.5%/1.4 Verdana,"Lucida Grande",Lucida, Helvetica, Arial, sans-serif;
    /* default font size: 100% => 16px; 93.75% => 15px; 87.5% => 14px; 81.25% => 13px; 75% => 12px */
    -webkit-text-size-adjust: 100%;
}


/*____________ headers ____________*/

h1,
h2,
h3,
h4,
h5,
h6,
caption,
legend {
    font-family: Arial, sans-serif;
    font-weight: bold;
    padding: 0;
    line-height: 1.2;
    clear: left; /* ideally 'both', but problems with toc */
}
[dir=rtl] h1,
[dir=rtl] h2,
[dir=rtl] h3,
[dir=rtl] h4,
[dir=rtl] h5,
[dir=rtl] h6,
[dir=rtl] caption,
[dir=rtl] legend {
    clear: right;
}

h1 {
    font-size: 2em;
    margin: 0 0 0.444em;
}
h2 {
    font-size: 1.5em;
    margin: 0 0 0.666em;
}
h3 {
    font-size: 1.125em;
    margin: 0 0 0.888em;
}
h4 {
    font-size: 1em;
    margin: 0 0 1.0em;
}
h5 {
    font-size: .875em;
    margin: 0 0 1.1428em;
}
h6 {
    font-size: .75em;
    margin: 0 0 1.333em;
}
/* bottom margin = 1 / font-size */


/*____________ basic margins and paddings ____________*/

p,
ul,
ol,
dl,
pre,
table,
hr,
blockquote,
fieldset,
address {
    margin: 0 0 1.4em 0; /* bottom margin = line-height */
    padding: 0;
}

div {
    margin: 0;
    padding: 0;
}


/*____________ lists ____________*/

ul,
ol {
    padding: 0 0 0 1.5em;
}
[dir=rtl] ul,
[dir=rtl] ol {
    padding: 0 1.5em 0 0;
}

li,
dd {
    padding: 0;
    margin: 0 0 0 1.5em;
}
[dir=rtl] li,
[dir=rtl] dd {
    margin: 0 1.5em 0 0;
}
dt {
    font-weight: bold;
    margin: 0;
    padding: 0;
}

li ul,
li ol,
li dl,
dl ul,
dl ol,
dl dl {
    margin-bottom: 0;
    padding: 0;
}
li li {
    font-size: 100%;
}

ul             { list-style: square outside; }
ol             { list-style: decimal outside; }
ol ol          { list-style-type: lower-alpha; }
ol ol ol       { list-style-type: upper-roman; }
ol ol ol ol    { list-style-type: upper-alpha; }
ol ol ol ol ol { list-style-type: lower-roman; }


/*____________ tables ____________*/

table {
    border-collapse: collapse;
    empty-cells: show;
    border-spacing: 0;
    border: 1px solid #ccc;
}

caption {
    caption-side: top;
    text-align: left;
    margin: 0 0 .3em;
}
[dir=rtl] caption {
    text-align: right;
}

th,
td {
    padding: .3em .5em;
    margin: 0;
    vertical-align: top;
    border: 1px solid #ccc;
    text-align: left;
}
th {
    font-weight: bold;
    background-color: #eee;
}
[dir=rtl] td,
[dir=rtl] th {
    text-align: right;
}


/*____________ links ____________*/

a {
    outline: none;
}
a:link,
a:visited {
    text-decoration: none;
    color: #2b73b7;
}
a:link:hover,
a:visited:hover,
a:link:focus,
a:visited:focus,
a:link:active,
a:visited:active {
    text-decoration: underline;
}


/*____________ misc ____________*/

img {
    border-width: 0;
    vertical-align: middle;
    color: #666;
    background-color: transparent;
    font-style: italic;
    height: auto;
}
img,
object {
    max-width: 100%;
}
/* IE8 and below won't display the images otherwise */
button img {
    max-width: none;
}

hr {
    border-top: solid #ccc;
    border-bottom: solid #fff;
    border-width: 1px 0;
    height: 0;
    width: 100%;
    text-align: center;
    clear: both;
}

acronym,
abbr {
    cursor: help;
    border-bottom: 1px dotted;
    font-style: normal;
}

pre,
code,
samp,
kbd {
    font-family: Consolas, "Andale Mono WT", "Andale Mono", "Bitstream Vera Sans Mono", "Nimbus Mono L", Monaco, "Courier New", monospace;
    /* same font stack should be used for ".dokuwiki table.diff td" in _diff.css */
    font-size: 1em;
    direction: ltr;
    text-align: left;
    background-color: #fbfaf9;
    color: #333;
    box-shadow: inset 0 0 .3em #ccc;
    border-radius: 2px;
}
pre {
    overflow: auto;
    word-wrap: normal;
    border: 1px solid #ccc;
    border-radius: 2px;
    box-shadow: inset 0 0 .5em #ccc;
    padding: .7em 1em;
}

blockquote {
    padding: 0 .5em;
    border: solid #ccc;
    border-width: 0 0 0 .25em;
}
[dir=rtl] blockquote {
    border-width: 0 .25em 0 0;
}
q:before,
q:after {
    content: '';
}

sub,
sup {
    font-size: .8em;
    line-height: 1;
}
sub {
    vertical-align: sub;
}
sup {
    vertical-align: super;
}

/*____________ forms ____________*/

/* for all of the form styles, style.ini colours are not used on purpose (except for fieldset border) */

form {
    display: inline;
    margin: 0;
    padding: 0;
}
fieldset {
    padding: 1em 1em 0;
    border: 1px solid #999;
}
legend {
    margin: 0;
    padding: 0 .1em;
}
label {
    vertical-align: middle;
    cursor: pointer;
}

input,
textarea,
button,
select,
optgroup,
option {
    font: inherit;
    font-weight: normal;
    color: #333;
    background-color: #fff;
    line-height: 1;
    margin: 0;
    vertical-align: middle;
    -moz-box-sizing: border-box;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
}

optgroup {
    font-style: italic;
    font-weight: bold;
}
option {
    font-style: normal;
    font-weight: normal;
}

input,
textarea,
select {
    border: 1px solid #ccc;
    box-shadow: inset 0 0 1px #eee;
    border-radius: 2px;
}
input:active,
input:focus,
textarea:active,
textarea:focus,
select:active,
select:focus {
    border-color: #999;
}
input[type=radio],
input[type=checkbox] {
    padding: 0;
    border-style: none;
    box-shadow: none;
}

/* all types of buttons */
input[type=submit],
input.button,
a.button,
button,
.qq-upload-button {
    color: #333;
    background-color: #eee;
    background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIHZpZXdCb3g9IjAgMCAxIDEiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPgo8bGluZWFyR3JhZGllbnQgaWQ9Imc4MjQiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiB4MT0iMCUiIHkxPSIwJSIgeDI9IjAlIiB5Mj0iMTAwJSI+CjxzdG9wIHN0b3AtY29sb3I9IiNGRkZGRkYiIG9mZnNldD0iMCIvPjxzdG9wIHN0b3AtY29sb3I9IiNGNEY0RjQiIG9mZnNldD0iMC4zIi8+PHN0b3Agc3RvcC1jb2xvcj0iI0VFRUVFRSIgb2Zmc2V0PSIwLjk5Ii8+PHN0b3Agc3RvcC1jb2xvcj0iI0NDQ0NDQyIgb2Zmc2V0PSIuOTkiLz4KPC9saW5lYXJHcmFkaWVudD4KPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEiIGhlaWdodD0iMSIgZmlsbD0idXJsKCNnODI0KSIgLz4KPC9zdmc+);
    /*background: -moz-linear-gradient(   top, #ffffff 0%, #f4f4f4 30%, #eeeeee 99%, #cccccc 99%); see FS#2447*/
    background: -webkit-linear-gradient(top, #ffffff 0%, #f4f4f4 30%, #eeeeee 99%, #cccccc 99%);
    background: -o-linear-gradient(     top, #ffffff 0%, #f4f4f4 30%, #eeeeee 99%, #cccccc 99%);
    background: -ms-linear-gradient(    top, #ffffff 0%, #f4f4f4 30%, #eeeeee 99%, #cccccc 99%);
    background: linear-gradient(        top, #ffffff 0%, #f4f4f4 30%, #eeeeee 99%, #cccccc 99%);
    border: 1px solid #ccc;
    border-radius: 2px;
    padding: .1em .5em;
    cursor: pointer;
}
#IE7 input.button,
#IE7 button {
    line-height: 1.4;
}

input[type=submit]:hover,
input[type=submit]:active,
input[type=submit]:focus,
input.button:hover,
input.button:active,
input.button:focus,
a.button:hover,
a.button:active,
a.button:focus,
button:hover,
button:active,
button:focus,
.qq-upload-button:hover {
    border-color: #999;
    background-color: #ddd;
    background-image:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIHZpZXdCb3g9IjAgMCAxIDEiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPgo8bGluZWFyR3JhZGllbnQgaWQ9Imc2NzAiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiB4MT0iMCUiIHkxPSIwJSIgeDI9IjAlIiB5Mj0iMTAwJSI+CjxzdG9wIHN0b3AtY29sb3I9IiNGRkZGRkYiIG9mZnNldD0iMCIvPjxzdG9wIHN0b3AtY29sb3I9IiNGNEY0RjQiIG9mZnNldD0iMC4zIi8+PHN0b3Agc3RvcC1jb2xvcj0iI0RERERERCIgb2Zmc2V0PSIwLjk5Ii8+PHN0b3Agc3RvcC1jb2xvcj0iI0JCQkJCQiIgb2Zmc2V0PSIuOTkiLz4KPC9saW5lYXJHcmFkaWVudD4KPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEiIGhlaWdodD0iMSIgZmlsbD0idXJsKCNnNjcwKSIgLz4KPC9zdmc+);
    /*background: -moz-linear-gradient(   top, #ffffff 0%, #f4f4f4 30%, #dddddd 99%, #cccccc 99%); see FS#2447*/
    background: -webkit-linear-gradient(top, #ffffff 0%, #f4f4f4 30%, #dddddd 99%, #bbbbbb 99%);
    background: -o-linear-gradient(     top, #ffffff 0%, #f4f4f4 30%, #dddddd 99%, #bbbbbb 99%);
    background: -ms-linear-gradient(    top, #ffffff 0%, #f4f4f4 30%, #dddddd 99%, #bbbbbb 99%);
    background: linear-gradient(        top, #ffffff 0%, #f4f4f4 30%, #dddddd 99%, #bbbbbb 99%);
}

input::-moz-focus-inner,
button::-moz-focus-inner {
    border: 0;
    padding: 0;
}

input[disabled],
button[disabled],
input[readonly],
button[readonly] {
    cursor: auto;
}
/**
 * This file provides styles for the image detail page (detail.php).
 */

#dokuwiki__detail {
    padding: 1em;
}
#dokuwiki__detail h1 {
}

#dokuwiki__detail img {
    float: left;
    margin: 0 1.5em .5em 0;
}
[dir=rtl] #dokuwiki__detail div.content img {
    float: right;
    margin-right: 0;
    margin-left: 1.5em;
}
#dokuwiki__detail div.img_detail {
    float: left;
}
[dir=rtl] #dokuwiki__detail div.content div.img_detail {
    float: right
}

#dokuwiki__detail div.img_detail h2 {
}
#dokuwiki__detail div.img_detail dl {
}
#dokuwiki__detail div.img_detail dl dt {
}
#dokuwiki__detail div.img_detail dl dd {
}

#dokuwiki__detail p.back {
    clear: both;
}
/**
 * This file provides styles for the media manager popup
 * (mediamanager.php).
 */

/*____________ structure ____________*/

html.popup {
    overflow: auto;
}

#media__manager {
    height: 100%;
    overflow: hidden;
}

#mediamgr__aside {
    width: 30%;
    height: 100%;
    overflow: auto;
    position: absolute;
    left: 0;
    border-right: 1px solid #ccc;
}
[dir=rtl] #mediamgr__aside {
    left: auto;
    right: 0;
    border-right-width: 0;
    border-left: 1px solid #ccc;
}
#mediamgr__aside .pad {
    padding: .5em;
}

#mediamgr__content {
    width: 69.7%;
    height: 100%;
    overflow: auto;
    position: absolute;
    right: 0;
}
[dir=rtl] #mediamgr__content {
    right: auto;
    left: 0;
}
#mediamgr__content .pad {
    padding: .5em;
}

#media__manager h1,
#media__manager h2 {
    font-size: 1.5em;
    margin-bottom: .5em;
    padding-bottom: .2em;
    border-bottom: 1px solid #ccc;
}

/* left side
********************************************************************/

/*____________ options ____________*/

#media__opts {
    margin-bottom: .5em;
}

#media__opts input {
    margin-right: .3em;
}
[dir=rtl] #media__opts input {
    margin-right: 0;
    margin-left: .3em;
}
#media__opts label {
}

/*____________ tree ____________*/

#media__tree ul {
    padding-left: .2em;
}
[dir=rtl] #media__tree ul {
    padding-left: 0;
    padding-right: .2em;
}
#media__tree ul li {
    clear: left;
    list-style-type: none;
    list-style-image: none;
    margin-left: 0;
}
[dir=rtl] #media__tree ul li {
    clear: right;
    margin-right: 0;
}
#media__tree ul li img {
    float: left;
    padding: .5em .3em 0 0;
}
[dir=rtl] #media__tree ul li img {
    float: right;
    padding: .5em 0 0 .3em;
}
#media__tree ul li div.li {
    display: inline;
}
#media__tree ul li li {
    margin-left: 1.5em;
}
[dir=rtl] #media__tree ul li li {
    margin-left: 0;
    margin-right: 1.5em;
}

/* right side
********************************************************************/

/*____________ upload form ____________*/

/* upload info */
#media__content div.upload {
    font-size: .9em;
    margin-bottom: .5em;
}

#mediamanager__uploader {
    margin-bottom: 1em;
}
#mediamanager__uploader p {
    margin-bottom: .5em;
}

/*____________ file list ____________*/

#media__content img.load {
    margin: 1em auto;
}

#media__content .odd,
#media__content .even {
    padding: .5em;
}
#media__content .odd {
    background-color: #eee;
}
#media__content .even {
}
/* highlight newly uploaded or edited file */
#media__content #scroll__here {
    border: 1px dashed #ccc;
}

/* link which inserts media file */
#media__content a.mediafile {
    margin-right: 1.5em;
    font-weight: bold;
}
[dir=rtl] #media__content a.mediafile {
    margin-right: 0;
    margin-left: 1.5em;
}
#media__content span.info {
}
#media__content img.btn {
    vertical-align: text-bottom;
}

/* info how to insert media, if JS disabled */
#media__content div.example {
    color: #666;
    margin-left: 1em;
}

#media__content div.detail {
    padding: .2em 0;
}
#media__content div.detail div.thumb {
    float: left;
    margin: 0 .5em 0 18px;
}
[dir=rtl] #media__content div.detail div.thumb {
    float: right;
    margin: 0 18px 0 .5em;
}
#media__content div.detail div.thumb a {
    display: block;
    cursor: pointer;
}
#media__content div.detail p {
    margin-bottom: 0;
}


/*____________ media search ____________*/

#dw__mediasearch {
}
#dw__mediasearch p {
}
#dw__mediasearch label {
}
#dw__mediasearch label span {
}
#dw__mediasearch input.edit {
}
#dw__mediasearch input.button {
}


/* meta edit form
********************************************************************/

#media__content form.meta {
}

#media__content form.meta div.metafield {
    clear: left;
    margin-bottom: .5em;
    overflow: hidden;
}
[dir=rtl] #media__content form.meta div.metafield {
    clear: right;
}

#media__content form.meta label {
    display: block;
    width: 25%;
    float: left;
    font-weight: bold;
    clear: left;
}
[dir=rtl] #media__content form.meta label {
    float: right;
    clear: right;
}
#media__content form.meta .edit {
    float: left;
    width: 70%;
    margin: 0;
}
[dir=rtl] #media__content form.meta .edit {
    float: right;
}
#media__content form.meta textarea.edit {
    /* needed because of IE8 hack in _edit.css for textarea.edit: */
    max-width: 70%;
    min-width: 70%;
}

#media__content form.meta div.buttons {
    clear: left;
    margin: .2em 0 0 25%;
}
[dir=rtl] #media__content form.meta div.buttons {
    clear: right;
    margin: .2em 25% 0 0;
}
/**
 * This file provides the styles for the fullscreen media manager
 * (?do=media).
 *
 * What most templates would probably need to change (depending on
 * their site width) are the 4 min-width's (search for @change).
 */


/*____________ structure ____________*/

#mediamanager__page h1 {
    margin-bottom: .5em;
}

#mediamanager__page {
    /* min-width must be summary of all 3 panels' min-widths */
    min-width: 50em; /* @change */
    width: 100%;
    text-align: left;
}

#mediamanager__page .panel {
    float: left;
}

#mediamanager__page .namespaces {
    width: 20%;
    min-width: 10em; /* @change */
}
#mediamanager__page .filelist {
    width: 50%;
    min-width: 25em; /* @change */
}
#mediamanager__page .file {
    width: 30%;
    min-width: 15em; /* @change */
}

#mediamanager__page .panelHeader {
    background-color: #eee;
    margin: 0 10px 10px 0;
    padding: 10px 10px 8px;
    text-align: left;
    min-height: 20px;
    overflow: hidden;
}

#mediamanager__page .panelContent {
    overflow-y: auto;
    overflow-x: hidden;
    padding: 0;
    margin: 0 10px 10px 0;
    position: relative;
}
[dir=rtl] #mediamanager__page .panelContent {
    text-align: right;
}

#mediamanager__page .file .panelHeader,
#mediamanager__page .file .panelContent {
    margin-right: 0;
}

#mediamanager__page .ui-resizable-e {
    width: 6px;
    right: 2px;
    background: transparent url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/resizecol.png) center center no-repeat;
}
#mediamanager__page .ui-resizable-e:hover {
    background-color: #eee;
}


#mediamanager__page dd {
    margin: 0;
}

#mediamanager__page .panelHeader h3 {
    float: left;
    font-weight: normal;
    font-size: 1em;
    padding: 0;
    margin: 0 0 3px;
}


/*____________ namespaces panel ____________*/

[dir=rtl] #mediamanager__page .namespaces {
    text-align: right;
}

/* make it look like a tab (as in _tabs.css) */
#mediamanager__page .namespaces h2 {
    font-size: 1em;
    display: inline-block;
    padding: .3em .8em;
    margin: 0 0 0 .3em;
    border-radius: .5em .5em 0 0;
    font-weight: normal;
    background-color: #eee;
    color: #333;
    border: 1px solid #ccc;
    border-bottom-color: #eee;
    line-height: 1.4em;
    position: relative;
    bottom: -1px;
    z-index: 2;
}
* html #mediamanager__page .namespaces h2,
*+html #mediamanager__page .namespaces h2 {
    display: inline;
}
[dir=rtl] #mediamanager__page .namespaces h2 {
    margin: 0 .3em 0 0;
    position: relative;
    right: 10px;
}
#mediamanager__page .namespaces .panelHeader {
    border-top: 1px solid #ccc;
    z-index: 1;
}

#mediamanager__page .namespaces ul {
    margin-left: .2em;
    margin-bottom: 0;
    padding: 0;
    list-style: none;
}
[dir=rtl] #mediamanager__page .namespaces ul {
    margin-left: 0;
    margin-right: .2em;
}
#mediamanager__page .namespaces ul ul {
    margin-left: 1em;
}
[dir=rtl] #mediamanager__page .namespaces ul ul {
    margin-left: 0;
    margin-right: 1em;
}
#mediamanager__page .namespaces ul ul li {
    margin: 0;
}

#mediamanager__page .namespaces ul .selected {
    background-color: #ff9;
    font-weight: bold;
}


/*____________ file list panel ____________*/

/* file list header */

#mediamanager__page .panelHeader form.options {
    float: right;
    margin-top: -3px;
}

#mediamanager__page .panelHeader ul {
    list-style: none;
    margin: 0;
    padding: 0;
}
#mediamanager__page .panelHeader ul li {
    color: #333;
    float: left;
    line-height: 1;
    padding-left: 3px;
}
[dir=rtl] #mediamanager__page .panelHeader ul li {
    margin-right: 0;
    margin-left: .5em;
}

#mediamanager__page .panelHeader ul li.listType {
    padding-left: 30px;
    margin: 0 0 0 5px;
    background: url('/wiki/pm/lib/tpl/dokuwiki_modif/../../images/icon-list.png') 3px 1px no-repeat;
}
#mediamanager__page .panelHeader ul li.sortBy {
    padding-left: 30px;
    margin: 0 0 0 5px;
    background: url('/wiki/pm/lib/tpl/dokuwiki_modif/../../images/icon-sort.png') 3px 1px no-repeat;
}

#mediamanager__page .panelHeader form.options .ui-buttonset label{
    font-size: 90%;
    margin-right: -0.4em;
}
#mediamanager__page .panelHeader form.options .ui-buttonset .ui-button-text {
    padding: .3em .5em;
    line-height: 1;
}

/* file list content */

#mediamanager__page .filelist ul {
    padding: 0;
    margin: 0 10px 0 0;
}
[dir=rtl] #mediamanager__page .filelist ul {
    margin: 0 10px 0 0;
}

#mediamanager__page .filelist .panelContent ul li:hover {
    background-color: #eee;
}

#mediamanager__page .filelist li dt a {
    vertical-align: middle;
    display: table-cell;
    overflow: hidden;
}
* html #mediamanager__page .filelist .thumbs li dt a,
*+html #mediamanager__page .filelist .thumbs li dt a {
    display: block;
}
* html #mediamanager__page .filelist .rows li dt a,
*+html #mediamanager__page .filelist .rows li dt a {
    display: inline;
}

/* file list as thumbs */

#mediamanager__page .filelist .thumbs li {
    width: 100px;
    min-height: 130px;
    display: inline-block;
    display: -moz-inline-stack;
    /* the right margin should visually be 10px, but because of its inline-block nature the whitespace inbetween is about 4px more */
    margin: 0 6px 10px 0;
    background-color: #ddd;
    color: #333;
    padding: 5px;
    vertical-align: top;
    text-align: center;
    position: relative;
    line-height: 1.2;
}
[dir=rtl] #mediamanager__page .filelist .thumbs li {
    margin-right: 0;
    margin-left: 6px;
}
* html #mediamanager__page .filelist .thumbs li,
*+html #mediamanager__page .filelist .thumbs li {
    display: inline;
    zoom: 1;
}

#mediamanager__page .filelist .thumbs li dt a {
    width: 100px;
    height: 90px;
}

#mediamanager__page .filelist .thumbs li dt a img {
    max-width: 90px;
    max-height: 90px;
}

#mediamanager__page .filelist .thumbs li .name,
#mediamanager__page .filelist .thumbs li .size,
#mediamanager__page .filelist .thumbs li .filesize,
#mediamanager__page .filelist .thumbs li .date {
    display: block;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 90px;
    white-space: nowrap;
}
#mediamanager__page .filelist .thumbs li .name {
    padding: 5px 0;
    font-weight: bold;
}
#mediamanager__page .filelist .thumbs li .date {
    font-style: italic;
    white-space: normal;
}

/* file list as rows */

#mediamanager__page .filelist .rows li {
    list-style: none;
    display: block;
    position: relative;
    max-height: 50px;
    margin: 0;
    margin-bottom: 3px;
    background-color: #fff;
    color: #333;
    overflow: hidden;
}

#mediamanager__page .filelist .rows li:nth-child(2n+1) {
    background-color: #ddd;
}

#mediamanager__page .filelist .rows li dt {
    float: left;
    width: 10%;
    height: 40px;
    text-align: center;
}

#mediamanager__page .filelist .rows li dt a {
    width: 100px;
    height: 40px;
}

#mediamanager__page .filelist .rows li dt a img {
    max-width: 40px;
    max-height: 40px;
}

#mediamanager__page .filelist .rows li .name,
#mediamanager__page .filelist .rows li .size,
#mediamanager__page .filelist .rows li .filesize,
#mediamanager__page .filelist .rows li .date {
    overflow: hidden;
    text-overflow: ellipsis;
    float: left;
    margin-left: 1%;
    white-space: nowrap;
}

#mediamanager__page .filelist .rows li .name {
    width: 30%;
    font-weight: bold;
}
#mediamanager__page .filelist .rows li .size,
#mediamanager__page .filelist .rows li .filesize {
    width: 15%;
}
#mediamanager__page .filelist .rows li .date {
    width: 20%;
    font-style: italic;
    white-space: normal;
}

/* upload form */

#mediamanager__page div.upload {
    padding-bottom: 0.5em;
}

/*____________ file panel ____________*/

#mediamanager__page .file ul.actions {
    text-align: center;
    margin: 0 0 5px;
    padding: 0;
    list-style: none;
}
#mediamanager__page .file ul.actions li {
    display: inline;
    margin: 0;
}

#mediamanager__page .file div.image {
    margin-bottom: 5px;
    text-align: center;
}

#mediamanager__page .file div.image img {
    width: 100%;
}

#mediamanager__page .file dl {
    margin-bottom: 0;
}
#mediamanager__page .file dl dt {
    font-weight: bold;
    display: block;
    background-color: #eee;
}
#mediamanager__page .file dl dd {
    display: block;
    background-color: #ddd;
}


/* file meta data edit form */

#mediamanager__page form.meta div.row {
    margin-bottom: 5px;
}

#mediamanager__page form.meta label span {
    display: block;
}

#mediamanager__page form.meta input {
    width: 50%;
}

#mediamanager__page form.meta input.button {
    width: auto;
}

#mediamanager__page form.meta textarea.edit {
    height: 6em;
    width: 95%;
    min-width: 95%;
    max-width: 95%;
}

/* file revisions form */

#mediamanager__page #page__revisions ul {
    margin-left: 10px;
    padding: 0;
    list-style-type: none;
}

#mediamanager__page #page__revisions ul li div.li div {
    font-size: 90%;
    color: #666;
    padding-left: 18px;
}

#mediamanager__page #page__revisions ul li div.li input {
    position: relative;
    top: 1px;
}

/* file diff view */

#mediamanager__diff table {
    table-layout: fixed;
    border-width: 0;
}

#mediamanager__diff td,
#mediamanager__diff th {
    width: 48%;
    margin: 0 5px 10px 0;
    padding: 0;
    vertical-align: top;
    text-align: left;
    border-color: #fff;
}
[dir=rtl] #mediamanager__diff td,
[dir=rtl] #mediamanager__diff th {
    text-align: right;
}

#mediamanager__diff th {
    font-weight: normal;
    background-color: #fff;
    line-height: 1.2;
}
#mediamanager__diff th a {
    font-weight: bold;
}
#mediamanager__diff th span {
    font-size: 90%;
}

#mediamanager__diff dl dd strong{
    background-color: #ff9;
    color: #333;
    font-weight: normal;
}

/* image diff views */

#mediamanager__page .file form.diffView {
    margin-bottom: 10px;
    display: block;
}

#mediamanager__diff div.slider {
    margin: 10px;
    width: 95%;
}

#mediamanager__diff .imageDiff {
    position: relative;
}
#mediamanager__diff .imageDiff .image2 {
    position: absolute;
    top: 0;
    left: 0;
}

#mediamanager__diff .imageDiff.opacity .image2 {
    opacity: 0.5;
}

#mediamanager__diff .imageDiff.portions .image2 {
    border-right: 1px solid red;
    overflow: hidden;
}

#mediamanager__diff .imageDiff.portions img {
    float: left;
}

#mediamanager__diff .imageDiff img {
    width: 100%;
    max-width: none;
}

/**
 * This file provides the styles for the file uploader
 * used in the media manager (both fullscreen and popup).
 */

.qq-uploader {
    position: relative;
    width: 100%;
}

.qq-uploader .error {
    color: #f00;
    background-color: #fff;
}

/* select file button */

.qq-upload-button {
    display: inline-block;
    text-decoration: none;
    font-size: 100%;
    cursor: pointer;
    margin: 1px 1px 5px;
}

* html .qq-upload-button,
*+html .qq-upload-button {
    display: inline;
}

.qq-upload-button-focus {
    outline: 1px dotted;
}

/* drop area */

.qq-upload-drop-area {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    min-height: 70px;
    z-index: 2;
    background: #ddd;
    color: #333;
    text-align: center;
}

.qq-upload-drop-area span {
    display: block;
    position: absolute;
    top: 50%;
    width: 100%;
    margin-top: -8px;
    font-size: 120%;
}

.qq-upload-drop-area-active {
    background: #eee;
}

/* list of files to upload */

div.qq-uploader ul {
    margin: 0;
    padding: 0;
    list-style: none;
}

.qq-uploader li {
    margin: 0 0 5px;
    color: #333;
}

.qq-uploader li span,
.qq-uploader li input,
.qq-uploader li a {
    margin-right: 5px;
}

.qq-upload-file {
    display: block;
    font-weight: bold;
}

.qq-upload-spinner {
    display: inline-block;
    background: url("/wiki/pm/lib/tpl/dokuwiki_modif/../../images/throbber.gif");
    width: 15px;
    height: 15px;
    vertical-align: text-bottom;
}

.qq-upload-size,
.qq-upload-cancel {
    font-size: 85%;
}

.qq-upload-failed-text {
    display: none;
}
.qq-upload-fail .qq-upload-failed-text {
    display: inline;
}

.qq-action-container * {
    vertical-align: middle;
}
.qq-overwrite-check input {
    margin-left: 10px;
}
/**
 * This file provides the styles for general tabs.
 */

.dokuwiki .tabs > ul,
.dokuwiki ul.tabs {
    padding: 0;
    margin: 0;
    overflow: hidden;
    position: relative;
}
/* border underneath */
.dokuwiki .tabs > ul:after,
.dokuwiki ul.tabs:after {
    position: absolute;
    content: "";
    width: 100%;
    bottom: 0;
    left: 0;
    border-bottom: 1px solid #ccc;
    z-index: 1;
}

.dokuwiki .tabs > ul li,
.dokuwiki ul.tabs li {
    float: left;
    padding: 0;
    margin: 0;
    list-style: none;
}
[dir=rtl] .dokuwiki .tabs > ul li,
[dir=rtl] .dokuwiki ul.tabs li {
    float: right;
}

.dokuwiki .tabs > ul li a,
.dokuwiki ul.tabs li strong,
.dokuwiki ul.tabs li a {
    display: inline-block;
    padding: .3em .8em;
    margin: 0 0 0 .3em;
    background-color: #ddd;
    color: #333;
    border: 1px solid #ccc;
    border-radius: .5em .5em 0 0;
    position: relative;
    z-index: 0;
}
[dir=rtl] .dokuwiki .tabs > ul li a,
[dir=rtl] .dokuwiki ul.tabs li strong,
[dir=rtl] .dokuwiki ul.tabs li a {
    margin: 0 .3em 0 0;
}

.dokuwiki ul.tabs li strong {
    font-weight: normal;
}

.dokuwiki ul.tabs li a:link,
.dokuwiki ul.tabs li a:visited {
}
.dokuwiki .tabs > ul li a:hover,
.dokuwiki .tabs > ul li a:active,
.dokuwiki .tabs > ul li a:focus,
.dokuwiki .tabs > ul li .curid a,
.dokuwiki .tabs > ul .active a,
.dokuwiki ul.tabs li a:hover,
.dokuwiki ul.tabs li a:active,
.dokuwiki ul.tabs li a:focus,
.dokuwiki ul.tabs li strong {
    background-color: #eee;
    color: #333;
    text-decoration: none;
    font-weight: normal;
}

.dokuwiki .tabs > ul li .curid a,
.dokuwiki .tabs > ul li .active a,
.dokuwiki ul.tabs li strong {
    z-index: 2;
    border-bottom-color: #eee;
}
/**
 * This file provides styles for all types of links.
 */

/*____________ links to wiki pages ____________*/

/* existing wikipage */
.dokuwiki a.wikilink1 {
}
/* not existing wikipage */
.dokuwiki a.wikilink2 {
    text-decoration: none;
}
.dokuwiki a.wikilink2:link,
.dokuwiki a.wikilink2:visited {
    border-bottom: 1px dashed;
}
.dokuwiki a.wikilink2:hover,
.dokuwiki a.wikilink2:active,
.dokuwiki a.wikilink2:focus {
    border-bottom-width: 0;
}

/* any link to current page */
.dokuwiki span.curid a {
    font-weight: bold;
}

/*____________ other link types ____________*/

.dokuwiki a.urlextern,
.dokuwiki a.windows,
.dokuwiki a.mail,
.dokuwiki a.mediafile,
.dokuwiki a.interwiki {
    background-repeat: no-repeat;
    background-position: 0 center;
    padding: 0 0 0 18px;
}
/* external link */
.dokuwiki a.urlextern {
    background-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/external-link.png);
}
/* windows share */
.dokuwiki a.windows {
    background-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/unc.png);
}
/* email link */
.dokuwiki a.mail {
    background-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/email.png);
}

/* icons of the following are set by dokuwiki in lib/exe/css.php */
/* link to some embedded media */
.dokuwiki a.mediafile {
}
/* interwiki link */
.dokuwiki a.interwiki {
}

/* RTL corrections; if link icons don't work as expected, remove the following lines */
[dir=rtl] .dokuwiki a.urlextern,
[dir=rtl] .dokuwiki a.windows,
[dir=rtl] .dokuwiki a.mail,
[dir=rtl] .dokuwiki a.interwiki,
[dir=rtl] .dokuwiki a.mediafile {
    background-position: right center;
    padding: 0 18px 0 0;
    display: inline-block; /* needed for IE7 */
}
/**
 * This file provides styles for the TOC (table of contents), the
 * sitemap (?do=index) and backlinks (?do=backlink).
 */

/* toc
********************************************************************/

/* toc container */
#dw__toc {
    float: right;
    margin: 0 0 1.4em 1.4em;
    width: 12em;
    background-color: #eee;
    color: inherit;
}
[dir=rtl] #dw__toc {
    float: left;
    margin: 0 1.4em 1.4em 0;
}

/*____________ toc header ____________*/

.dokuwiki h3.toggle {
    padding: .2em .5em;
    font-weight: bold;
}

.dokuwiki .toggle strong {
    float: right;
    margin: 0 .2em;
}
[dir=rtl] .dokuwiki .toggle strong {
    float: left;
}

/*____________ toc list ____________*/

#dw__toc > div {
    padding: .2em .5em;
}
#dw__toc ul {
    padding: 0;
    margin: 0;
}
#dw__toc ul li {
    list-style: none;
    padding: 0;
    margin: 0;
    line-height: 1.1;
}
#dw__toc ul li div.li {
    padding: .15em 0;
}
#dw__toc ul ul {
    padding-left: 1em;
}
[dir=rtl] #dw__toc ul ul {
    padding-left: 0;
    padding-right: 1em;
}
#dw__toc ul ul li {
}
#dw__toc ul li a {
}

/* in case of toc list jumping one level
  (e.g. if heading level 3 follows directly after heading level 1) */
#dw__toc ul li.clear {
}


/* sitemap (and backlinks)
********************************************************************/

.dokuwiki ul.idx {
    padding-left: 0;
}
[dir=rtl] .dokuwiki ul.idx {
    padding-right: 0;
}
.dokuwiki ul.idx li {
    list-style-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/bullet.png);
}
.dokuwiki ul.idx li.open {
    list-style-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/open.png);
}
.dokuwiki ul.idx li.closed {
    list-style-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/closed.png);
}
[dir=rtl] .dokuwiki ul.idx li.closed {
    list-style-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/closed-rtl.png);
}
/**
 * This file provides styles for footnotes.
 */

/*____________ footnotes inside the text ____________*/

/* link to footnote inside the text */
.dokuwiki sup a.fn_top {
}
/* JSpopup */
div.insitu-footnote {
    max-width: 40%;
    min-width: 5em;
}

/*____________ footnotes at the bottom of the page ____________*/

.dokuwiki div.footnotes {
    border-top: 1px solid #ccc;
    padding: .5em 0 0 0;
    margin: 1em 0 0 0;
    clear: both;
}
.dokuwiki div.footnotes div.fn {
}
.dokuwiki div.footnotes div.fn sup a.fn_bot {
    font-weight: bold;
}
/**
 * This file provides styles for the search results page (?do=search)
 * and the AJAX search popup.
 */

/* search results page
********************************************************************/

/* loading gif */
#dw__loading {
    text-align: center;
    margin-bottom: 1.4em;
}

/*____________ matching pagenames ____________*/

.dokuwiki div.search_quickresult {
    margin-bottom: 1.4em;
}
.dokuwiki div.search_quickresult h3 {
}
.dokuwiki div.search_quickresult ul {
    padding: 0;
}
.dokuwiki div.search_quickresult ul li {
    float: left;
    width: 12em;
    margin: 0 1.5em;
}
[dir=rtl] .dokuwiki div.search_quickresult ul li {
    float: right;
}

/*____________ search results ____________*/

.dokuwiki dl.search_results {
    margin-bottom: 1.2em;
}

/* search heading */
.dokuwiki dl.search_results dt {
    font-weight: normal;
    margin-bottom: .2em;
}
/* search snippet */
.dokuwiki dl.search_results dd {
    color: #999;
    background-color: inherit;
    margin: 0 0 1.2em 0;
}

/* search hit in normal text */
.dokuwiki .search_hit {
    color: #333;
    background-color: #ff9;
}
/* search hit in search results */
.dokuwiki .search_results strong.search_hit {
    font-weight: normal;
}
/* ellipsis separating snippets */
.dokuwiki .search_results .search_sep {
    color: #333;
    background-color: inherit;
}

/* "nothing found" at search + media */
.dokuwiki div.nothing {
    margin-bottom: 1.4em;
}


/* AJAX quicksearch popup
********************************************************************/

.dokuwiki form.search div.no {
    position: relative;
}

/* .JSpopup */
.dokuwiki form.search div.ajax_qsearch {
    position: absolute;
    top: 0;
    left: -13.5em; /* -( width of #qsearch__in + padding of .ajax_qsearch + a bit more ) */
    width: 12em;
    padding: 0.5em;
    font-size: .9em;
    z-index: 20;
    text-align: left;
    display: none;
}
[dir=rtl] .dokuwiki form.search div.ajax_qsearch {
    left: auto;
    right: -13.5em;
    text-align: right;
}
.dokuwiki form.search div.ajax_qsearch strong {
    display: block;
    margin-bottom: .3em;
}
.dokuwiki form.search div.ajax_qsearch ul {
    margin: 0 !important;
    padding: 0 !important;
}
.dokuwiki form.search div.ajax_qsearch ul li {
    margin: 0;
    padding: 0;
    display: block !important;
}
/**
 * This file provides styles for the recent changes (?do=recent) and
 * old revisions (?do=revisions).
 */

/*____________ list of revisions / recent changes ____________*/

/* select type of revisions (media/pages) */
.dokuwiki .changeType {
    margin-bottom: .5em;
}

.dokuwiki form.changes ul li {
    list-style: none;
    margin-left: 0;
}
[dir=rtl] .dokuwiki form.changes ul li {
    margin-right: 0;
}
.dokuwiki form.changes ul li span,
.dokuwiki form.changes ul li a {
    vertical-align: middle;
}
.dokuwiki form.changes ul li span.user a {
    vertical-align: bottom;
}
.dokuwiki form.changes ul li.minor {
    opacity: .7;
}

.dokuwiki form.changes li span.date {
}
.dokuwiki form.changes li a.diff_link {
    vertical-align: baseline;
}
.dokuwiki form.changes li a.revisions_link {
    vertical-align: baseline;
}
.dokuwiki form.changes li a.wikilink1,
.dokuwiki form.changes li a.wikilink2 {
}
.dokuwiki form.changes li span.sum {
    font-weight: bold;
}
.dokuwiki form.changes li span.user {
}


/*____________ page navigator ____________*/

.dokuwiki div.pagenav {
    text-align: center;
    margin: 1.4em 0;
}
.dokuwiki div.pagenav-prev,
.dokuwiki div.pagenav-next {
    display: inline;
    margin: 0 .5em;
}
/**
 * This file provides styles for the diff view, which shows you
 * differences between two versions of a page (?do=diff).
 */

.dokuwiki table.diff {
    width: 100%;
    border-width: 0;
}
.dokuwiki table.diff th,
.dokuwiki table.diff td {
    vertical-align: top;
    padding: 0;
    border-width: 0;
    /* no style.ini colours because deleted and added lines have a fixed background colour */
    background-color: #fff;
    color: #333;
}

/* table header */
.dokuwiki table.diff th {
    border-bottom: 1px solid #ccc;
    font-size: 110%;
    width: 50%;
    font-weight: normal;
}
.dokuwiki table.diff th a {
    font-weight: bold;
}
.dokuwiki table.diff th span.user {
    font-size: .9em;
}
.dokuwiki table.diff th span.sum {
    font-size: .9em;
    font-weight: bold;
}
.dokuwiki table.diff th.minor {
    color: #999;
}

/* table body */
.dokuwiki table.diff td {
    font-family: Consolas, "Andale Mono WT", "Andale Mono", "Bitstream Vera Sans Mono", "Nimbus Mono L", Monaco, "Courier New", monospace;
}
.dokuwiki table.diff td.diff-blockheader {
    font-weight: bold;
}
.dokuwiki table.diff .diff-addedline {
    background-color: #cfc;
    color: inherit;
}
.dokuwiki table.diff .diff-deletedline {
    background-color: #fdd;
    color: inherit;
}
.dokuwiki table.diff td.diff-context {
    background-color: #eee;
    color: inherit;
}
.dokuwiki table.diff td.diff-addedline strong,
.dokuwiki table.diff td.diff-deletedline strong {
    color: #f00;
    background-color: inherit;
    font-weight: bold;
}
/**
 * This file provides styles for the edit view (?do=edit), preview
 * and section edit buttons.
 */

/* edit view
********************************************************************/

.dokuwiki div.editBox {
}

/*____________ toolbar ____________*/

.dokuwiki div.toolbar {
    margin-bottom: .5em;
    overflow: hidden;
}
#draft__status {
    float: right;
    color: #999;
    background-color: inherit;
}
[dir=rtl] #draft__status {
    float: left;
}
#tool__bar {
    float: left;
}
[dir=rtl] #tool__bar {
    float: right;
}

/* buttons inside of toolbar */
.dokuwiki div.toolbar button.toolbutton {
}
/* picker popups (outside of .dokuwiki) */
div.picker {
    width: 300px;
    border: 1px solid #ccc;
    background-color: #eee;
    color: inherit;
}
/* picker for headlines */
div.picker.pk_hl {
    width: auto;
}

/* buttons inside of picker */
div.picker button.pickerbutton,
div.picker button.toolbutton {
    padding: .1em .35em;
    border-width: 0;
}

/*____________ edit textarea ____________*/

.dokuwiki textarea.edit {
    /* should just be "width: 100%", but IE8 doesn't like it, see FS#1910 + FS#1667 */
    width: 700px;
    min-width: 100%;
    max-width: 100%;
    margin-bottom: .5em;
}

/*____________ below the textarea ____________*/

.dokuwiki div.editBar {
    overflow: hidden;
    margin-bottom: .5em;
}

/* size and wrap controls */
#size__ctl {
    float: right;
}
[dir=rtl] #size__ctl {
    float: left;
}
#size__ctl img {
    cursor: pointer;
}

/* edit buttons */
.dokuwiki .editBar .editButtons {
    display: inline;
    margin-right: 1em;
}
[dir=rtl] .dokuwiki .editBar .editButtons {
    margin-right: 0;
    margin-left: 1em;
}
.dokuwiki .editBar .editButtons input {
}

/* summary input and minor changes checkbox */
.dokuwiki .editBar .summary {
    display: inline;
}
.dokuwiki .editBar .summary label {
    vertical-align: middle;
    white-space: nowrap;
}
.dokuwiki .editBar .summary label span {
    vertical-align: middle;
}
.dokuwiki .editBar .summary input {
}
/* change background colour if summary is missing */
.dokuwiki .editBar .summary input.missing {
    color: #333;
    background-color: #ffcccc;
}

/* preview
********************************************************************/

.dokuwiki div.preview {
    border: dotted #ccc;
    border-width: .2em 0;
    padding: 1.4em 0;
    margin-bottom: 1.4em;
}

/* section edit buttons
********************************************************************/

.dokuwiki .secedit {
    float: right;
    margin-top: -1.4em;
}
[dir=rtl] .dokuwiki .secedit {
    float: left;
}
.dokuwiki .secedit input.button {
    font-size: 75%;
}

/* style for section highlighting */
.dokuwiki div.section_highlight {
    margin: 0 -1em; /* negative side margin = side padding + side border */
    padding: 0 .5em;
    border: solid #eee;
    border-width: 0 .5em;
}
/**
 * This file provides styles for modal dialogues.
 */

.dokuwiki .ui-widget {
    font-size: 100%;
}


/* link wizard (opens from the link button in the edit toolbar)
********************************************************************/

#link__wiz {
}

[dir=rtl] #link__wiz_close {
    float: left;
}

#link__wiz_result {
    background-color: #fff;
    width:  293px;
    height: 193px;
    overflow: auto;
    border: 1px solid #ccc;
    margin: 3px auto;
    text-align: left;
    line-height: 1;
}
[dir=rtl] #link__wiz_result {
    text-align: right;
}

#link__wiz_result div {
    padding: 3px 3px 3px 0;
}

#link__wiz_result div a {
    display: block;
    padding-left: 22px;
    min-height: 16px;
    background: transparent 3px center no-repeat;
}
[dir=rtl] #link__wiz_result div a {
    padding: 3px 22px 3px 3px;
    background-position: 257px 3px;
}

#link__wiz_result div.type_u a {
    background-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/up.png);
}
#link__wiz_result div.type_f a {
    background-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/page.png);
}
#link__wiz_result div.type_d a {
    background-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/ns.png);
}

#link__wiz_result div.even {
    background-color: #ddd;
}

#link__wiz_result div.selected {
    background-color: #eee;
}

#link__wiz_result span {
    display: block;
    color: #666;
    margin-left: 22px;
}


/* media option wizard (opens when inserting media in the media popup)
********************************************************************/

#media__popup {
    /* for backwards compatibility (not needed since Rincewind) */
    display: none;
}

#media__popup_content p {
    margin: 0 0 .5em;
}

#media__popup_content label {
    margin-right: .5em;
    cursor: default;
}

#media__popup_content .button {
    margin-right: 1px;
    cursor: pointer;
}

/* TODO: this file is not up to the best standards and will be fixed after an overhaul of the form code */

/**
 * This file provides styles for forms in general and specifically
 * for ?do=
 *   - login
 *   - resendpwd
 *   - register
 *   - profile
 *   - subscribe
 */

/* ---------------- forms ------------------------ */

.dokuwiki form {
  border: none;
  display: inline;
}

.dokuwiki label.block {
  display: block;
  text-align: right;
  font-weight: bold;
}
[dir=rtl] .dokuwiki label.block {
    text-align: left;
}

.dokuwiki label.simple {
  display: block;
  text-align: left;
  font-weight: normal;
}
[dir=rtl] .dokuwiki label.simple {
    text-align: right;
}

.dokuwiki label.block select,
.dokuwiki label.block input.edit {
  width: 50%;
}

.dokuwiki label span {
    vertical-align: middle;
}

.dokuwiki fieldset {
  width: 400px;
  text-align: center;
  border: 1px solid #ccc;
  padding: 0.5em;
  margin: auto;
}


.dokuwiki input.edit,
.dokuwiki select.edit {
  vertical-align: middle;
}
.dokuwiki select.edit {
  padding: 0.1em 0;
}


.dokuwiki input.button,
.dokuwiki button.button {
    vertical-align: middle;
}

/**
 * Styles for the subscription page
 */

#subscribe__form {
    display: block;
    width: 400px;
    text-align: center;
}

#subscribe__form fieldset {
    text-align: left;
    margin: 0.5em 0;
}
[dir=rtl] #subscribe__form fieldset {
    text-align: right;
}

#subscribe__form label {
    display: block;
    margin: 0 0.5em 0.5em;
}
/**
 * This file provides styles for the Administration overview
 * (?do=admin).
 */

.dokuwiki ul.admin_tasks {
    float: left;
    width: 40%;
    list-style-type: none;
    font-size: 1.125em;
}
[dir=rtl] .dokuwiki ul.admin_tasks {
    float: right;
}

.dokuwiki ul.admin_tasks li {
    padding-left: 35px;
    margin: 0 0 1em 0;
    font-weight: bold;
    list-style-type: none;
    background: transparent none no-repeat scroll 0 0;
    color: inherit;
}
[dir=rtl] .dokuwiki ul.admin_tasks li {
    padding-left: 0;
    padding-right: 35px;
    background-position: right 0;
}

.dokuwiki ul.admin_tasks li.admin_acl {
    background-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/admin/acl.png);
}
.dokuwiki ul.admin_tasks li.admin_usermanager {
    background-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/admin/usermanager.png);
}
.dokuwiki ul.admin_tasks li.admin_plugin {
    background-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/admin/plugin.png);
}
.dokuwiki ul.admin_tasks li.admin_config {
    background-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/admin/config.png);
}
.dokuwiki ul.admin_tasks li.admin_revert {
    background-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/admin/revert.png);
}
.dokuwiki ul.admin_tasks li.admin_popularity {
    background-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/../../images/admin/popularity.png);
}

/* DokuWiki version below */
.dokuwiki #admin__version {
    clear: left;
    float: right;
    color: #666;
    background-color: inherit;
}
[dir=rtl] .dokuwiki #admin__version {
    clear: right;
    float: left;
}
/**
 * This file provides styles for the general layout structure.
 *
 * @author Anika Henke <anika@selfthinker.org>
 */

body {
    margin: 0 auto;
}
#dokuwiki__site {
    margin: 0 auto;
    max-width: 100em;
}
#dokuwiki__site > .site {
    padding: 0 .5em;
}

#dokuwiki__header {
    width: 100%;
}
#dokuwiki__header > .pad {
}
    #dokuwiki__header .headings {
        float: left;
    }
    [dir=rtl] #dokuwiki__header .headings {
        float: right;
        text-align: right;
    }
    #dokuwiki__header .tools {
        float: right;
        text-align: right;
    }
    [dir=rtl] #dokuwiki__header .tools {
        float: left;
        text-align: left;
    }

#dokuwiki__site .wrapper {
    position: relative;
}

    #dokuwiki__aside {
        width: 100em;
        float: left;
        position: relative;
        display: block;
    }
    [dir=rtl] #dokuwiki__aside {
        float: right;
    }
    #dokuwiki__aside > .pad {
        margin: 0 1.5em 0 0;
    }
    [dir=rtl] #dokuwiki__aside > .pad {
        margin: 0 0 0 1.5em;
    }

    .showSidebar #dokuwiki__content {
        float: right;
        margin-left: 0;
        width: 100%;
    }
    [dir=rtl] .showSidebar #dokuwiki__content {
        float: left;
        margin-left: 0;
        margin-right: 0;
    }
    .showSidebar #dokuwiki__content > .pad {
        margin-left: 0;
    }
    [dir=rtl] .showSidebar #dokuwiki__content > .pad {
        margin-left: 0;
        margin-right: 0;
    }

#dokuwiki__footer {
    clear: both;
}
#dokuwiki__footer > .pad {
}
/**
 * This file provides the main design styles for the
 * bits that surround the content.
 *
 * @author Anika Henke <anika@selfthinker.org>
 * @author Andreas Gohr <andi@splitbrain.org>
 * @author Clarence Lee <clarencedglee@gmail.com>
 */

/* header
********************************************************************/

#dokuwiki__header {
    padding: 2em 0 1.5em;
}

#dokuwiki__header .headings,
#dokuwiki__header .tools {
    margin-bottom: 1.5em;
    width: 49%;
}
#dokuwiki__header h1 img {
    float: left;
    margin-right: .5em;
}
[dir=rtl] #dokuwiki__header h1 img {
    float: right;
    margin-left: .5em;
    margin-right: 0;
}
#dokuwiki__header h1 span {
    display: block;
    padding-top: 10px;
}
#dokuwiki__header h1 {
    margin: 0;
    font-size: 1.5em;
    font-weight: normal;
}
#dokuwiki__header h1 a {
    text-decoration: none;
    color: #333;
    background-color: inherit;
}
#dokuwiki__header h1 a:hover,
#dokuwiki__header h1 a:active,
#dokuwiki__header h1 a:focus {
}
#dokuwiki__header p.claim {
    margin-bottom: 0;
    font-size: 0.875em;
}

#dokuwiki__header .tools {
    margin-top: .2em;
}


/* tools
********************************************************************/

/* highlight selected tool */
.mode_admin a.action.admin,
.mode_login a.action.login,
.mode_register a.action.register,
.mode_profile a.action.profile,
.mode_recent a.action.recent,
.mode_index a.action.index,
.mode_media a.action.media,
.mode_revisions a.action.revs,
.mode_backlink a.action.backlink,
.mode_subscribe a.action.subscribe {
    font-weight: bold;
}

#dokuwiki__header .tools ul {
    padding-left: 0;
    margin-bottom: 0;
}
#dokuwiki__header .tools li {
    font-size: 0.875em;
    margin-left: 1em;
    list-style: none;
    display: inline;
}
[dir=rtl] #dokuwiki__header .tools li {
    margin-right: 1em;
    margin-left: 0;
}
#dokuwiki__header .tools form.search div.ajax_qsearch li {
    font-size: 1em;
    margin-left: 0;
    display: block;
    overflow: hidden;
    text-overflow: ellipsis;
}

#dokuwiki__usertools a.action {
    padding-left: 20px;
    background: transparent url(/wiki/pm/lib/tpl/dokuwiki_modif/images/usertools.png) no-repeat 0 0;
}
[dir=rtl] #dokuwiki__usertools a.action {
    padding-left: 0;
    padding-right: 20px;
}
[dir=rtl] #IE7 #dokuwiki__usertools a.action {
    display: inline-block;
}


#dokuwiki__header .mobileTools {
    display: none; /* hide mobile tools dropdown to only show in mobile view */
}

/*____________ user tools ____________*/

#dokuwiki__usertools {
    position: absolute;
    top: .5em;
    right: .5em;
    text-align: right;
    width: 100%;
}
[dir=rtl] #dokuwiki__usertools {
    text-align: left;
    left: 40px;
    right: auto;
}
#dokuwiki__usertools ul {
    margin: 0 auto;
    padding: 0;
    max-width: 100em;
}
#dokuwiki__usertools ul li.user {
}

#dokuwiki__usertools a.action.admin {
    background-position: left 0;
}
[dir=rtl] #dokuwiki__usertools a.action.admin {
    background-position: right 0;
}
#dokuwiki__usertools a.action.profile {
    background-position: left -32px;
}
[dir=rtl] #dokuwiki__usertools a.action.profile {
    background-position: right -32px;
}
#dokuwiki__usertools a.action.register {
    background-position: left -64px;
}
[dir=rtl] #dokuwiki__usertools a.action.register {
    background-position: right -64px;
}
#dokuwiki__usertools a.action.login {
    background-position: left -96px;
}
[dir=rtl] #dokuwiki__usertools a.action.login {
    background-position: right -96px;
}
#dokuwiki__usertools a.action.logout {
    background-position: left -128px;
}
[dir=rtl] #dokuwiki__usertools a.action.logout {
    background-position: right -128px;
}


/*____________ site tools ____________*/

#dokuwiki__sitetools {
    text-align: right;
}
[dir=rtl] #dokuwiki__sitetools {
    text-align: left;
}

#dokuwiki__sitetools form.search {
    display: block;
    font-size: 0.875em;
    position: relative;
}
#IE7 #dokuwiki__sitetools form.search {
    min-height: 1px;
    z-index: 21;
}
#dokuwiki__sitetools form.search input.edit {
    width: 18em;
    padding: .35em 22px .35em .1em;
}
[dir=rtl] #dokuwiki__sitetools form.search input.edit {
    padding: .35em .1em .35em 22px;
}
#dokuwiki__sitetools form.search input.button {
    background: transparent url(/wiki/pm/lib/tpl/dokuwiki_modif/images/search.png) no-repeat 0 0;
    border-width: 0;
    width: 19px;
    height: 14px;
    text-indent: -99999px;
    margin-left: -20px;
    box-shadow: none;
    padding: 0;
}
[dir=rtl] #dokuwiki__sitetools form.search input.button {
    background-position: 5px 0;
    margin-left: 0;
    margin-right: -20px;
}

#dokuwiki__sitetools ul {
    margin-top: 0.5em;
}
#dokuwiki__sitetools li {
}

/*____________ breadcrumbs ____________*/

.dokuwiki div.breadcrumbs {
    border-top: 1px solid #ccc;
    border-bottom: 1px solid #fff;
    margin-bottom: .5em;
    font-size: 0.875em;
    clear: both;
}
.dokuwiki div.breadcrumbs div {
    padding: .1em .35em;
}

.dokuwiki div.breadcrumbs div:only-child {
    border-top: 1px solid #fff;
    border-bottom: 1px solid #ccc;
}
.dokuwiki div.breadcrumbs div:first-child {
    border-top: 1px solid #fff;
}
#IE7 .dokuwiki div.breadcrumbs div,
#IE8 .dokuwiki div.breadcrumbs div {
    border-bottom: 1px solid #ccc;
}
.dokuwiki div.breadcrumbs div:last-child {
    border-bottom: 1px solid #ccc;
}

.dokuwiki div.breadcrumbs a {
    color: #2b73b7;
    background-color: inherit;
}
.dokuwiki div.breadcrumbs .bcsep {
    font-size: 0.75em;
}


/* sidebar
********************************************************************/

#dokuwiki__aside {
}
#dokuwiki__aside > .pad {
    font-size: 1.1em;
    overflow: hidden;
    word-wrap: break-word;
}

/* make sidebar more condensed */

#dokuwiki__aside h1 {
    font-size: 1.714em;
    margin-bottom: .292em;
}
#dokuwiki__aside h2 {
    margin-bottom: .333em;
}
#dokuwiki__aside h3 {
    margin-bottom: .444em;
}
#dokuwiki__aside h4 {
    margin-bottom: .5em;
}
#dokuwiki__aside h5 {
    margin-bottom: .5714em;
}

#dokuwiki__aside p,
#dokuwiki__aside ul,
#dokuwiki__aside ol,
#dokuwiki__aside dl,
#dokuwiki__aside pre,
#dokuwiki__aside table,
#dokuwiki__aside fieldset,
#dokuwiki__aside hr,
#dokuwiki__aside blockquote,
#dokuwiki__aside address {
    margin-bottom: .7em;
}

#dokuwiki__aside ul,
#dokuwiki__aside ol {
    padding-left: .5em;
}
[dir=rtl] #dokuwiki__aside ul,
[dir=rtl] #dokuwiki__aside ol {
    padding-right: .5em;
}
#dokuwiki__aside li ul,
#dokuwiki__aside li ol {
    margin-right: 0;
    padding: 0;
}

#dokuwiki__aside a:link,
#dokuwiki__aside a:visited {
    color: #2b73b7;
    background-color: inherit;
}


/* content
********************************************************************/

#dokuwiki__content {
}

.dokuwiki .pageId {
    position: absolute;
    top: 25.8em;
    right: -1em;
    overflow: hidden;
    padding: 1em 1em 0;
}
[dir=rtl] .dokuwiki .pageId {
    right: auto;
    left: -1em;
}
.dokuwiki .pageId span {
    font-size: 0.875em;
    border: solid #eee;
    border-width: 1px 1px 0;
    background-color: #fff;
    color: #999;
    padding: .1em .35em;
    border-top-left-radius: 2px;
    border-top-right-radius: 2px;
    box-shadow: 0 0 .5em #999;
    display: block;
}

.dokuwiki div.page {
    background: #fff;
    color: inherit;
    border: 1px solid #eee;
    box-shadow: 0 0 .5em #999;
    border-radius: 2px;
    padding: 1.556em 2em 2em;
    margin-bottom: .5em;
    overflow: hidden;
    word-wrap: break-word;
}

.dokuwiki .docInfo {
    font-size: 0.875em;
    text-align: right;
}
[dir=rtl] .dokuwiki .docInfo {
    text-align: left;
}

/* license note under edit window */
.dokuwiki div.license {
    font-size: 93.75%;
}


/* footer
********************************************************************/

.dokuwiki .wrapper {
    margin-bottom: 1.4em;
}

#dokuwiki__footer {
    margin-bottom: 1em;
    text-align: center;
}
#dokuwiki__footer > .pad {
    font-size: 0.875em;
}

#dokuwiki__footer div.license {
    margin-bottom: 0.5em;
    font-size: 100%;
}

[dir=rtl] #dokuwiki__footer .license img {
    margin: 0 0 0 .5em;
}

#dokuwiki__footer div.buttons a img {
    opacity: 0.5;
}
#dokuwiki__footer div.buttons a:hover img,
#dokuwiki__footer div.buttons a:active img,
#dokuwiki__footer div.buttons a:focus img {
    opacity: 1;
}


#navbar p
{
	margin: 0 0 0;
}
#navbar {
	margin: 0;
	padding: 0;
	height: 4em;
 }
#navbar li {
	list-style: none;
	float: left; }
#navbar li a {
	display: block;
	padding: 3px 8px;
	margin-right: 1px;
	background-color: #dee7ec;

	border-bottom: 1px solid #8CACBB;
	border-left: 1px solid #8CACBB;
	border-right: 1px solid #8CACBB;
	border-top: 1px solid #8CACBB;
	color: #000 !important;
	text-decoration: none; }
#navbar li a.mediafile {
	padding-left: 18px;
}
#navbar li a.mediafile {
	background-position: 0 5px;
}
#navbar li {
	margin: 0px 0px 0px 0px;
}
#navbar li ul {
	display: none; 
	/*width: 10em; /* Width to help Opera out */
	border-bottom: 0px;
	border-left: 0px;
	border-right: 0px;
	border-top: 0px;
	/*background-color: #69f; DD2013 */
	margin: 0px 0px 0px 0px; }
#navbar li:hover ul {
	display: block;
	position: absolute;
	margin: 0;
	padding: 0; }
#navbar li:hover li {
	float: none; }
#navbar li:hover li a {
	background-color: #cccccc;
/*	border-bottom: 1px solid #fff; DD2013 */
	margin-right: 0px;
	margin-top: 1px;
	color: #000; }
#navbar li li a:hover {
	background-color: #8db3ff; }
/**
 * This file provides the styles for the page tools
 * (fly out navigation beside the page to edit, etc).
 *
 * @author Anika Henke <anika@selfthinker.org>
 * @author Andreas Gohr <andi@splitbrain.org>
 */

#dokuwiki__site > .site {
    /* give space to the right so the tools won't disappear on smaller screens */
    /* it's 40px because the 30px wide icons will have 5px more spacing to the left and right */
    padding-right: 40px;
    /* give the same space to the left to balance it out */
    padding-left: 40px;
}
.dokuwiki div.page {
    height: 190px;
    min-height: 190px; /* 30 (= height of icons) x 6 (= maximum number of possible tools) + 2x5 */
    height: auto;
}
#dokuwiki__usertools {
    /* move the tools just outside of the site */
    right: 40px;
}
[dir=rtl] #dokuwiki__usertools {
    right: auto;
    left: 40px;
}

.publicity table {
	border: 0px;
}
.publicity td {
	border: 0px;
}
.publicity {
	position: absolute;
    right: 22em;
    /* on same vertical level as first headline, because .page has 2em padding */
    top: 3em;
    width: 40px;
}
#dokuwiki__pagetools {
    position: absolute;
    right: -40px;
    /* on same vertical level as first headline, because .page has 2em padding */
    top: 28em;
    width: 40px;
}
[dir=rtl] #dokuwiki__pagetools {
    right: auto;
    left: -40px;
}

#dokuwiki__pagetools div.tools {
    position: fixed;
    width: 40px;
}

#dokuwiki__pagetools ul {
    position: absolute;
    right: 0;
    text-align: right;
    margin: 0;
    padding: 0;
    /* add transparent border to prevent jumping when proper border is added on hover */
    border: 1px solid transparent;
}
[dir=rtl] #dokuwiki__pagetools ul {
    right: auto;
    left: 0;
    text-align: left;
}

#dokuwiki__pagetools ul li {
    padding: 0;
    margin: 0;
    list-style: none;
    font-size: 0.875em;
}

#dokuwiki__pagetools ul li a {
    display: block;
    min-height: 20px; /* 30 - 2x5 */
    line-height: 20px;
    padding: 5px 40px 5px 5px;
    background-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/images/pagetools-sprite.png);
    background-position: right 0;
    background-repeat: no-repeat;
    /* add transparent border to prevent jumping when proper border is added on focus */
    border: 1px solid transparent;
    white-space: nowrap;
}
[dir=rtl] #dokuwiki__pagetools ul li a {
    padding: 5px 5px 5px 40px;
    background-position: left 0;
}

/* hide labels accessibly when neither on hover nor on focus */
#dokuwiki__pagetools ul li a span {
    position: absolute;
    clip: rect(0 0 0 0); /* IE7, IE6 */
    clip: rect(0, 0, 0, 0);
}

/* show all tools on hover and individual tools on focus */
#dokuwiki__pagetools:hover ul,
#dokuwiki__pagetools ul li a:focus {
    background-color: #fff;
    border-color: #ccc;
    border-radius: 2px;
    box-shadow: 2px 2px 2px #999;
}
[dir=rtl] #dokuwiki__pagetools:hover ul,
[dir=rtl] #dokuwiki__pagetools ul li a:focus {
    box-shadow: -2px 2px 2px #999;
}

#dokuwiki__pagetools:hover ul li a span,
#dokuwiki__pagetools ul li a:focus span {
    display: inline;
    position: static;
}

#dokuwiki__pagetools ul li a:hover,
#dokuwiki__pagetools ul li a:active,
#dokuwiki__pagetools ul li a:focus {
    text-decoration: none;
}
#dokuwiki__pagetools ul li a:hover {
    background-color: #eee;
}

/*____________ all available icons in sprite ____________*/

#dokuwiki__pagetools ul li a.edit {
    background-position: right 0;
}
#dokuwiki__pagetools ul li a.edit:hover,
#dokuwiki__pagetools ul li a.edit:active,
#dokuwiki__pagetools ul li a.edit:focus {
    background-position: right -45px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.edit {
    background-position: left 0;
}
[dir=rtl] #dokuwiki__pagetools ul li a.edit:hover,
[dir=rtl] #dokuwiki__pagetools ul li a.edit:active,
[dir=rtl] #dokuwiki__pagetools ul li a.edit:focus {
    background-position: left -45px;
}

#dokuwiki__pagetools ul li a.create {
    background-position: right -90px;
}
#dokuwiki__pagetools ul li a.create:hover,
#dokuwiki__pagetools ul li a.create:active,
#dokuwiki__pagetools ul li a.create:focus {
    background-position: right -135px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.create {
    background-position: left -90px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.create:hover,
[dir=rtl] #dokuwiki__pagetools ul li a.create:active,
[dir=rtl] #dokuwiki__pagetools ul li a.create:focus {
    background-position: left -135px;
}

#dokuwiki__pagetools ul li a.show {
    background-position: right -270px;
}
#dokuwiki__pagetools ul li a.show:hover,
#dokuwiki__pagetools ul li a.show:active,
#dokuwiki__pagetools ul li a.show:focus {
    background-position: right -315px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.show {
    background-position: left -270px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.show:hover,
[dir=rtl] #dokuwiki__pagetools ul li a.show:active,
[dir=rtl] #dokuwiki__pagetools ul li a.show:focus {
    background-position: left -315px;
}

#dokuwiki__pagetools ul li a.source {
    background-position: right -360px;
}
#dokuwiki__pagetools ul li a.source:hover,
#dokuwiki__pagetools ul li a.source:active,
#dokuwiki__pagetools ul li a.source:focus {
    background-position: right -405px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.source {
    background-position: left -360px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.source:hover,
[dir=rtl] #dokuwiki__pagetools ul li a.source:active,
[dir=rtl] #dokuwiki__pagetools ul li a.source:focus {
    background-position: left -405px;
}

#dokuwiki__pagetools ul li a.draft {
    background-position: right -180px;
}
#dokuwiki__pagetools ul li a.draft:hover,
#dokuwiki__pagetools ul li a.draft:active,
#dokuwiki__pagetools ul li a.draft:focus {
    background-position: right -225px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.draft {
    background-position: left -180px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.draft:hover,
[dir=rtl] #dokuwiki__pagetools ul li a.draft:active,
[dir=rtl] #dokuwiki__pagetools ul li a.draft:focus {
    background-position: left -225px;
}

#dokuwiki__pagetools ul li a.revs {
    background-position: right -540px;
}
#dokuwiki__pagetools ul li a.revs:hover,
#dokuwiki__pagetools ul li a.revs:active,
#dokuwiki__pagetools ul li a.revs:focus,
.mode_revisions #dokuwiki__pagetools ul li a.revs {
    background-position: right -585px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.revs {
    background-position: left -540px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.revs:hover,
[dir=rtl] #dokuwiki__pagetools ul li a.revs:active,
[dir=rtl] #dokuwiki__pagetools ul li a.revs:focus,
.mode_revisions [dir=rtl] #dokuwiki__pagetools ul li a.revs {
    background-position: left -585px;
}

#dokuwiki__pagetools ul li a.backlink {
    background-position: right -630px;
}
#dokuwiki__pagetools ul li a.backlink:hover,
#dokuwiki__pagetools ul li a.backlink:active,
#dokuwiki__pagetools ul li a.backlink:focus,
.mode_backlink #dokuwiki__pagetools ul li a.backlink {
    background-position: right -675px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.backlink {
    background-position: left -630px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.backlink:hover,
[dir=rtl] #dokuwiki__pagetools ul li a.backlink:active,
[dir=rtl] #dokuwiki__pagetools ul li a.backlink:focus,
.mode_backlink [dir=rtl] #dokuwiki__pagetools ul li a.backlink {
    background-position: left -675px;
}

#dokuwiki__pagetools ul li a.top {
    background-position: right -810px;
}
#dokuwiki__pagetools ul li a.top:hover,
#dokuwiki__pagetools ul li a.top:active,
#dokuwiki__pagetools ul li a.top:focus {
    background-position: right -855px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.top {
    background-position: left -810px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.top:hover,
[dir=rtl] #dokuwiki__pagetools ul li a.top:active,
[dir=rtl] #dokuwiki__pagetools ul li a.top:focus {
    background-position: left -855px;
}

#dokuwiki__pagetools ul li a.revert {
    background-position: right -450px;
}
#dokuwiki__pagetools ul li a.revert:hover,
#dokuwiki__pagetools ul li a.revert:active,
#dokuwiki__pagetools ul li a.revert:focus,
.mode_revert #dokuwiki__pagetools ul li a.revert {
    background-position: right -495px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.revert {
    background-position: left -450px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.revert:hover,
[dir=rtl] #dokuwiki__pagetools ul li a.revert:active,
[dir=rtl] #dokuwiki__pagetools ul li a.revert:focus,
.mode_revert [dir=rtl] #dokuwiki__pagetools ul li a.revert {
    background-position: left -495px;
}

#dokuwiki__pagetools ul li a.subscribe {
    background-position: right -720px;
}
#dokuwiki__pagetools ul li a.subscribe:hover,
#dokuwiki__pagetools ul li a.subscribe:active,
#dokuwiki__pagetools ul li a.subscribe:focus,
.mode_subscribe #dokuwiki__pagetools ul li a.subscribe {
    background-position: right -765px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.subscribe {
    background-position: left -720px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.subscribe:hover,
[dir=rtl] #dokuwiki__pagetools ul li a.subscribe:active,
[dir=rtl] #dokuwiki__pagetools ul li a.subscribe:focus,
.mode_subscribe [dir=rtl] #dokuwiki__pagetools ul li a.subscribe {
    background-position: left -765px;
}

#dokuwiki__pagetools ul li a.mediaManager {
    background-position: right -900px;
}
#dokuwiki__pagetools ul li a.mediaManager:hover,
#dokuwiki__pagetools ul li a.mediaManager:active,
#dokuwiki__pagetools ul li a.mediaManager:focus {
    background-position: right -945px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.mediaManager {
    background-position: left -900px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.mediaManager:hover,
[dir=rtl] #dokuwiki__pagetools ul li a.mediaManager:active,
[dir=rtl] #dokuwiki__pagetools ul li a.mediaManager:focus {
    background-position: left -945px;
}

#dokuwiki__pagetools ul li a.back {
    background-position: right -990px;
}
#dokuwiki__pagetools ul li a.back:hover,
#dokuwiki__pagetools ul li a.back:active,
#dokuwiki__pagetools ul li a.back:focus {
    background-position: right -1035px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.back {
    background-position: left -990px;
}
[dir=rtl] #dokuwiki__pagetools ul li a.back:hover,
[dir=rtl] #dokuwiki__pagetools ul li a.back:active,
[dir=rtl] #dokuwiki__pagetools ul li a.back:focus {
    background-position: left -1035px;
}
/**
 * This file provides the main design styles for the page content.
 *
 * @author Anika Henke <anika@selfthinker.org>
 * @author Andreas Gohr <andi@splitbrain.org>
 * @author Clarence Lee <clarencedglee@gmail.com>
 */

/*____________ section indenting ____________

.dokuwiki.page  h1 {margin-left: 0;}
.dokuwiki.page  h2 {margin-left: .666em;}
.dokuwiki.page  h3 {margin-left: 1.776em;}
.dokuwiki.page  h4 {margin-left: 3em;}
.dokuwiki.page  h5 {margin-left: 4.5712em;}
.dokuwiki.page  div.level1 {margin-left: 0;}
.dokuwiki.page  div.level2 {margin-left: 1em;}
.dokuwiki.page  div.level3 {margin-left: 2em;}
.dokuwiki.page  div.level4 {margin-left: 3em;}
.dokuwiki.page  div.level5 {margin-left: 4em;}

[dir=rtl] .dokuwiki .page h1 {margin-left: 0; margin-right: 0;}
[dir=rtl] .dokuwiki .page h2 {margin-left: 0; margin-right: .666em;}
[dir=rtl] .dokuwiki .page h3 {margin-left: 0; margin-right: 1.776em;}
[dir=rtl] .dokuwiki .page h4 {margin-left: 0; margin-right: 3em;}
[dir=rtl] .dokuwiki .page h5 {margin-left: 0; margin-right: 4.5712em;}
[dir=rtl] .dokuwiki .page div.level1 {margin-left: 0; margin-right: 0;}
[dir=rtl] .dokuwiki .page div.level2 {margin-left: 0; margin-right: 1em;}
[dir=rtl] .dokuwiki .page div.level3 {margin-left: 0; margin-right: 2em;}
[dir=rtl] .dokuwiki .page div.level4 {margin-left: 0; margin-right: 3em;}
[dir=rtl] .dokuwiki .page div.level5 {margin-left: 0; margin-right: 4em;}
*/
/* hx margin-left = (1 / font-size) * .levelx-margin */


/*____________ links to wiki pages (addition to _links) ____________*/

/* existing wikipage */
.dokuwiki a.wikilink1 {
    color: #080;
    background-color: inherit;
}
/* not existing wikipage */
.dokuwiki a.wikilink2 {
    color: #d30;
    background-color: inherit;
}


/*____________ images ____________*/

/* embedded images (styles are already partly set in lib/styles/all.css) */
.dokuwiki img.media {
    margin: .2em 0;
}
.dokuwiki img.medialeft {
    margin: .2em 1em .2em 0;
}
.dokuwiki img.mediaright {
    margin: .2em 0 .2em 1em;
}
.dokuwiki img.mediacenter {
    margin: .2em auto;
}


/*____________ lists ____________*/

#dokuwiki__content ul li,
#dokuwiki__aside ul li {
    color: #999;
}
#dokuwiki__content ol li,
#dokuwiki__aside ol li {
    color: #666;
}
#dokuwiki__content li .li,
#dokuwiki__aside li .li {
    color: #333;
}


/*____________ tables ____________*/

/* div around each table */
.dokuwiki div.table {
    overflow-x: auto;
    margin-bottom: 1.4em;
}
.dokuwiki div.table table {
    margin-bottom: 0;
}

.dokuwiki table.inline {
    min-width: 50%;
}
.dokuwiki table.inline tr:hover td {
    background-color: #eee;
}
.dokuwiki table.inline tr:hover th {
    background-color: #ccc;
}


/*____________ code ____________*/

/* fix if background-color hides underlining */
.dokuwiki em.u code {
    text-decoration: underline;
}

/* for code in <file> */
.dokuwiki pre.file {
}

/* filenames for downloadable file and code blocks */
.dokuwiki dl.code,
.dokuwiki dl.file {
}

.dokuwiki dl.code dt,
.dokuwiki dl.file dt {
    background-color: #fbfaf9;
    /* background: -moz-linear-gradient(   top, #eee 0%, #fbfaf9 100%); see FS#2447 */
    background: -webkit-linear-gradient(top, #eee 0%, #fbfaf9 100%);
    background: -o-linear-gradient(     top, #eee 0%, #fbfaf9 100%);
    background: -ms-linear-gradient(    top, #eee 0%, #fbfaf9 100%);
    background: linear-gradient(        top, #eee 0%, #fbfaf9 100%);
    color: inherit;
    border: 1px solid #ccc;
    border-bottom-color: #fbfaf9;
    border-top-left-radius: .3em;
    border-top-right-radius: .3em;
    padding: .3em .6em .1em;
    margin-bottom: -1px;
    float: left;
}
[dir=rtl] .dokuwiki dl.code dt,
[dir=rtl] .dokuwiki dl.file dt {
    float: right;
}
.dokuwiki dl.code dt a,
.dokuwiki dl.file dt a {
    background-color: transparent;
    font-size: 0.875em;
    font-weight: normal;
    display: block;
    min-height: 16px;
}

.dokuwiki dl.code dd,
.dokuwiki dl.file dd {
    margin: 0;
    clear: left;
    min-height: 1px; /* for IE7 */
}
[dir=rtl] .dokuwiki dl.code dd,
[dir=rtl] .dokuwiki dl.file dd {
    clear: right;
}

.dokuwiki dl.code pre,
.dokuwiki dl.file pre {
    box-shadow: inset -4px -4px .5em -.3em #ccc;
}


/*____________ JS popup ____________*/

.JSpopup {
    background-color: #fff;
    color: #333;
    border: 1px solid #ccc;
    box-shadow: .1em .1em .1em #ccc;
    border-radius: 2px;
    padding: .3em .5em;
    font-size: .9em;
}
.dokuwiki form.search div.ajax_qsearch {
    top: -.35em;
    font-size: 1em;
    text-overflow: ellipsis;
}

.JSpopup ul,
.JSpopup ol {
    padding-left: 0;
}
[dir=rtl] .JSpopup ul,
[dir=rtl] .JSpopup ol {
    padding-right: 0;
}


/* changes to underscored CSS files
********************************************************************/

#acl__tree li {
    margin: 0;
}

#dokuwiki__content span.curid a {
    font-weight: normal;
}
#dokuwiki__content strong span.curid a {
    font-weight: bold;
}


/*____________ changes to _edit ____________*/

.dokuwiki div.toolbar button.toolbutton {
    border-radius: 0;
    border-left-width: 0;
    padding: .1em .35em;
}
.dokuwiki div.toolbar button.toolbutton:first-child {
    border-top-left-radius: 4px;
    border-bottom-left-radius: 4px;
    border-left-width: 1px;
}
[dir=rtl] .dokuwiki div.toolbar button.toolbutton:first-child {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
    border-left-width: 0;
    border-right-width: 1px;
}
.dokuwiki div.toolbar button.toolbutton:last-child {
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
}
[dir=rtl] .dokuwiki div.toolbar button.toolbutton:last-child {
    border-top-left-radius: 4px;
    border-bottom-left-radius: 4px;
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
    border-left-width: 1px;
}

.dokuwiki div.section_highlight {
    margin: 0 -2em;
    padding: 0 1em;
    border-width: 0 1em;
}

.dokuwiki textarea.edit {
    font-family: Consolas, "Andale Mono WT", "Andale Mono", "Bitstream Vera Sans Mono", "Nimbus Mono L", Monaco, "Courier New", monospace;
}

.dokuwiki div.preview {
    margin: 0 -2em;
    padding: 0 2em;
}
.dokuwiki.hasSidebar div.preview {
    border-right: 0em solid #eee;
}
[dir=rtl] .dokuwiki.hasSidebar div.preview {
    border-right-width: 0;
    border-left: 0em solid #eee;
}
.dokuwiki div.preview div.pad {
    padding: 1.556em 0 2em;
}


/*____________ changes to _toc ____________*/

#dw__toc {
    margin:  -1.556em -2em .5em 1.4em;
    width: 18em;
    border-left: 1px solid #ccc;
    background: #fff;
    color: inherit;
}
[dir=rtl] #dw__toc {
    margin: -1.556em 1.4em .5em -2em;
    border-left-width: 0;
    border-right: 1px solid #ccc;
}

.dokuwiki h3.toggle {
    padding: .5em 1em;
    margin-bottom: 0;
    font-size: .875em;
    letter-spacing: .1em;
}
#dokuwiki__aside h3.toggle {
    display: none;
}

.dokuwiki .toggle strong {
    background: transparent url(/wiki/pm/lib/tpl/dokuwiki_modif/images/toc-arrows.png) 0 0;
    width: 8px;
    height: 5px;
    margin: .4em 0 0;
}
.dokuwiki .toggle.closed strong {
    background-position: 0 -5px;
}

.dokuwiki .toggle strong span {
    display: none;
}


#dw__toc > div {
    font-size: 0.875em;
    padding: .5em 1em 1em;
}
#dw__toc ul {
    padding: 0 0 0 1.2em;
}
[dir=rtl] #dw__toc ul {
    padding: 0 1.5em 0 0;
}
#dw__toc ul li {
    list-style-image: url(/wiki/pm/lib/tpl/dokuwiki_modif/images/toc-bullet.png);
}
#dw__toc ul li.clear {
    list-style: none;
}
#dw__toc ul li div.li {
    padding: .2em 0;
}


/*____________ changes to _imgdetail ____________*/

#dokuwiki__detail {
    padding: 0;
}
#dokuwiki__detail img {
    float: none;
    margin-bottom: 1.4em;
}
#dokuwiki__detail div.img_detail {
    float: none;
}

#dokuwiki__detail div.img_detail dl {
    overflow: hidden;
}
#dokuwiki__detail div.img_detail dl dt {
    float: left;
    width: 9em;
    text-align: right;
    clear: left;
}
[dir=rtl] #dokuwiki__detail div.img_detail dl dt {
    float: right;
    text-align: left;
    clear: right;
}
#dokuwiki__detail div.img_detail dl dd {
    margin-left: 9.5em;
}
[dir=rtl] #dokuwiki__detail div.img_detail dl dd {
    margin-left: 0;
    margin-right: 9.5em;
}
/**
 * This file provides styles for included seperate html files
 * (added through "include hooks").
 */

} /* /@media END screen styles */

/* START rest styles */ 
/**
 * Basic screen and print styles. These styles are needed for basic DokuWiki functions
 * regardless of the used template. Templates can override them of course
 */

div.clearer {
    clear: both;
    font-size: 0;
    line-height: 0;
    height: 0;
    overflow: hidden;
}

/* one of the many clearfix versions */
.group {
    display: inline-block;
}
.group {
    display: block;
}
.group:before,
.group:after {
    content: "";
    display: table;
}
.group:after {
    clear: both;
}

div.no {
    display: inline;
    margin: 0;
    padding: 0;
}

.hidden {
    display: none;
}

/* image alignment */
.medialeft {
    float: left;
}
.mediaright {
    float: right;
}
.mediacenter {
    display: block;
    margin-left: auto;
    margin-right: auto;
}

/* table cell alignment */
.leftalign   { text-align: left;   }
.centeralign { text-align: center; }
.rightalign  { text-align: right;  }

/* underline */
em.u {
    font-style: normal;
    text-decoration: underline;
}
em em.u {
    font-style: italic;
}
/********************************************************************
Screen and Print Styles for the Wrap Plugin
********************************************************************/

/* tables in columns and boxes should span the whole width */
.dokuwiki .plugin_wrap table {
    width: 100%;
}
/* emulate a headline */
.dokuwiki .plugin_wrap em strong {
    font-size: 130%;
    font-weight: bold;
    font-style: normal;
    display: block;
}
/* emulate a bigger headline with a bottom border */
.dokuwiki .plugin_wrap em strong em.u {
    font-size: 115%;
    border-bottom: 1px solid #ccc;
    font-style: normal;
    text-decoration: none;
    display: block;
}
/* different bigger headline for safety notes */
.dokuwiki .wrap_danger em strong em.u, .dokuwiki .wrap_warning em strong em.u, .dokuwiki .wrap_caution em strong em.u, .dokuwiki .wrap_notice em strong em.u, .dokuwiki .wrap_safety em strong em.u {
    text-transform: uppercase;
    border-bottom-width: 0;
}
/* change border colour of emulated headlines inside boxes to something more neutral
   (to match all the different background colours) */
.dokuwiki .wrap_box em strong em.u,
.dokuwiki .wrap_info em strong em.u, .dokuwiki .wrap_important em strong em.u, .dokuwiki .wrap_alert em strong em.u, .dokuwiki .wrap_tip em strong em.u, .dokuwiki .wrap_help em strong em.u, .dokuwiki .wrap_todo em strong em.u, .dokuwiki .wrap_download em strong em.u {
    border-bottom-color: #999;
}

/* real headlines should not be indented inside a wrap */
.dokuwiki .plugin_wrap h1, .dokuwiki .plugin_wrap h2, .dokuwiki .plugin_wrap h3, .dokuwiki .plugin_wrap h4, .dokuwiki .plugin_wrap h5 {
    margin-left: 0;
    margin-right: 0;
}
/* hide section edit buttons (because they don't work inside a wrap) */
.dokuwiki .plugin_wrap div.secedit {
    display: none;
}

/* columns
********************************************************************/

.dokuwiki .wrap_left,
.dokuwiki .wrap_column {
    float: left;
    margin-right: 1.5em;
}
.dokuwiki .wrap_right {
    float: right;
    margin-left: 1.5em;
}
.dokuwiki .wrap_center {
    display: block;
    margin-left: auto;
    margin-right: auto;
}
/*
.dokuwiki .wrap_column,
.dokuwiki .wrap_left,
.dokuwiki .wrap_right {
    overflow: hidden;
}
*/
.dokuwiki .wrap_container {
    margin-right: -1.5em;
}

/*____________ CSS3 columns  ____________*/

.wrap_col2, .wrap_col3, .wrap_col4, .wrap_col5 {
    -moz-column-gap: 1.5em;
    -moz-column-rule: 1px dotted #666;
    -webkit-column-gap: 1.5em;
    -webkit-column-rule: 1px dotted #666;
    column-gap: 1.5em;
    column-rule: 1px dotted #666;
}
.wrap_col2 {
    -moz-column-count: 2;
    -webkit-column-count: 2;
    column-count: 2;
}
.wrap_col3 {
    -moz-column-count: 3;
    -webkit-column-count: 3;
    column-count: 3;
}
.wrap_col4 {
    -moz-column-count: 4;
    -webkit-column-count: 4;
    column-count: 4;
}
.wrap_col5 {
    -moz-column-count: 5;
    -webkit-column-count: 5;
    column-count: 5;
}


/* alignments
********************************************************************/

.dokuwiki .wrap_leftalign {
    text-align: left;
}
.dokuwiki .wrap_centeralign {
    text-align: center;
}
.dokuwiki .wrap_rightalign {
    text-align: right;
}
.dokuwiki .wrap_justify {
    text-align: justify;
}


/* box
********************************************************************/

/* see styles for boxes and notes with icons in style.css */

/*____________ rounded corners ____________*/
/* (only for modern browsers) */

.dokuwiki div.wrap_round {
    border-radius: 20px;
    -moz-border-radius: 20px;
    -webkit-border-radius: 20px;
    -khtml-border-radius: 20px;
}
.dokuwiki span.wrap_round {
    border-radius: 2px;
    -moz-border-radius: 2px;
    -webkit-border-radius: 2px;
    -khtml-border-radius: 2px;
}


/* mark
********************************************************************/

div.dokuwiki .wrap_lo {
    color: #666;
    font-size: 85%;
}
div.dokuwiki .wrap_em {
    color: #c00;
    font-weight: bold;
}

/* see styles for highlighted text in style.css */


/* typography
********************************************************************

div.dokuwiki .wrap_sansserif {
    font-family: Verdana,Tahoma,Geneva,"DejaVu Sans","Bitstream Vera Sans","Liberation Sans", Arial,Helvetica,FreeSans,"Liberation Sans","Nimbus Sans L", sans-serif;
}
div.dokuwiki .wrap_serif {
    font-family: Georgia,Garamond,"Palatino Linotype","Book Antiqua",Palatino,Palladio,"URW Palladio L","Liberation Serif",Didot,Gentium,"Bitstream Charter","Century Schoolbook L", "Times New Roman",Times,"Nimbus Roman No9 L","FreeSerif", serif;
}
div.dokuwiki .wrap_monospace {
    font-family: Courier,"Courier New",FreeMono,"Nimbus Mono L","Liberation Mono", "Lucida Console",Monaco,"DejaVu Sans Mono","Bitstream Vera Sans Mono", monospace;
}

div.dokuwiki .wrap_bigger {
    font-size: 125%;
}
div.dokuwiki .wrap_muchbigger {
    font-size: 200%;
}
div.dokuwiki .wrap_smaller {
    font-size: 75%;
}

div.dokuwiki .wrap_fgred {
    color: #900;
}
div.dokuwiki .wrap_fggreen {
    color: #090;
}
div.dokuwiki .wrap_fgblue {
    color: #009;
}
div.dokuwiki .wrap_fgcyan {
    color: #099;
}
div.dokuwiki .wrap_fgviolet {
    color: #909;
}
div.dokuwiki .wrap_fgyellow {
    color: #990;
}
div.dokuwiki .wrap_fggrey {
    color: #666;
}
div.dokuwiki .wrap_fgblack {
    color: #000;
}

see styles for background colours and white font colour in style.css */


/* miscellaneous
********************************************************************/

/*____________ indent ____________*/

div.dokuwiki .wrap_indent {
    padding-left: 1.5em;
}

/*____________ outdent ____________*/

div.dokuwiki .wrap_outdent {
    margin-left: -1.5em;
}

/*____________ word wrapping in pre ____________*/

div.dokuwiki div.wrap_prewrap pre {
    white-space: pre-wrap;
    word-wrap: break-word;/* for IE < 8 */
    /* white-space: -moz-pre-wrap; for FF < 3 */
}

/*____________ spoiler ____________*/

div.dokuwiki div.wrap_spoiler {
    margin-bottom: 1.5em;
}
/* see rest of spoiler styles in style.css */

/*____________ clear float ____________*/

div.dokuwiki .wrap_clear {
    clear: both;
    line-height: 0;
    height: 0;
    font-size: 1px;
    visibility: hidden;
    overflow: hidden;
}

/*____________ hide ____________*/

div.dokuwiki .wrap_hide {
    display: none;
}
/**
 * This file provides styles for mobile devices
 * and smaller screens (up to 480px and 768px width).
 *
 * @author Anika Henke <anika@selfthinker.org>
 */

/* for detecting media queries in JavaScript (see script.js): */
#screen__mode {
    position: relative;
    z-index: 0;
}

/* up to 979px screen widths
********************************************************************/
@media only screen and (max-width: 979px) {

#screen__mode {
    z-index: 1; /* for detecting media queries in JavaScript (see script.js) */
}

/* structure */
#dokuwiki__aside {
    width: 100%;
    float: none;
}

#dokuwiki__aside > .pad,
[dir=rtl] #dokuwiki__aside > .pad {
    margin: 0 0 .5em;
    /* style like .page */
    background: #fff;
    color: inherit;
    border: 1px solid #eee;
    box-shadow: 0 0 .5em #999;
    border-radius: 2px;
    padding: 1em;
    margin-bottom: .5em;
}

#dokuwiki__aside h3.toggle {
    font-size: 1em;
}
#dokuwiki__aside h3.toggle.closed {
    margin-bottom: 0;
    padding-bottom: 0;
}
#dokuwiki__aside h3.toggle.open {
    border-bottom: 1px solid #ccc;
}

.showSidebar #dokuwiki__content {
    float: none;
    margin-left: 0;
    width: 100%;
}
.showSidebar #dokuwiki__content > .pad {
    margin-left: 0;
}

[dir=rtl] .showSidebar #dokuwiki__content,
[dir=rtl] .showSidebar #dokuwiki__content > .pad {
    margin-right: 0;
}

/* toc */
#dw__toc {
    float: none;
    margin: 0 0 1em 0;
    width: auto;
    border-left-width: 0;
    border-bottom: 1px solid #ccc;
}
[dir=rtl] #dw__toc {
    float: none;
    margin: 0 0 1em 0;
    border-right-width: 0;
}

.dokuwiki h3.toggle {
    padding: 0 .5em .5em 0;
}
#dw__toc > div,
#dokuwiki__aside div.content {
    padding: .2em 0 .5em;
}

/* page */
.dokuwiki div.page {
    padding: 1em;
}

/* _edit */
.dokuwiki div.section_highlight {
    margin: 0 -1em;
    padding: 0 .5em;
    border-width: 0 .5em;
}
.dokuwiki div.preview {
    margin: 0 -1em;
    padding: 1em;
}

/* _recent */
.dokuwiki form.changes ul {
    padding-left: 0;
}
[dir=rtl] .dokuwiki form.changes ul {
    padding-right: 0;
}


} /* /@media */


/* up to 480px screen widths
********************************************************************/
@media only screen and (max-width: 480px) {

#screen__mode {
    z-index: 2; /* for detecting media queries in JavaScript (see script.js) */
}

body {
    font-size: 100%;
}

/*____________ structure ____________*/

#dokuwiki__site {
    max-width: 100%;
}
#dokuwiki__site > .site {
    padding: 0 .5em;
}
#dokuwiki__header {
    padding: .5em 0;
}


/*____________ header ____________*/

#dokuwiki__header ul.a11y.skip {
    position: static !important;
    left: 0 !important;
    width: auto !important;
    height: auto !important;
    float: right;
    font-size: 0.875em;
    list-style: none;
    padding-left: 0;
    margin: 0;
}
[dir=rtl] #dokuwiki__header ul.a11y.skip {
    left: auto !important;
    right: 0 !important;
    float: left;
    padding-right: 0;
}
#dokuwiki__header ul.a11y.skip li {
    margin-left: .35em;
    display: inline;
}
[dir=rtl] #dokuwiki__header ul.a11y.skip li {
    margin: 0 .35em 0 0;
}

#dokuwiki__header .headings,
#dokuwiki__header .tools {
    float: none;
    text-align: left;
    width: auto;
    margin-bottom: .5em;
}
[dir=rtl] #dokuwiki__header .headings,
[dir=rtl] #dokuwiki__header .tools {
    float: none;
    text-align: right;
    width: auto;
}
#dokuwiki__sitetools {
    text-align: left;
}
[dir=rtl] #dokuwiki__sitetools {
    text-align: right;
}
#dokuwiki__usertools,
#dokuwiki__sitetools ul,
#dokuwiki__sitetools h3,
#dokuwiki__pagetools,
.dokuwiki div.breadcrumbs, /* @todo: maybe move breadcrumbs to the bottom? */
.dokuwiki .pageId {
    display: none;
}

/* search form */
#dokuwiki__sitetools form.search {
    float: left;
    margin: 0 .2em .2em 0;
    width: 49%;
}
[dir=rtl] #dokuwiki__sitetools form.search {
    float: right;
    margin: 0 0 .2em .2em;
}

#dokuwiki__sitetools form.search input.edit {
    width: 100% !important;
}
.dokuwiki form.search div.ajax_qsearch {
    display: none !important;
}

/* action dropdown is alternative for all hidden tools */
#dokuwiki__header .mobileTools {
    display: block;
    font-size: 0.875em;
    margin: 0 0 .2em 0;
    float: right;
    width: 49%;
}
[dir=rtl] #dokuwiki__header .mobileTools {
    float: left;
}
#dokuwiki__header .mobileTools select {
    padding: .3em .1em;
    width: 100% !important;
}

/* force same height on search input and tools select */
#dokuwiki__sitetools form.search input.edit,
#dokuwiki__header .mobileTools select {
    height: 2.1em;
    line-height: 2.1em;
    overflow: visible;
}


/*____________ content ____________*/

#dokuwiki__aside > .pad,
.dokuwiki div.page {
    padding: .5em;
}

/* form elements */
#config__manager fieldset td.value,
#config__manager td .input,
.dokuwiki fieldset,
.dokuwiki input.edit,
.dokuwiki textarea,
.dokuwiki select {
    width: auto !important;
    max-width: 100% !important;
}
#config__manager fieldset {
    margin-left: 0;
    margin-right: 0;
}

.dokuwiki label.block {
    text-align: left;
}
[dir=rtl] .dokuwiki label.block {
    text-align: right;
}
.dokuwiki label.block span {
    display: block;
}

/* _edit */
.dokuwiki div.section_highlight {
    margin: 0;
    padding: 0;
    border-width: 0;
}
.dokuwiki div.preview {
    margin: 0 -.5em;
    padding: .5em;
}



} /* /@media */

/* END rest styles */

@media print { /* START print styles */
/**
 * Basic print styles. These styles are needed for basic DokuWiki functions
 * regardless of the used template. Templates can override them of course
 */

div.error, /* messages with msg() */
div.info,
div.success,
div.notify,
.secedit, /* section edit button */
.a11y, /* accessibly hidden text */
.JSpopup, /* modal windows */
#link__wiz {
    display: none;
}
/**
 * style.css for Plugin hidden
 * 
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Guillaume Turri <guillaume.turri@gmail.com>
 *
 */

.hiddenHead{
  background-color:#eee;
}

.hiddenBody{
  border-top:1px solid #ccc;
  padding:1px;
}

.hiddenGlobal{
  border:1px solid #ccc;
}

.hiddenOnHidden{
  display:none;
}

.hiddenOnVisible{
  display:none;
}

.hiddenElements{
  display:none;
}

div.hiddenGlobal div.hiddenHead p{
  margin:0;
}

.hiddenNoPrint {
    display:none;
}
/********************************************************************
Print Styles for the Wrap Plugin (additional to all.css)
********************************************************************/

/* boxes and notes with icons
********************************************************************/

.dokuwiki .wrap_box,
.dokuwiki .wrap_danger, .dokuwiki .wrap_warning, .dokuwiki .wrap_caution, .dokuwiki .wrap_notice, .dokuwiki .wrap_safety,
.dokuwiki .wrap_info, .dokuwiki .wrap_important, .dokuwiki .wrap_alert, .dokuwiki .wrap_tip, .dokuwiki .wrap_help, .dokuwiki .wrap_todo, .dokuwiki .wrap_download {
/*
    overflow: hidden;
*/
}
.dokuwiki div.wrap_box,
.dokuwiki div.wrap_danger, .dokuwiki div.wrap_warning, .dokuwiki div.wrap_caution, .dokuwiki div.wrap_notice, .dokuwiki div.wrap_safety,
.dokuwiki div.wrap_info, .dokuwiki div.wrap_important, .dokuwiki div.wrap_alert, .dokuwiki div.wrap_tip, .dokuwiki div.wrap_help, .dokuwiki div.wrap_todo, .dokuwiki div.wrap_download {
    border: 2px solid #999;
    padding: 1em 1em .5em;
    margin-bottom: 1.5em;
}
.dokuwiki span.wrap_box,
.dokuwiki span.wrap_danger, .dokuwiki span.wrap_warning, .dokuwiki span.wrap_caution, .dokuwiki span.wrap_notice, .dokuwiki span.wrap_safety,
.dokuwiki span.wrap_info, .dokuwiki span.wrap_important, .dokuwiki span.wrap_alert, .dokuwiki span.wrap_tip, .dokuwiki span.wrap_help, .dokuwiki span.wrap_todo, .dokuwiki span.wrap_download {
    border: 1px solid #999;
    padding: 0 .3em;
}


/* mark
********************************************************************/

div.dokuwiki .wrap_hi {
    border: 1px solid #999;
}


/* miscellaneous
********************************************************************/

/*____________ spoiler ____________*/

div.dokuwiki .wrap_spoiler {
    visibility: hidden;
}

/*____________ pagebreak ____________*/

div.dokuwiki .wrap_pagebreak {
    page-break-after: always;
}

/*____________ avoid page break ____________*/
/* not yet supported by most browsers */

div.dokuwiki .wrap_nopagebreak {
    page-break-inside: avoid;
}

/*____________ no print ____________*/

div.dokuwiki .wrap_noprint {
    display: none;
}
div.dokuwiki #discussion__comment_form,
div.dokuwiki #discussion__newthread_form,
div.dokuwiki div.comment_buttons,
div.dokuwiki div.comment_hidden {
  display:none;
}/**
 * This file provides the styles for printing.
 *
 * @todo: improve and finish
 */

body {
    /*
    font: normal 12pt/1.2 serif;
    color: #000;
    background-color: #fff;
    */
}

/* hide certain sections */
.a11y,
#dokuwiki__header .tools,
#dokuwiki__aside,
.dokuwiki .breadcrumbs,
#dw__toc,
h3.toggle,
#dokuwiki__pagetools,
#dokuwiki__footer {
    display: none;
}

.dokuwiki h1,
.dokuwiki h2,
.dokuwiki h3,
.dokuwiki h4,
.dokuwiki h5,
.dokuwiki caption,
.dokuwiki legend {
    clear: both;
}
.dokuwiki ul {
    list-style: disc outside;
}
.dokuwiki ol {
    list-style: decimal outside;
}
.dokuwiki ol ol {
    list-style-type: lower-alpha;
}
.dokuwiki ol ol ol {
    list-style-type: upper-roman;
}
.dokuwiki ol ol ol ol {
    list-style-type: upper-alpha;
}
.dokuwiki ol ol ol ol ol {
    list-style-type: lower-roman;
}

.dokuwiki a:link,
.dokuwiki a:visited {
    text-decoration: underline;
    color: #333;
    background-color: inherit;
}

/* display href after link */
a.urlextern:after,
a.interwiki:after,
a.mail:after {
   content: " [" attr(href) "]";
   font-size: 90%;
}

/* code blocks */
.dokuwiki pre {
    font-family: monospace;
}
.dokuwiki dl.code dt,
.dokuwiki dl.file dt {
    font-weight: bold;
}

/* images */
.dokuwiki img {
    border-width: 0;
    vertical-align: middle;
}
.dokuwiki img.media {
    margin: .2em 0;
}
.dokuwiki img.medialeft {
    margin: .2em 1em .2em 0;
}
.dokuwiki img.mediaright {
    margin: .2em 0 .2em 1em;
}
.dokuwiki img.mediacenter {
    margin: .2em auto;
}

.dokuwiki blockquote {
    padding: 0 10pt;
    margin: 0;
    border: solid #ccc;
    border-width: 0 0 0 2pt;
}
[dir=rtl] .dokuwiki blockquote {
    border-width: 0 2pt 0 0;
}

/* tables */
.dokuwiki table {
    border-collapse: collapse;
    empty-cells: show;
    border-spacing: 0;
    border: 1pt solid #ccc;
}
.dokuwiki th,
.dokuwiki td {
    padding: 3pt 5pt;
    margin: 0;
    vertical-align: top;
    border: 1pt solid #666;
    text-align: left;
}
[dir=rtl] .dokuwiki th,
[dir=rtl] .dokuwiki td {
    text-align: right;
}
.dokuwiki th {
    font-weight: bold;
}


/*____________ a bit of layout ____________*/

#dokuwiki__header {
    border-bottom: 2pt solid #ccc;
}
#dokuwiki__header h1 {
    font-size: 1.5em;
}
#dokuwiki__header h1 a {
    text-decoration: none;
}
#dokuwiki__header h1 img {
    float: left;
    margin-right: .5em;
}
[dir=rtl] #dokuwiki__header h1 img {
    float: right;
    margin-right: 0;
    margin-left: .5em;
}
.dokuwiki div.footnotes {
    clear: both;
    border-top: 1pt solid #000;
    margin-top: 10pt;
}

} /* /@media END print styles */
