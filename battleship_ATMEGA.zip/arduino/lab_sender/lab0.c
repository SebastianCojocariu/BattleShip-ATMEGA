/*
 * PM - 2017
 * lab0.c
 */

#define __PROG_TYPES_COMPAT__
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/io.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <util/delay.h>
#include "ST7735R_TFT.h"
#include "spi.h"
#include "usart.h"

#define WIDTH ST7735R_WIDTH 
#define HEIGHT ST7735R_HEIGHT

#define L 120
#define CENTER_X WIDTH/2
#define CENTER_Y HEIGHT/2

#define R_line 0
#define G_line 0
#define B_line 0


#define R_plane_placed 153
#define G_plane_placed 153
#define B_plane_placed 0

#define R_plane_moving 192
#define G_plane_moving 192
#define B_plane_moving 192

#define R_ball_moving 0
#define G_ball_moving 0
#define B_ball_moving 0

#define R_touch 0
#define G_touch 0
#define B_touch 255

#define R_missed 128
#define G_missed 128
#define B_missed 128

#define R_surface 255
#define G_surface 255
#define B_surface 255

volatile int DIM_airplane_big = 8;

volatile int TOTAL_DIM_PLANES;
volatile int line, column; 
volatile int X,Y;
volatile int n;
volatile int length_square;

volatile int horizontal_lines[15];
volatile int vertical_lines[15];

volatile int own_map[15][15];
volatile int attacked_map[15][15];
volatile int enemy_map[15][15];
volatile int rotated = 0;
volatile int no_airplanes = 0;
volatile unsigned char received_msg;
volatile int matrix_echange;

volatile int x[8] = {-1,0,0,0,1,2,2,2};
volatile int y[8] = {0,0,-1,1,0,0,-1,1};
volatile int won = 0;
volatile int place_planes = 0;
volatile int no_round = 0;
volatile int no_dim_found = 0;

float min(float x,float y){
	if(x > y)
		return x;
	return y;
}

/* Aprinde led-ul PC0 la apasarea butonului PB2. */
void exemplu(void) {
	/* Setez pinul PD7 ca iesire. */
	DDRD |= (1 << PD7);

	/* Sting LED-ul. */
	PORTD &= ~(1 << PD7);

	while (1) {
			PORTD |= (1 << PD7);
			_delay_ms(500);
	}
}


void start_joystick(void){
	/* Setez pinii PD6,PD5,PD4,PD1,PD0 + PB2*/
	DDRB &= ~(1 << PB2);
	DDRD &= ~(1 << PD6);
	DDRD &= ~(1 << PD5);
	DDRD &= ~(1 << PD4);
	DDRD &= ~(1 << PD1);
	//DDRD &= ~(1 << PD0);
	DDRC &= ~(1 << PC0);


	/* Activez rezistenta de pull-up pentru pinii de mai sus */
	PORTB |= (1 << PB2);
	PORTD |= (1 << PD6);
	PORTD |= (1 << PD5);
	PORTD |= (1 << PD4);
	PORTD |= (1 << PD1);
	//PORTD |= (1 << PD0);
	PORTC |= (1 << PC0);

	
}

void calculate_ball_coordinates()
{	
	int colt_x = CENTER_X - n/2 * length_square - n - 1;
	int colt_y = CENTER_Y - n/2 * length_square - n - 1;
	int k = 2;
	//X = colt_x + line + (line - 1) * length_square + k * length_square/2;
	//Y = colt_y + column + (column - 1) * length_square + k * length_square/2;
	X = colt_x + line + (line)*length_square;
	Y = colt_y + column + (column)*length_square;
}


void setup_coordinates()
{
	column = n/2;
	line = n/2;
	TOTAL_DIM_PLANES = no_airplanes * DIM_airplane_big;

	length_square = (L - n - 1)/n;
	if (length_square % 2 == 1)
		length_square--;

	for(int i = 0 ;i <= n/2; i++){
		if(i > 0 ){
			vertical_lines[n/2 + i + 1] = CENTER_X + i * length_square + i;
			vertical_lines[n/2 - i + 1] = CENTER_X - i * length_square - i;

			horizontal_lines[n/2 + i + 1] = CENTER_Y + i * length_square + i;
			horizontal_lines[n/2 - i + 1 ] = CENTER_Y - i * length_square - i;
		}
		else{
			vertical_lines[n/2 + 1] = CENTER_X;
 			horizontal_lines[n/2 + 1] = CENTER_Y;
		}
	}

	calculate_ball_coordinates();
}

void make_map(){
	//alb peste tot
	ST7735R_FillRect(0, 0, WIDTH, HEIGHT, R_surface, G_surface, B_surface);
	
	if (n % 2 == 0){
		float k = 1;
		if(n == 10)
			k = 1;
		if (n == 8)
			k = 1.25;
		for(int i = 0; i <= n/2; i++){
			if(i > 0){
 				ST7735R_VLine(vertical_lines[n/2 - i + 1],(HEIGHT - L)/2 + k * length_square/2, (HEIGHT + L)/2 - k * length_square/2, R_line, G_line, B_line);
 				ST7735R_VLine(vertical_lines[n/2 + i + 1],(HEIGHT - L)/2 + k * length_square/2, (HEIGHT + L)/2 - k * length_square/2, R_line, G_line, B_line);

 				ST7735R_HLine((WIDTH - L )/2 + k * length_square/2, (WIDTH + L)/2 - k * length_square/2, horizontal_lines[n/2 + i + 1] , R_line, G_line, B_line);
 				ST7735R_HLine((WIDTH - L )/2 + k * length_square/2, (WIDTH + L)/2 - k * length_square/2,  horizontal_lines[n/2 - i + 1], R_line, G_line, B_line);
 			}
 			else{
 				ST7735R_VLine(vertical_lines[n/2 + 1], (HEIGHT - L)/2 + k * length_square/2, (HEIGHT + L)/2 - k * length_square/2, R_line, G_line, B_line);
 				ST7735R_HLine((WIDTH - L)/2 + k * length_square/2, (WIDTH + L)/2 - k * length_square/2,horizontal_lines[n/2 + 1], R_line, G_line, B_line);
 			}
 		}
	}

}




void draw_current_position(int r,int g,int b)
{
	calculate_ball_coordinates();
	int radius = length_square / 4;
	ST7735R_FilledCircle(X, Y, radius, r,g,b);
}

void draw_square(int l,int c,int r,int g,int b)
{
	ST7735R_FillRect(vertical_lines[l] + 1,horizontal_lines[c] + 1,vertical_lines[l + 1] - 1,horizontal_lines[c + 1] - 1, r, g, b);

}

void change_matrix_rotation(int dx[8],int dy[8]){
	for(int i = 0;i < 8; i++){
		x[i] = dx[i];
		y[i] = dy[i];
	}
}



void draw_airplane(int r,int g,int b)
{
	for(int i = 0;i < 8;i++)
		draw_square(line + x[i], column + y[i], r, g, b);
}


int gameOver()
{
	return 0;
}

void erase_last_ball()
{	//verifica ce tip de culoarea are harta
	/*if(own_map[line][column] == 0)
		ST7735R_FillRect(vertical_lines[line] + 1,horizontal_lines[column] + 1,vertical_lines[line + 1] - 1, horizontal_lines[column + 1] - 1, R_surface, G_surface, B_surface);
	else
		ST7735R_FillRect(vertical_lines[line] + 1,horizontal_lines[column] + 1,vertical_lines[line + 1] - 1, horizontal_lines[column + 1] - 1, R_plane_placed, G_plane_placed, B_plane_placed);*/
	//verifica daca a este deja un semn pe locatia respectiva

	ST7735R_FillRect(vertical_lines[line] + 1,horizontal_lines[column] + 1,vertical_lines[line + 1] - 1, horizontal_lines[column + 1] - 1, R_surface, G_surface, B_surface);

	if(attacked_map[line][column] == 1 && own_map[line][column] == 1){
		ST7735R_FillRect(vertical_lines[line] + 1,horizontal_lines[column] + 1,vertical_lines[line + 1] - 1, horizontal_lines[column + 1] - 1, R_plane_placed, G_plane_placed, B_plane_placed);
		draw_current_position(R_touch,G_touch,B_touch);
	}
	else if (attacked_map[line][column] == 1)
		draw_current_position(R_missed,G_missed,B_missed);
	/*else if (attacked_map[line][column] == 0)
		draw_current_position(R_surface,G_ball_moving,B_ball_moving);*/

	//ST7735R_FillRect(X - length_square/4, Y - length_square/4, X + length_square/4, Y + length_square/4, 255, 255, 255);

}

void erase_last_airplane()
{

	for(int i = 0;i < 8; i++){
		if(own_map[line + x[i]][column + y[i]] == 0)
			draw_square(line + x[i],column + y[i],R_surface,G_surface,B_surface);
		else
			draw_square(line + x[i],column + y[i],R_plane_placed,G_plane_placed,B_plane_placed);
	}
}

int condition_bounds_airplanes()
{
	
	
	for(int i = 0;i < 8;i++)
		if(line + x[i] < 1 || line + x[i] > n || column + y[i] < 1 || column + y[i] > n)
			return 0;

	return 1;
}

int condition_collision_airplanes(char type[])
{

	for(int i = 0;i < 8;i++)
		if(strcmp(type,"own") == 0)
			if(line + x[i] < 1 || line + x[i] > n || column + y[i] < 1 || column + y[i] > n
				|| own_map[line + x[i]][column + y[i]] == 1)
				return 0;
		else if(strcmp(type,"enemy") == 0)
			if(line + x[i] < 1 || line + x[i] > n || column + y[i] < 1 || column + y[i] > n
				|| enemy_map[line + x[i]][column + y[i]] == 1)
				return 0;
	return 1;

}

void change_rotation()
{
	int aux = rotated;
	int aux_x[8];
	int aux_y[8];

	for(int i = 0;i < 8;i++){
		aux_x[i] = x[i];
		aux_y[i] = y[i];
	}

	rotated = (rotated + 1) % 4;

	if(rotated == 0){
		int dx[8] = {-1,0,0,0,1,2,2,2};
		int dy[8] = {0,-1,0,1,0,-1,0,1};
		change_matrix_rotation(dx,dy);
	}

	else if(rotated == 1){
		int dx[8] = {0,1,0,-1,0,1,0,-1};
		int dy[8] = {1,0,0,0,-1,-2,-2,-2};
		change_matrix_rotation(dx,dy);
	}

	else if(rotated == 2){
		int dx[8] = {1,0,0,0,-1,-2,-2,-2};
		int dy[8] = {0,-1,0,1,0,-1,0,1};
		change_matrix_rotation(dx,dy);
	}

	else if (rotated == 3){
		int dx[8] = {0,-1,0,1,0,-1,0,1};
		int dy[8] = {-1,0,0,0,1,2,2,2};
		change_matrix_rotation(dx,dy);
	}

	if(condition_bounds_airplanes() == 0){
		rotated = aux;
		change_matrix_rotation(aux_x,aux_y);
	}
}

void addAirplaneToOwnMap()
{
	for(int i = 0; i < 8 ; i++)
		own_map[line + x[i]][column + y[i]] = 1;
}



void choose_airplanes()
{
	int ok;
	int nr = 0;
	while(nr < no_airplanes){
		draw_airplane(R_plane_moving,G_plane_moving,B_plane_moving);
		while(1){
			ok = 0;
			//daca e apasat UP

			if((PIND & (1 << PD6)) == 0){
				line--;
				if(condition_bounds_airplanes() == 0)
					line++;
				else{
					line++;
					erase_last_airplane();
					line--;
					ok = 1;
				}
			}

			//daca e apasat LEFT
			else if((PIND & (1 << PD5)) == 0){
				column++;
				if(condition_bounds_airplanes() == 0)
						column--;
				else{
						column--;
						erase_last_airplane();
						column++;
						ok = 1;
				}
			}
			
			//daca e apasat RIGHT
			else if((PINC & (1 << PC0)) == 0){
				column--;
				if(condition_bounds_airplanes() == 0)
						column++;
				else{
					column++;
					erase_last_airplane();
					column--;
					ok = 1;
				}
			}
			
			//daca e apasat DOWN
			else if((PIND & (1 << PD1)) == 0){
				line++;
				if(condition_bounds_airplanes() == 0)
					line--;
				else{
					line--;
					erase_last_airplane();
					line++;
					ok = 1;
				}
			}
			
			//butonul de rotatie al avionului
			else if ((PINB & (1 << PB2) ) == 0){
				erase_last_airplane();
				change_rotation();
				draw_airplane(R_plane_moving,G_plane_moving,B_plane_moving);
				_delay_ms(500);
			}

			//daca e apasat OK
			else if((PIND & (1 << PD4)) == 0){
				char type[] = "own";
				if(condition_collision_airplanes(type) != 0){
					nr++;
					draw_airplane(R_plane_placed,G_plane_placed,B_plane_placed);
					addAirplaneToOwnMap();
					line = n/2;
					column = n/2;

					_delay_ms(500);

					break;
				}
			}
		
			if(ok == 1){
				draw_airplane(R_plane_moving,G_plane_moving,B_plane_moving);
				_delay_ms(500);
			}

		}

	}
}




void choose_move()
{
	int ok = 1;
	while(ok == 1){
		/*if(gameOver() != 0)
			break;
		make_map();
		draw_current_position();
		_delay_ms(500);
		*/

		draw_current_position(R_ball_moving,G_ball_moving,B_ball_moving);
		char *buffer = (char*)malloc(30);
		sprintf(buffer,"ROUND : %d",no_round);
		ST7735R_DrawText(10, 10, buffer, 0, 0, 255, 0, 255, 0);

		sprintf(buffer,"NO_REMAINING: %d",TOTAL_DIM_PLANES - no_dim_found);
		ST7735R_DrawText(10, 150, buffer, 0, 0, 255, 0, 255, 0);


		free(buffer);

		//draw_airplane();
		//_delay_ms(5000);
		while(1){
			
			//daca e apasat UP
			if((PIND & (1 << PD6)) == 0){
				if(line > 1){
					erase_last_ball();
					line--;
					draw_current_position(R_ball_moving,G_ball_moving,B_ball_moving);
					_delay_ms(500);
					continue;
				}
				
			}
			//daca e apasat LEFT
			else if((PIND & (1 << PD5)) == 0){
				if(column < n){
					erase_last_ball();
					column++;
					draw_current_position(R_ball_moving,G_ball_moving,B_ball_moving);
					_delay_ms(500);
					continue;
				}
				
			}
			
			//daca e apasat DOWN
			else if((PIND & (1 << PD1)) == 0){
				if(line < n){
					erase_last_ball();
					line++;
					draw_current_position(R_ball_moving,G_ball_moving,B_ball_moving);
					_delay_ms(500);
					continue;
				}
				
			}
			//daca e apasat RIGHT
			else if((PINC & (1 << PC0)) == 0){
				if(column > 1){
					erase_last_ball();
					column--;
					draw_current_position(R_ball_moving,G_ball_moving,B_ball_moving);
					_delay_ms(500);
					continue;
				}
				
			}

			//daca e apasat OK
			else if((PIND & (1 << PD4)) == 0){
				PORTD |= (1 << PD7);
				//daca a mai fost atacata considera ca nu s-a facut mutarea
				if(attacked_map[line][column] == 1){
					_delay_ms(500);
					break;

				}

				if(own_map[line][column] == 1){
					no_dim_found++;
					draw_square(line,column,R_plane_placed,G_plane_placed,B_plane_placed);
					//draw_current_position(R_touch,G_touch,B_touch);
					attacked_map[line][column] = 1;
				}
				else{
					no_round++;
					draw_current_position(R_missed,G_missed,B_missed);

					attacked_map[line][column] = 1;
				}
				_delay_ms(500);
				PORTD &= ~(1 << PD7);

				if (no_dim_found == TOTAL_DIM_PLANES){
					ST7735R_FillRect(0, 0, ST7735R_WIDTH - 1, ST7735R_HEIGHT - 1, 255, 255, 255);
					char buffer[50];
					
					ST7735R_DrawText(30, 50,"Felicitari!!!!", 0, 0, 255, R_surface, G_surface, B_surface);
					ST7735R_DrawText(30, 60,"Ai castigat!!!!", 255, 0, 255, R_surface, G_surface, B_surface);
					sprintf(buffer,"No rounds  : %d",no_round);
   					ST7735R_DrawText(30, 70, buffer, 0, 255, 0,R_surface, G_surface, B_surface);
					ok = 0;
				}
				break;
			}
		

		}

	}
}


void test()
{
	for(int i = 0;i < 500;i++){	
		
		//draw_current_position();
		//line--;
		//column--;
		if (i % 3 == 0)
			ST7735R_FilledCircle(64, 80 + i * 0.1, 32, 0, 0, 255);

		if (i % 3 == 1)
			ST7735R_FilledCircle(64, 80 + i * 0.1, 32, 0, 255, 255);

		if (i % 3 == 2)
			ST7735R_FilledCircle(64, 80 + i * 0.1, 32, 255, 255, 255);
	
		//ST7735R_FilledCircle(96, 32, 32, 0, 0, 255);

		_delay_ms(500);

	}
}


ISR(USART0_RX_vect)
{
	unsigned char c = UDR0;
	if(c == 'P')
		place_planes = 1;

	received_msg = 1;
	_delay_ms(500);
}




int main(void) {

	DDRD |= (1 << PD7);
 	n = 10;
	no_airplanes = 1;
	
	SPI_init();
	ST7735R_Begin();
	USART0_init();

	
	start_joystick();
	setup_coordinates();


   	while(1)
   	{
    	if(place_planes == 0){
    		make_map();
    		choose_airplanes();
    		make_map();
    		choose_move();
    		USART0_transmit('P');
    		
    	}
    	while(place_planes == 0);
    	_delay_ms(500);
    	break;


	}
	ST7735R_FillRect(0, 0, ST7735R_WIDTH - 1, ST7735R_HEIGHT - 1, 0, 0, 0);
   	ST7735R_DrawText(0, 50, "sender!!! ", 255, 0, 0, 0, 255, 0);

	return 0;
}
