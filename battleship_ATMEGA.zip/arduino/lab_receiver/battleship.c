/*
 * PM - 2017
 * lab0.c
 */

#define __PROG_TYPES_COMPAT__
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/io.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <util/delay.h>
#include "ST7735R_TFT.h"
#include "spi.h"
#include "usart.h"

#define WIDTH ST7735R_WIDTH 
#define HEIGHT ST7735R_HEIGHT

#define L 120
#define CENTER_X WIDTH/2
#define CENTER_Y HEIGHT/2

#define R_line 0
#define G_line 0
#define B_line 0


#define R_plane_placed 153
#define G_plane_placed 153
#define B_plane_placed 0

#define R_plane_moving 192
#define G_plane_moving 192
#define B_plane_moving 192

#define R_ball_moving 0
#define G_ball_moving 0
#define B_ball_moving 0

#define R_touch 0
#define G_touch 0
#define B_touch 255

#define R_missed 128
#define G_missed 128
#define B_missed 128

#define R_surface 255
#define G_surface 255
#define B_surface 255

volatile int DIM_airplane_big = 8;

volatile int TOTAL_DIM_PLANES;
volatile int line, column; 
volatile int X,Y;
volatile int n;
volatile int length_square;

volatile int horizontal_lines[15];
volatile int vertical_lines[15];

volatile int own_map[15][15];
volatile int attacked_map[15][15];
volatile int enemy_map[15][15];
volatile int rotated = 2;
volatile int no_airplanes = 0;
volatile unsigned char received_msg = 0;
volatile int matrix_echange;

volatile int x[8] = {-1,0,0,0,1,2,2,2};
volatile int y[8] = {0,0,-1,1,0,0,-1,1};
volatile int won = 0;
volatile int place_planes = 0;
volatile unsigned char no_round = 0;
volatile int no_dim_found = 0;
volatile char no_attemps_opponent = 0;

float min(float x,float y){
	if(x > y)
		return x;
	return y;
}

/* Aprinde led-ul PC0 la apasarea butonului PB2. */
void exemplu(void) {
	/* Setez pinul PD7 ca iesire. */
	DDRD |= (1 << PD7);

	/* Sting LED-ul. */
	PORTD &= ~(1 << PD7);

	while (1) {
			PORTD |= (1 << PD7);
			_delay_ms(500);
	}
}


void start_joystick(void){
	/* Setez pinii PD6,PD5,PD4,PD1,PD0 + PB2*/
	DDRB &= ~(1 << PB2);
	DDRD &= ~(1 << PD6);
	DDRD &= ~(1 << PD5);
	DDRD &= ~(1 << PD4);
	//DDRD &= ~(1 << PD1);
	//DDRD &= ~(1 << PD0);
	DDRC &= ~(1 << PC0);
	DDRC &= ~(1 << PC1);


	/* Activez rezistenta de pull-up pentru pinii de mai sus */
	PORTB |= (1 << PB2);
	PORTD |= (1 << PD6);
	PORTD |= (1 << PD5);
	PORTD |= (1 << PD4);
	//PORTD |= (1 << PD1);
	//PORTD |= (1 << PD0);
	PORTC |= (1 << PC0);
	PORTC |= (1 << PC1);

	
}

void calculate_ball_coordinates()
{	
	X = vertical_lines[line] + length_square/2 + 1;
	Y = horizontal_lines[column] + length_square/2 + 1;
}


void setup_coordinates()
{
	column = n/2;
	line = n/2;
	TOTAL_DIM_PLANES = no_airplanes * DIM_airplane_big;

	length_square = (L - n - 1)/n;
	if (length_square % 2 == 1)
		length_square--;

	for(int i = 0 ;i <= n/2; i++){
		if(i > 0 ){
			vertical_lines[n/2 + i + 1] = CENTER_X + i * length_square + i;
			vertical_lines[n/2 - i + 1] = CENTER_X - i * length_square - i;

			horizontal_lines[n/2 + i + 1] = CENTER_Y + i * length_square + i;
			horizontal_lines[n/2 - i + 1 ] = CENTER_Y - i * length_square - i;
		}
		else{
			vertical_lines[n/2 + 1] = CENTER_X;
 			horizontal_lines[n/2 + 1] = CENTER_Y;
		}
	}

	calculate_ball_coordinates();
}

void make_map(){
	//alb peste tot
	ST7735R_FillRect(0, 0, WIDTH, HEIGHT, R_surface, G_surface, B_surface);
	
	if (n % 2 == 0){
		float k = 1;
		if(n == 10)
			k = 1;
		if (n == 8)
			k = 1.25;
		for(int i = 0; i <= n/2; i++){
			if(i > 0){
 				ST7735R_VLine(vertical_lines[n/2 - i + 1],horizontal_lines[1], horizontal_lines[n + 1], R_line, G_line, B_line);
 				ST7735R_VLine(vertical_lines[n/2 + i + 1],horizontal_lines[1], horizontal_lines[n + 1], R_line, G_line, B_line);

 				ST7735R_HLine(vertical_lines[1],vertical_lines[n + 1], horizontal_lines[n/2 + i + 1] , R_line, G_line, B_line);
 				ST7735R_HLine(vertical_lines[1],vertical_lines[n + 1],  horizontal_lines[n/2 - i + 1], R_line, G_line, B_line);
 			}
 			else{
 				ST7735R_VLine(vertical_lines[n/2 + 1],horizontal_lines[1], horizontal_lines[ n + 1], R_line, G_line, B_line);
 				ST7735R_HLine(vertical_lines[1],vertical_lines[n + 1],horizontal_lines[n/2 + 1], R_line, G_line, B_line);
 			}
 		}
	}

	//adauga indexare matrice

	char buffer[10];
	for(int i = 1 ;i <= n; i++){
		sprintf(buffer,"%d",i);
		ST7735R_DrawText(vertical_lines[1] - 8,horizontal_lines[i] + length_square/2, buffer, 0, 0, 255, R_surface,G_surface,B_surface);

		sprintf(buffer,"%c",'A' + i - 1);
		ST7735R_DrawText(vertical_lines[i] + length_square/2,horizontal_lines[1] - 9, buffer, 0, 0, 255, R_surface,G_surface,B_surface);
	}

}




void draw_current_position(int r,int g,int b)
{
	calculate_ball_coordinates();
	int radius = length_square / 4;
	ST7735R_FilledCircle(X, Y, radius, r,g,b);
}

void draw_square(int l,int c,int r,int g,int b)
{
	ST7735R_FillRect(vertical_lines[l] + 1,horizontal_lines[c] + 1,vertical_lines[l + 1] - 1,horizontal_lines[c + 1] - 1, r, g, b);

}

void change_matrix_rotation(int dx[8],int dy[8]){
	for(int i = 0;i < 8; i++){
		x[i] = dx[i];
		y[i] = dy[i];
	}
}



void draw_airplane(int r,int g,int b)
{
	for(int i = 0;i < 8;i++)
		draw_square(line + x[i], column + y[i], r, g, b);
}


int gameOver()
{
	return 0;
}

void erase_last_ball()
{	//verifica ce tip de culoarea are harta
	/*if(own_map[line][column] == 0)
		ST7735R_FillRect(vertical_lines[line] + 1,horizontal_lines[column] + 1,vertical_lines[line + 1] - 1, horizontal_lines[column + 1] - 1, R_surface, G_surface, B_surface);
	else
		ST7735R_FillRect(vertical_lines[line] + 1,horizontal_lines[column] + 1,vertical_lines[line + 1] - 1, horizontal_lines[column + 1] - 1, R_plane_placed, G_plane_placed, B_plane_placed);*/
	//verifica daca a este deja un semn pe locatia respectiva

	ST7735R_FillRect(vertical_lines[line] + 1,horizontal_lines[column] + 1,vertical_lines[line + 1] - 1, horizontal_lines[column + 1] - 1, R_surface, G_surface, B_surface);

	if(attacked_map[line][column] == 1 && own_map[line][column] == 1){
		ST7735R_FillRect(vertical_lines[line] + 1,horizontal_lines[column] + 1,vertical_lines[line + 1] - 1, horizontal_lines[column + 1] - 1, R_plane_placed, G_plane_placed, B_plane_placed);
		draw_current_position(R_touch,G_touch,B_touch);
	}
	else if (attacked_map[line][column] == 1)
		draw_current_position(R_missed,G_missed,B_missed);
	/*else if (attacked_map[line][column] == 0)
		draw_current_position(R_surface,G_ball_moving,B_ball_moving);*/

	//ST7735R_FillRect(X - length_square/4, Y - length_square/4, X + length_square/4, Y + length_square/4, 255, 255, 255);

}

void erase_last_airplane()
{

	for(int i = 0;i < 8; i++){
		if(own_map[line + x[i]][column + y[i]] == 0)
			draw_square(line + x[i],column + y[i],R_surface,G_surface,B_surface);
		else
			draw_square(line + x[i],column + y[i],R_plane_placed,G_plane_placed,B_plane_placed);
	}
}

int condition_bounds_airplanes()
{
	
	
	for(int i = 0;i < 8;i++)
		if(line + x[i] < 1 || line + x[i] > n || column + y[i] < 1 || column + y[i] > n)
			return 0;

	return 1;
}

int condition_collision_airplanes(char type[])
{

	for(int i = 0;i < 8;i++)
		if(strcmp(type,"own") == 0)
			if(line + x[i] < 1 || line + x[i] > n || column + y[i] < 1 || column + y[i] > n
				|| own_map[line + x[i]][column + y[i]] == 1)
				return 0;
		else if(strcmp(type,"enemy") == 0)
			if(line + x[i] < 1 || line + x[i] > n || column + y[i] < 1 || column + y[i] > n
				|| enemy_map[line + x[i]][column + y[i]] == 1)
				return 0;
	return 1;

}

void change_rotation()
{
	int aux = rotated;
	int aux_x[8];
	int aux_y[8];

	for(int i = 0;i < 8;i++){
		aux_x[i] = x[i];
		aux_y[i] = y[i];
	}

	rotated = (rotated + 1) % 4;

	if(rotated == 0){
		int dx[8] = {-1,0,0,0,1,2,2,2};
		int dy[8] = {0,-1,0,1,0,-1,0,1};
		change_matrix_rotation(dx,dy);
	}

	else if(rotated == 1){
		int dx[8] = {0,1,0,-1,0,1,0,-1};
		int dy[8] = {1,0,0,0,-1,-2,-2,-2};
		change_matrix_rotation(dx,dy);
	}

	else if(rotated == 2){
		int dx[8] = {1,0,0,0,-1,-2,-2,-2};
		int dy[8] = {0,-1,0,1,0,-1,0,1};
		change_matrix_rotation(dx,dy);
	}

	else if (rotated == 3){
		int dx[8] = {0,-1,0,1,0,-1,0,1};
		int dy[8] = {-1,0,0,0,1,2,2,2};
		change_matrix_rotation(dx,dy);
	}

	if(condition_bounds_airplanes() == 0){
		rotated = aux;
		change_matrix_rotation(aux_x,aux_y);
	}
}

void addAirplaneToOwnMap()
{
	for(int i = 0; i < 8 ; i++)
		own_map[line + x[i]][column + y[i]] = 1;
}



void choose_airplanes()
{
	int ok;
	int nr = 0;
	change_rotation();
	while(nr < no_airplanes){
		draw_airplane(R_plane_moving,G_plane_moving,B_plane_moving);
		while(1){
			ok = 0;
			//daca e apasat LEFT

			if((PIND & (1 << PD5)) == 0){
				line--;
				if(condition_bounds_airplanes() == 0)
					line++;
				else{
					line++;
					erase_last_airplane();
					line--;
					ok = 1;
				}
			}

			//daca e apasat DOWN
			else if((PINC & (1 << PC1)) == 0){
				column++;
				if(condition_bounds_airplanes() == 0)
						column--;
				else{
						column--;
						erase_last_airplane();
						column++;
						ok = 1;
				}
			}
			
			//daca e apasat UP
			else if((PIND & (1 << PD6)) == 0){
				column--;
				if(condition_bounds_airplanes() == 0)
						column++;
				else{
					column++;
					erase_last_airplane();
					column--;
					ok = 1;
				}
			}
			
			//daca e apasat RIGHT
			else if((PINC & (1 << PC0)) == 0){
				line++;
				if(condition_bounds_airplanes() == 0)
					line--;
				else{
					line--;
					erase_last_airplane();
					line++;
					ok = 1;
				}
			}
			
			//butonul de rotatie al avionului
			else if ((PINB & (1 << PB2) ) == 0){
				erase_last_airplane();
				change_rotation();
				draw_airplane(R_plane_moving,G_plane_moving,B_plane_moving);
				_delay_ms(5000);
			}

			//daca e apasat OK
			else if((PIND & (1 << PD4)) == 0){
				PORTD |= (1 << PD7);
				char type[] = "own";
				if(condition_collision_airplanes(type) != 0){
					nr++;
					draw_airplane(R_plane_placed,G_plane_placed,B_plane_placed);
					addAirplaneToOwnMap();
					line = n/2;
					column = n/2;

					_delay_ms(5000);
					PORTD &= ~(1 << PD7);
					break;
				}
				_delay_ms(5000);
				PORTD &= ~(1 << PD7);
			}
		
			if(ok == 1){
				draw_airplane(R_plane_moving,G_plane_moving,B_plane_moving);
				_delay_ms(5000);
			}

		}

	}
}

int set_options(int v[3], char words[][10], int size, char type[]){
	int r_fundal = 255;
	int g_fundal = 255;
	int b_fundal = 255;

	int r_option = 0;
	int g_option = 0;
	int b_option = 0;

	int pos = 0;
	int length = 10;
	int x_coord = 50;
	int ERR = 4;
	int new_width = 45;
	int options = 0;


	ST7735R_FillRect(0, 0, WIDTH, HEIGHT, r_fundal,g_fundal,b_fundal);
	for(int i = 0; i < 3; i++){
		ST7735R_DrawText(x_coord, v[i], words[i], 0, 0, 255, r_fundal,g_fundal,b_fundal);
	}

	//optiunea de start
	ST7735R_FillRect(x_coord, v[pos] - ERR, x_coord + new_width, v[pos] + length, r_option,g_option,b_option);
	ST7735R_DrawText(x_coord, v[pos], words[pos], 0, 0, 255, r_option,g_option,b_option);


	if(strcmp(type,"dimensiune") == 0){
		ST7735R_DrawText(10, 20, "Alegeti dimensiunea", 0, 0, 255, r_fundal,g_fundal,b_fundal);
		ST7735R_DrawText(50, 30, "tablei", 0, 0, 255, r_fundal,g_fundal,b_fundal);
	}

	else if (strcmp(type,"no_avioane") == 0){
		ST7735R_DrawText(10, 20, "Alegeti no avioane", 0, 0, 255, r_fundal,g_fundal,b_fundal);
	}

	else if (strcmp(type,"") == 0){
		ST7735R_DrawText(40, 20, "Battleship", 0, 0, 255, r_fundal,g_fundal,b_fundal);

	}
	
	while(1){
		//daca e apasat UP
		if((PIND & (1 << PD6)) == 0){
			if(pos > 0){
				//refacem vechea optiune
				ST7735R_FillRect(0, v[pos] - ERR, WIDTH, v[pos] + length, r_fundal,g_fundal,b_fundal);
				ST7735R_DrawText(x_coord, v[pos] , words[pos], 0, 0, 255, r_fundal,g_fundal,b_fundal);
				
				pos--;

				ST7735R_FillRect(x_coord, v[pos] - ERR, x_coord + new_width, v[pos] + length, r_option,g_option,b_option);
				ST7735R_DrawText(x_coord, v[pos], words[pos], 0, 0, 255, r_option,g_option,b_option);
				
				_delay_ms(5000);
				continue;
			}
			
		}	
	//daca e apasat DOWN
		else if((PINC & (1 << PC1)) == 0){
			if(pos < size){
				//refacem vechea optiune
				ST7735R_FillRect(0, v[pos] - ERR, WIDTH, v[pos] + length,r_fundal,g_fundal,b_fundal);
				ST7735R_DrawText(x_coord, v[pos] , words[pos], 0, 0, 255, r_fundal,g_fundal,b_fundal);
				
				pos++;

				ST7735R_FillRect(x_coord, v[pos] - ERR, x_coord + new_width, v[pos] + length, r_option,g_option,b_option);
				ST7735R_DrawText(x_coord, v[pos], words[pos], 0, 0, 255, r_option,g_option,b_option);
				
				_delay_ms(5000);
				continue;
			}	
		}

		else if((PIND & (1 << PD4)) == 0){
			//start
			PORTD |= (1 << PD7);
			_delay_ms(5000);
			PORTD &= ~(1 << PD7);
			return pos;
		}
	}

	return -1;

}


void choose_setup()
{
	//start
	int v[3] = {55, 70, 85};
	char words[][10] = {"Start","Options","Exit"};
	int options = set_options(v, words, 3,"");

	n = 10;
	no_airplanes = 3;

	if(options == 1){
		char buffer[10];
		int res;
		//aflam dimensiunea matricii
		for(int i = 0; i < 3; i++){
			sprintf(buffer,"%d",8 + 2 * i);
			strcpy(words[i],buffer);
		}
		res = set_options(v, words, 3,"dimensiune");
		n = 8 + 2* res;

		//aflam numarul de avioane
		for(int i = 0; i < 3; i++){
			sprintf(buffer,"%d",i + 2);
			strcpy(words[i],buffer);
		}
		res = set_options(v, words, 3,"no_avioane");
		no_airplanes = res + 2;
	}

	setup_coordinates();

}


void choose_move()
{
	int ok = 1;
	while(ok == 1){
		/*if(gameOver() != 0)
			break;
		make_map();
		draw_current_position();
		_delay_ms(500);
		*/

		draw_current_position(R_ball_moving,G_ball_moving,B_ball_moving);
		char *buffer = (char*)malloc(30);
		sprintf(buffer,"ATTEMPTS : %d",no_round);
		ST7735R_FillRect(0, 0, 128, 10, R_surface, G_surface, B_surface);
		ST7735R_DrawText(40, 5, buffer, 0, 0, 255, 0, 255, 0);

		ST7735R_FillRect(0, 145, 128, 168, R_surface, G_surface, B_surface);
		sprintf(buffer,"NO_REMAINING: %d",TOTAL_DIM_PLANES - no_dim_found);
		ST7735R_DrawText(15, 150, buffer, 0, 0, 255, 0, 255, 0);


		free(buffer);

		//draw_airplane();
		//_delay_ms(5000);
		while(1){
			
			//daca e apasat LEFT
			if((PIND & (1 << PD5)) == 0){
				if(line > 1){
					erase_last_ball();
					line--;
					draw_current_position(R_ball_moving,G_ball_moving,B_ball_moving);
					_delay_ms(5000);
					continue;
				}
				
			}
			//daca e apasat DOWN
			else if((PINC & (1 << PC1)) == 0){
				if(column < n){
					erase_last_ball();
					column++;
					draw_current_position(R_ball_moving,G_ball_moving,B_ball_moving);
					_delay_ms(5000);
					continue;
				}
				
			}
			
			//daca e apasat RIGHT
			else if((PINC & (1 << PC0)) == 0){
				if(line < n){
					erase_last_ball();
					line++;
					draw_current_position(R_ball_moving,G_ball_moving,B_ball_moving);
					_delay_ms(5000);
					continue;
				}
				
			}
			//daca e apasat UP
			else if((PIND & (1 << PD6)) == 0){
				if(column > 1){
					erase_last_ball();
					column--;
					draw_current_position(R_ball_moving,G_ball_moving,B_ball_moving);
					_delay_ms(5000);
					continue;
				}
				
			}

			//daca e apasat OK
			else if((PIND & (1 << PD4)) == 0){
				PORTD |= (1 << PD7);
				//daca a mai fost atacata considera ca nu s-a facut mutarea
				if(attacked_map[line][column] == 1){
					_delay_ms(5000);
					break;

				}

				if(own_map[line][column] == 1){
					no_dim_found++;
					draw_square(line,column,R_plane_placed,G_plane_placed,B_plane_placed);
					//draw_current_position(R_touch,G_touch,B_touch);
					attacked_map[line][column] = 1;
				}
				else{
					no_round++;
					draw_current_position(R_missed,G_missed,B_missed);

					attacked_map[line][column] = 1;
				}

				_delay_ms(5000);
				PORTD &= ~(1 << PD7);

				if (no_dim_found == TOTAL_DIM_PLANES){
					ST7735R_FillRect(0, 0, ST7735R_WIDTH - 1, ST7735R_HEIGHT - 1, 255, 255, 255);
					char buffer[50];
					
					ST7735R_DrawText(30, 60,"Felicitari!!!!", 0, 0, 255, R_surface, G_surface, B_surface);
					ST7735R_DrawText(25, 70,"Ai terminat jocul", 255, 0, 255, R_surface, G_surface, B_surface);
					sprintf(buffer,"No attempts: %d",no_round);
   					ST7735R_DrawText(30, 80, buffer, 0, 255, 0,R_surface, G_surface, B_surface);
					ok = 0;
				}
				break;
			}
		

		}

	}
}


void test()
{
	for(int i = 0;i < 500;i++){	
		
		//draw_current_position();
		//line--;
		//column--;
		if (i % 3 == 0)
			ST7735R_FilledCircle(64, 80 + i * 0.1, 32, 0, 0, 255);

		if (i % 3 == 1)
			ST7735R_FilledCircle(64, 80 + i * 0.1, 32, 0, 255, 255);

		if (i % 3 == 2)
			ST7735R_FilledCircle(64, 80 + i * 0.1, 32, 255, 255, 255);
	
		//ST7735R_FilledCircle(96, 32, 32, 0, 0, 255);

		_delay_ms(500);

	}
}


ISR(USART0_RX_vect)
{
	no_attemps_opponent = UDR0;

	received_msg = 1;
	//_delay_ms(500);
}




int main(void) {

	DDRD |= (1 << PD7);
 	//n = 12;
	//no_airplanes = 2;
	_delay_ms(50000);
	SPI_init();
	ST7735R_Begin();
	USART0_init();
	received_msg = 0;

	
	start_joystick();
	setup_coordinates();


   	
    choose_setup();
    make_map();
    choose_airplanes();
    make_map();
    choose_move();
    

    USART0_transmit(no_round);

    //asteapta mesajul de la celalalt
    while(received_msg == 0){

    }

    if(no_attemps_opponent < no_round){	
		ST7735R_FillRect(0, 0, WIDTH, HEIGHT, R_surface,G_surface, B_surface);
   		ST7735R_DrawText(50, 50, "YOU LOST ", 255, 0, 0, R_surface,G_surface, B_surface);
   }

   else if(no_attemps_opponent > no_round){
   		ST7735R_FillRect(0, 0, WIDTH, HEIGHT, R_surface,G_surface, B_surface);
   		ST7735R_DrawText(50, 50, "YOU WIN", 255, 0, 0, R_surface,G_surface, B_surface);
   }

   else{
   		ST7735R_FillRect(0, 0, WIDTH, HEIGHT, R_surface,G_surface, B_surface);
   		ST7735R_DrawText(50, 50, "It's a tie", 255, 0, 0, R_surface,G_surface, B_surface);
   }

	return 0;
}
